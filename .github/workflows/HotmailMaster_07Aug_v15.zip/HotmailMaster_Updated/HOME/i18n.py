"""
Multi-Language System — English / Hindi
Dev: @ADI_WT
"""

_LANG = {"user": {}}


def set_lang(user_id: int, lang: str):
    _LANG["user"][user_id] = lang


def get_lang(user_id: int) -> str:
    return _LANG["user"].get(user_id, "en")


def t(user_id: int, key: str) -> str:
    lang = get_lang(user_id)
    return _STRINGS.get(key, {}).get(lang, key)


_STRINGS = {
    "welcome_title": {"en": "⚡ WHITE MASTER ⚡", "hi": "⚡ व्हाइट मास्टर ⚡"},
    "welcome_sub": {"en": "Premium All-in-One Account Checker", "hi": "प्रीमियम ऑल-इन-वन अकाउंट चेकर"},
    "system_status": {"en": "SYSTEM STATUS", "hi": "सिस्टम स्टेटस"},
    "online": {"en": "Online", "hi": "ऑनलाइन"},
    "users": {"en": "Users", "hi": "यूजर्स"},
    "proxies": {"en": "Proxies", "hi": "प्रॉक्सी"},
    "checked": {"en": "Checked", "hi": "चेक्ड"},
    "hits": {"en": "Hits", "hi": "हिट्स"},
    "premium_modules": {"en": "PREMIUM MODULES", "hi": "प्रीमियम मॉड्यूल्स"},
    "cookie_checker": {"en": "Cookie Checker", "hi": "कुकी चेकर"},
    "services": {"en": "services", "hi": "सर्विसेज"},
    "minecraft_combo": {"en": "Minecraft Combo", "hi": "माइनक्राफ्ट कॉम्बो"},
    "boosteroid_combo": {"en": "Boosteroid Combo", "hi": "बूस्टरॉइड कॉम्बो"},
    "inboxer": {"en": "Inboxer", "hi": "इनबॉक्सर"},
    "m_hotmail": {"en": "M-Hotmail", "hi": "एम-हॉटमेल"},
    "tv_activators": {"en": "TV Activators", "hi": "टीवी एक्टिवेटर्स"},
    "select_module": {"en": "Select a module below to begin", "hi": "नीचे से मॉड्यूल चुनें"},
    "m_hotmail_btn": {"en": "📧 M-HOTMAIL", "hi": "📧 एम-हॉटमेल"},
    "cookie_checker_btn": {"en": "🍪 Cookie Checker", "hi": "🍪 कुकी चेकर"},
    "inboxer_btn": {"en": "📬 Inboxer", "hi": "📬 इनबॉक्सर"},
    "xbox_game_pass_btn": {"en": "💎 Xbox Game Pass", "hi": "💎 एक्सबॉक्स गेम पास"},
    "boosteroid_btn": {"en": "☁️ Boosteroid", "hi": "☁️ बूस्टरॉइड"},
    "tv_menu_btn": {"en": "📺 TV Menu", "hi": "📺 टीवी मेनू"},
    "admin_panel_btn": {"en": "👑 Admin Panel", "hi": "👑 एडमिन पैनल"},
    "language_btn": {"en": "🌐 Language / भाषा", "hi": "🌐 भाषा / Language"},
    "progress": {"en": "PROGRESS", "hi": "प्रोग्रेस"},
    "cpm": {"en": "cpm", "hi": "सीपीएम"},
    "eta": {"en": "ETA", "hi": "बाकी समय"},
    "bad": {"en": "Bad", "hi": "बैड"},
    "errors": {"en": "Errors", "hi": "एरर्स"},
    "retry": {"en": "Retry", "hi": "रीट्राई"},
    "complete": {"en": "COMPLETE", "hi": "कंप्लीट"},
    "stopped": {"en": "STOPPED", "hi": "रुका हुआ"},
    "time": {"en": "Time", "hi": "समय"},
    "private_bot": {"en": "Private Bot — Access Required", "hi": "प्राइवेट बॉट — एक्सेस चाहिए"},
    "access_required": {"en": "This bot is private. Admin approval required to use.", "hi": "यह बॉट प्राइवेट है। इस्तेमाल के लिए एडमिन की अप्रूवल चाहिए।"},
    "request_sent": {"en": "Your request has been sent to admin. Bot will unlock after approval.", "hi": "आपकी रिक्वेस्ट एडमिन को भेज दी गई है। अप्रूवल मिलते ही बॉट खुल जाएगा।"},
    "approved": {"en": "Access Approved! You can now use the bot. Press /start!", "hi": "एक्सेस अप्रूव्ड! अब बॉट इस्तेमाल कर सकते हैं। /start दबाएं!"},
    "rejected": {"en": "Access Rejected. Admin has rejected your request.", "hi": "एक्सेस रिजेक्टेड। एडमिन ने आपकी रिक्वेस्ट रिजेक्ट कर दी।"},
    "upload_txt": {"en": "Upload your .txt file (1 file = 1 account).", "hi": "अपनी .txt फाइल भेजें (1 फाइल = 1 अकाउंट)।"},
    "saved_folder": {"en": "Bot will save to", "hi": "बॉट इस फोल्डर में सेव करेगा"},
    "format_any": {"en": "Format: key=value, Netscape, or JSON — all work.", "hi": "फॉर्मेट: key=value, Netscape, या JSON — सब चलेंगे।"},
    "dev": {"en": "Dev: @ADI_WT", "hi": "डेव: @ADI_WT"},
}
