# Proxy Auto Refresh System

The bot automatically keeps the proxy pool fresh.

## How it works

1. **Startup** — proxies load from `FILES/proxy.txt` + admin-added proxies (deduplicated) into the global pool.
2. **Auto fetch loop** — a background thread scrapes public proxy sources periodically (`auto_proxy_fetch_loop` in `bot.py`).
3. **Proxy Hunt** — scraped proxies are tested with 300 threads; only live ones are kept.
4. **Dead proxy tracking** — checkers mark dead proxies (`_mark_dead`) and skip them automatically. Failed checks retry with fresh proxies (3 attempts).
5. **Auto-test on start** — a background sample test (30 proxies, 5s timeout) logs how many proxies are alive.

## Commands

- `/proxyhunt` — manually hunt fresh live proxies
- `/get_proxies` — download current proxy list (admin)

## Supported formats

```
ip:port
ip:port:user:pass
user:pass@ip:port
http://user:pass@ip:port
socks5://user:pass@ip:port
```
