@echo off
title Hotmail Master Bot - Auto Restart (Windows RDP)
cd /d "%~dp0"

:loop
echo [%date% %time%] Starting bot...
python bot.py
echo [%date% %time%] Bot stopped/crashed. Restarting in 5s...
timeout /t 5 /nobreak >nul
goto loop
