# Quick Start Guide

## 1. Install

```bash
pip install -r requirements.txt
```

## 2. Configure

Edit `CONFIG/config.py`:

```python
BOT_TOKEN = "your-bot-token"      # from @BotFather
ADMIN_ID = 123456789              # your Telegram user ID
HITS_CHANNEL_ID = 0               # optional: channel ID for auto hit posts
```

## 3. Run

```bash
python3 bot.py
```

You should see the banner, proxy pool size, and `Running! Listening for updates...`

## 4. First use

1. Open your bot in Telegram → `/start`
2. As admin you get full access instantly; other users need your approval (Approve/Reject buttons come to you)

## 5. Checking

- **Combo check (Xbox/Boosteroid):** send `email:password` .txt file → choose checker
- **Cookie check:** send cookie .txt/.zip → Cookies → pick service
- **Hotmail:** send combo file → M-HOTMAIL
- Hits are delivered as a zip; a copy also goes to the admin

## 6. Proxies

Add proxies to `FILES/proxy.txt` (one per line) or use `/proxyhunt`.
Formats: `ip:port`, `ip:port:user:pass`, `user:pass@ip:port`, `socks5://...`

## 7. Useful commands

- `/status` — bot stats (admin)
- `/userstats <id>` — per-user activity (admin)
- `/broadcast` — reply to a message to send it to all users (admin)
- `/fetch_full` — full bot backup (admin)

## 8. Windows RDP vs Linux VPS

Bot **dono pe kaam karta hai** — code fully cross-platform hai (UTF-8 encoding, no OS-specific calls).

### 🪟 Windows RDP
```bat
start_windows.bat          ← normal start (auto deps install)
start_windows_loop.bat     ← crash pe auto-restart (Linux supervisor jaisa)
```
Requirement: Python 3.10+ from python.org (install mein "Add to PATH" tick karo)

### 🐧 Linux VPS
```bash
pip install -r requirements.txt
python3 bot.py
# ya auto-restart ke saath:
bash start_supervised.sh
```

### Notes
- `Procfile` — Heroku/Railway style hosts ke liye already included
- Encoding sab jagah UTF-8 — Hindi/emoji/symbols dono OS pe safe
- Paths relative hain — kisi bhi folder mein extract karke chalao
