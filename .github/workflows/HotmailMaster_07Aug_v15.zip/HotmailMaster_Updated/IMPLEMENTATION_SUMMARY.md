# Implementation Summary

## Core
- **Hotmail/Outlook checker** — Microsoft OAuth login, services detection (PSN, Steam, Supercell, TikTok, Instagram), Xbox Live info, Discord link, balance, promo codes
- **Inbox checker** — Graph API inbox scanning with platform username extraction
- **Xbox Game Pass / Minecraft combo** — sFTTag flow, XBL/XSTS, entitlements (XGPU/XGP), capes, gamertag, region, tenure, XGP expiry; valid/2FA accounts saved separately; hit filters (All / XGPU / MC Premium)
- **Boosteroid combo** — SHA512 PoW login, subscription + games count; premium/valid split

## Cookie checkers (27)
Netflix, ChatGPT, TikTok, Prime Video (channels API), Claude, Cursor, Boosteroid, GeForce NOW, Amazon Luna (real tempo API), Crunchyroll, Canva, Roblox (real Premium), Spotify, Steam, Epic, Discord, Twitch, YouTube, Twitter/X, Reddit (real gold), GitHub, LinkedIn, EA, GOG, Humble, FunPay, Replit (real paid flag)

## TV Login
Netflix, Prime Video, Spotify, JioHotstar (QR)

## Reliability
- 3-proxy retry on network failures; BAD/2FA never retried
- Dead-proxy tracking fixed (raw string match)
- Rate-limit ("too many times") classified as retryable, not BAD
- Auto-retry pass for error combos after each run
- Cloudflare challenge detection (Replit)

## Admin / Users
- Private bot approval system, ban/unban, broadcast, `/status`, `/userstats`
- All user hits auto-forwarded to admin; optional channel auto-post (`HITS_CHANNEL_ID`)
- Daily file limit for free users (10/day), anti-leech hit download guard
