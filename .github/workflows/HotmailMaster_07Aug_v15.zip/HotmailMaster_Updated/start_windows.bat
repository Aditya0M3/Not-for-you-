@echo off
title Hotmail Master Bot - Windows RDP
cd /d "%~dp0"

echo ============================================
echo   HOTMAIL MASTER BOT - Windows Start
echo ============================================

REM Python check
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found! Install Python 3.10+ from python.org
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Deps check/install
echo [*] Checking dependencies...
python -c "import telebot, requests, bs4, cloudscraper, rich, socks" >nul 2>&1
if errorlevel 1 (
    echo [*] Installing dependencies...
    python -m pip install -r requirements.txt
)

REM Start bot
echo [*] Starting bot...
python bot.py

REM Crash ho to 5s baad restart (VPS supervisor jaisa)
echo [!] Bot stopped. Restarting in 5 seconds... (close window to exit)
timeout /t 5 /nobreak >nul
goto :eof
