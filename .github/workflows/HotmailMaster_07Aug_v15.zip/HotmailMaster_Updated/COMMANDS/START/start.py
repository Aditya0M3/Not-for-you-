import time
from telebot import types
from HOME import state
from HOME.i18n import t, set_lang, get_lang
from HOME.helpers import (
    bold, italic, mono, make_progress_bar,
    get_profile_photo, user_full_link,
    E_WAVE, E_SPARKLE, E_ROBOT, E_SHIELD, E_GREEN, E_CLOCK, E_USER, E_GLOBE,
    E_CHART, E_FIRE, E_DIAMOND, E_CHECK, E_CROWN, E_HEART, E_ROCKET, E_CROSS,
    E_GEAR, E_BAN, E_MEMO, E_PIN, E_KEY, E_STOP, E_STAR, E_BOLT
)
from DATABASE.database import load_db, update_user_info, is_banned, is_approved, get_user
from PROXY.proxy import init_proxies
from CONFIG.config import ADMIN_ID, MAX_LINES, MASTER_THREADS, INBOXER_THREADS, COOKIES_THREADS, DEFAULT_THREADS


def _answer(bot, call_id, text=None, alert=False):
    """Silently answer callback queries — Telegram expires them after 30s."""
    try:
        bot.answer_callback_query(call_id, text=text, show_alert=alert)
    except:
        pass


def register():
    bot = state.bot

    @bot.message_handler(commands=['start'])
    def cmd_start(message):
        user = message.from_user
        db_inst = load_db()
        update_user_info(db_inst, user)

        banned, reason = is_banned(db_inst, user.id)
        if banned:
            bot.reply_to(message, f"{E_BAN} {bold('You are banned!')}\n{E_MEMO} Reason: {mono(reason or 'No reason')}", parse_mode="HTML")
            return

        # ── PRIVATE BOT: approval required (no one can use it without admin approval) ──
        if user.id != ADMIN_ID and not is_approved(db_inst, user.id):
            with state.active_checks_lock:
                already = state.active_checks.get(f"access_req_{user.id}")
            uname = f"@{user.username}" if user.username else user.first_name
            deny_text = (
                f"{E_KEY} {bold('Private Bot — Access Required')}\n\n"
                f"This bot is private. You need admin approval to use it.\n"
                f"{E_MEMO} Your request has been sent to the admin. The bot will unlock as soon as you are approved.\n\n"
                f"{E_GEAR} {italic('Dev: @ADI_WT')}"
            )
            bot.reply_to(message, deny_text, parse_mode="HTML")
            if not already:
                with state.active_checks_lock:
                    state.active_checks[f"access_req_{user.id}"] = True
                markup = types.InlineKeyboardMarkup(row_width=2)
                markup.add(
                    types.InlineKeyboardButton("✅ Approve", callback_data=f"admin_appr_{user.id}"),
                    types.InlineKeyboardButton("❌ Reject",  callback_data=f"admin_rej_{user.id}"),
                )
                try:
                    bot.send_message(
                        ADMIN_ID,
                        f"{E_KEY} {bold('Access Request')}\n"
                        f"👤 User: {user_full_link(user)}\n"
                        f"🆔 ID: {mono(str(user.id))}\n"
                        f"📛 Username: {mono(uname)}\n\n"
                        f"Approve and this user will be able to use the bot.",
                        parse_mode="HTML", reply_markup=markup
                    )
                except Exception:
                    pass
            return

        uptime = time.time() - state.BOT_START_TIME
        uptime_str = time.strftime("%H:%M:%S", time.gmtime(uptime))
        total_users = len(db_inst.get("users", {}))
        total_proxies = len(init_proxies())
        g = db_inst.get("global_stats", {})

        welcome_text = f"""<blockquote>\u256d\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256e
      \u26a1 \ud835\udde6\ud835\udddb\ud835\udddc\ud835\udde7\ud835\udd98 \ud835\udde0\ud835\udd94\ud835\udde6\ud835\udde7\ud835\udd98\ud835\udde5 \u26a1
\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256f</blockquote>

{E_WAVE} Hey, {user_full_link(user)}!
{E_ROBOT} {italic('Premium All-in-One Account Checker')}

<blockquote>
{E_SHIELD} <b>SYSTEM STATUS</b>
{E_GREEN} Online  \u2022  {E_CLOCK} <code>{uptime_str}</code>
{E_USER} Users <code>{total_users}</code>  \u2022  {E_GLOBE} Proxies <code>{total_proxies}</code>
{E_CHART} Checked <code>{g.get('total_checked', 0)}</code>  \u2022  {E_FIRE} Hits <code>{g.get('total_hits', 0)}</code>
</blockquote>

<blockquote>
{E_DIAMOND} <b>PREMIUM MODULES</b>
\U0001F36A <b>Cookie Checker</b> \u2014 22 Services
   Netflix \u2022 ChatGPT \u2022 Claude \u2022 Cursor \u2022 Spotify
   Boosteroid \u2022 Roblox \u2022 Steam \u2022 Discord & more
\U0001F48E <b>Xbox Game Pass</b> \u2014 XGPU / XGP / Minecraft
\u2601\ufe0f <b>Boosteroid Combo</b> \u2014 SHA512 PoW Login
\U0001F4EC <b>Inboxer</b> \u2014 200+ Services Detection
\U0001F4E7 <b>M-Hotmail</b> \u2014 PSN / Steam / TikTok / Discord
\U0001F4FA <b>TV Activators</b> \u2014 Netflix / JioHotstar / Spotify / Prime
</blockquote>

{E_CROWN} {italic('Dev: @ADI_WT')}
{E_HEART} {italic('Select a module below to begin')}{E_HEART} {italic('Enjoy using the bot!')}"""

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton(f"{E_ROCKET} Checker", callback_data="open_checker"),
            types.InlineKeyboardButton(f"{E_USER} My Profile", callback_data="my_profile"),
        )
        markup.add(
            types.InlineKeyboardButton(f"💎 Xbox Game Pass", callback_data="xgp_minecraft"),
            types.InlineKeyboardButton(f"☁️ Boosteroid", callback_data="xgp_boosteroid"),
        )
        markup.add(
            types.InlineKeyboardButton(f"📺 TV Menu", callback_data="tv_menu"),
            types.InlineKeyboardButton(t(user.id, 'language_btn'), callback_data="lang_menu"),
        )
        markup.add(
            types.InlineKeyboardButton(f"{E_GLOBE} Bot Status", callback_data="bot_status"),
            types.InlineKeyboardButton(f"{E_CROSS} Exit", callback_data="exit_bot"),
        )

        photo = get_profile_photo(user.id)
        if photo:
            try:
                bot.send_photo(message.chat.id, photo, caption=welcome_text,
                               parse_mode="HTML", reply_to_message_id=message.message_id, reply_markup=markup)
                return
            except:
                pass
        bot.reply_to(message, welcome_text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)

    @bot.callback_query_handler(func=lambda call: call.data == "open_checker")
    def cb_open_checker(call):
        user = call.from_user
        db_inst = load_db()
        banned, reason = is_banned(db_inst, user.id)
        if banned:
            _answer(bot, call.id, "You are banned!", alert=True)
            return

        is_admin = user.id == ADMIN_ID
        with state.active_checks_lock:
            if user.id in state.active_checks and not is_admin:
                _answer(bot, call.id, "You already have an active check running!", alert=True)
                return

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton(f"{E_CROSS} Back to Menu", callback_data="back_to_menu"))

        approved = is_approved(db_inst, user.id) or is_admin
        limit_text = "Unlimited (Admin)" if is_admin else ("Unlimited (Approved)" if approved else f"Max {MAX_LINES} lines")

        text = f"""{E_ROCKET} {bold('Checker — Send Your File')}

{E_MEMO} {bold('M-HOTMAIL Checker:')}
{E_PIN} Format: {mono('email:password')}
{E_PIN} Lines limit: {mono(limit_text)}
{E_PIN} File: {mono('.txt only')}

{E_STAR} {bold('🍪 Cookie Checker:')}
{E_PIN} Services: {mono('Netflix / ChatGPT / TikTok')}
{E_PIN} Format: {mono('Netscape / JSON / key=value')}
{E_PIN} File: {mono('.txt or .zip')}

{E_STAR} {bold('📬 Inboxer:')}
{E_PIN} Detect {mono('200+ services')} in inbox
{E_PIN} PSN / Games / Social / Payment / Proxy
{E_PIN} File: {mono('.txt only (email:pass)')}

{E_CHECK} {bold('Note')} — Proxies already loaded! {E_GEAR}
{E_BOLT} Threads: Hotmail {mono(str(MASTER_THREADS))} / Inbox {mono(str(INBOXER_THREADS))} / Cookies {mono(str(COOKIES_THREADS))}
{E_GLOBE} Proxies: {mono(str(len(init_proxies())))}

{E_MEMO} {italic('Send your .txt or .zip file to begin!')}
{E_GEAR} {italic('Dev: @ADI_WT')}"""

        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        except:
            bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "my_profile")
    def cb_my_profile(call):
        user = call.from_user
        db_inst = load_db()
        u = get_user(db_inst, user.id)

        is_prem = getattr(user, 'is_premium', False) or False
        prem_text = f"{E_DIAMOND} Yes" if is_prem else f"{E_CROSS} No"
        approved = is_approved(db_inst, user.id)
        rank = f"{E_CROWN} Admin" if user.id == ADMIN_ID else (f"{E_CROWN} Approved" if approved else f"{E_USER} Normal")

        text = f"""{E_USER} {bold('My Profile')}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_SPARKLE} {bold('Name:')} {user_full_link(user)}
{E_PIN} {bold('Username:')} {mono('@' + user.username if user.username else 'N/A')}
{E_KEY} {bold('User ID:')} {mono(str(user.id))}
{E_MEMO} {bold('Chat ID:')} {mono(str(call.message.chat.id))}
{E_DIAMOND} {bold('Premium:')} {prem_text}
{E_SHIELD} {bold('Rank:')} {rank}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_CHART} {bold('Statistics:')}
{E_CHECK} Total Checked: {mono(str(u.get('total_checked', 0)))}
{E_FIRE} Total Hits: {mono(str(u.get('total_hits', 0)))}
{E_GLOBE} Total Lines: {mono(str(u.get('total_lines', 0)))}
{E_BOLT} Total Checks: {mono(str(u.get('checks_count', 0)))}
{E_CLOCK} First Seen: {mono(u.get('first_seen', 'N/A')[:10])}
{E_CLOCK} Last Seen: {mono(u.get('last_seen', 'N/A')[:10])}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_GEAR} {italic('Dev: @ADI_WT')}"""

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton(f"{E_CROSS} Back to Menu", callback_data="back_to_menu"))

        photo = get_profile_photo(user.id)
        if photo:
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            try:
                bot.send_photo(call.message.chat.id, photo, caption=text, parse_mode="HTML", reply_markup=markup)
                _answer(bot, call.id)
                return
            except:
                pass

        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        except:
            bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "bot_status")
    def cb_bot_status(call):
        db_inst = load_db()
        uptime = time.time() - state.BOT_START_TIME
        uptime_str = time.strftime("%Hh %Mm %Ss", time.gmtime(uptime))
        total_users = len(db_inst.get("users", {}))
        total_proxies = len(init_proxies())
        g = db_inst.get("global_stats", {})

        with state.active_checks_lock:
            current_checks = len(state.active_checks)

        text = f"""{E_ROBOT} {bold('Bot Status')}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_GREEN} Status: {mono('Online')}
{E_CLOCK} Uptime: {mono(uptime_str)}
{E_USER} Total Users: {mono(str(total_users))}
{E_GLOBE} Proxies: {mono(str(total_proxies))}
{E_BOLT} Active Checks: {mono(str(current_checks))}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_CHART} {bold('Global Stats:')}
{E_CHECK} Total Checked: {mono(str(g.get('total_checked', 0)))}
{E_FIRE} Total Hits: {mono(str(g.get('total_hits', 0)))}
{E_GLOBE} Total Lines: {mono(str(g.get('total_lines_checked', 0)))}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
{E_GEAR} {italic('Dev: @ADI_WT')}"""

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton(f"{E_CROSS} Back to Menu", callback_data="back_to_menu"))
        try:
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        except:
            bot.send_message(call.message.chat.id, text, parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "exit_bot")
    def cb_exit(call):
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass
        try:
            bot.send_animation(call.message.chat.id, "https://t.me/conflicthistor/1401255",
                               caption=f"{E_WAVE} Bye :)\n{E_GEAR} {italic('Dev: @ADI_WT')}", parse_mode="HTML")
        except:
            bot.send_message(call.message.chat.id, f"{E_WAVE} Bye :)\n{E_GEAR} {italic('Dev: @ADI_WT')}", parse_mode="HTML")
        _answer(bot, call.id)

    # ── Admin: approve / reject access requests ─────────────────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("admin_appr_") or call.data.startswith("admin_rej_"))
    def cb_admin_access(call):
        if call.from_user.id != ADMIN_ID:
            _answer(bot, call.id, "Admin only!", alert=True)
            return
        action = "appr" if call.data.startswith("admin_appr_") else "rej"
        target_id = int(call.data.split("_")[-1])

        with state.active_checks_lock:
            state.active_checks.pop(f"access_req_{target_id}", None)

        if action == "appr":
            from datetime import datetime
            from DATABASE.database import save_db
            db_inst = load_db()
            db_inst.setdefault("approved", {})[str(target_id)] = {
                "days": None, "date": datetime.now().isoformat(), "by": ADMIN_ID
            }
            save_db(db_inst)
            try:
                bot.edit_message_text(
                    f"{E_CHECK} {bold('Approved!')}\nUser {mono(str(target_id))} ab bot use kar sakta hai.",
                    call.message.chat.id, call.message.message_id, parse_mode="HTML"
                )
            except Exception:
                pass
            try:
                bot.send_message(
                    target_id,
                    f"{E_CROWN} {bold('Access Approved!')}\n"
                    f"Admin has approved you — you can now use the bot. Press /start!\n"
                    f"{E_GEAR} {italic('Dev: @ADI_WT')}",
                    parse_mode="HTML"
                )
            except Exception:
                pass
        else:
            try:
                bot.edit_message_text(
                    f"{E_CROSS} {bold('Rejected.')}\nUser {mono(str(target_id))} was not granted access.",
                    call.message.chat.id, call.message.message_id, parse_mode="HTML"
                )
            except Exception:
                pass
            try:
                bot.send_message(
                    target_id,
                    f"{E_CROSS} {bold('Access Rejected')}\nAdmin ne request reject kar di.",
                    parse_mode="HTML"
                )
            except Exception:
                pass
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "lang_menu")
    def cb_lang_menu(call):
        uid = call.from_user.id
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🇬🇧 English", callback_data=f"lang_en_{uid}"),
            types.InlineKeyboardButton("🇮🇳 हिंदी", callback_data=f"lang_hi_{uid}"),
        )
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="back_to_menu"))
        bot.edit_message_text(
            f"{E_GLOBE} <b>Select Language / भाषा चुनें</b>",
            call.message.chat.id, call.message.message_id,
            parse_mode="HTML", reply_markup=markup
        )

    @bot.callback_query_handler(func=lambda call: call.data.startswith("lang_en_") or call.data.startswith("lang_hi_"))
    def cb_lang_set(call):
        uid = int(call.data.split("_")[-1])
        if call.from_user.id != uid:
            return
        lang = "en" if call.data.startswith("lang_en_") else "hi"
        set_lang(uid, lang)
        bot.answer_callback_query(call.id, f"Language set to {'English' if lang=='en' else 'हिंदी'} ✅")
        cb_back_to_menu(call)

    @bot.callback_query_handler(func=lambda call: call.data == "back_to_menu")
    def cb_back_to_menu(call):
        user = call.from_user
        db_inst = load_db()
        uptime = time.time() - state.BOT_START_TIME
        uptime_str = time.strftime("%H:%M:%S", time.gmtime(uptime))
        total_users = len(db_inst.get("users", {}))
        total_proxies = len(init_proxies())
        g = db_inst.get("global_stats", {})

        welcome_text = f"""<blockquote>\u256d\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256e
      \u26a1 \ud835\udde6\ud835\udddb\ud835\udddc\ud835\udde7\ud835\udd98 \ud835\udde0\ud835\udd94\ud835\udde6\ud835\udde7\ud835\udd98\ud835\udde5 \u26a1
\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256f</blockquote>

{E_WAVE} Hey, {user_full_link(user)}!
{E_ROBOT} {italic('Premium All-in-One Account Checker')}

<blockquote>
{E_SHIELD} <b>SYSTEM STATUS</b>
{E_GREEN} Online  \u2022  {E_CLOCK} <code>{uptime_str}</code>
{E_USER} Users <code>{total_users}</code>  \u2022  {E_GLOBE} Proxies <code>{total_proxies}</code>
{E_CHART} Checked <code>{g.get('total_checked', 0)}</code>  \u2022  {E_FIRE} Hits <code>{g.get('total_hits', 0)}</code>
</blockquote>

<blockquote>
{E_DIAMOND} <b>PREMIUM MODULES</b>
\U0001F36A <b>Cookie Checker</b> \u2014 22 Services
   Netflix \u2022 ChatGPT \u2022 Claude \u2022 Cursor \u2022 Spotify
   Boosteroid \u2022 Roblox \u2022 Steam \u2022 Discord & more
\U0001F48E <b>Xbox Game Pass</b> \u2014 XGPU / XGP / Minecraft
\u2601\ufe0f <b>Boosteroid Combo</b> \u2014 SHA512 PoW Login
\U0001F4EC <b>Inboxer</b> \u2014 200+ Services Detection
\U0001F4E7 <b>M-Hotmail</b> \u2014 PSN / Steam / TikTok / Discord
\U0001F4FA <b>TV Activators</b> \u2014 Netflix / JioHotstar / Spotify / Prime
</blockquote>

{E_CROWN} {italic('Dev: @ADI_WT')}
{E_HEART} {italic('Select a module below to begin')}{E_HEART} {italic('Enjoy using the bot!')}"""

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton(f"{E_ROCKET} Checker", callback_data="open_checker"),
            types.InlineKeyboardButton(f"{E_USER} My Profile", callback_data="my_profile"),
        )
        markup.add(
            types.InlineKeyboardButton(f"💎 Xbox Game Pass", callback_data="xgp_minecraft"),
            types.InlineKeyboardButton(f"☁️ Boosteroid", callback_data="xgp_boosteroid"),
        )
        markup.add(
            types.InlineKeyboardButton(f"📺 TV Menu", callback_data="tv_menu"),
            types.InlineKeyboardButton(t(user.id, 'language_btn'), callback_data="lang_menu"),
        )
        markup.add(
            types.InlineKeyboardButton(f"{E_GLOBE} Bot Status", callback_data="bot_status"),
            types.InlineKeyboardButton(f"{E_CROSS} Exit", callback_data="exit_bot"),
        )

        try:
            if call.message.content_type == 'photo':
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(call.message.chat.id, welcome_text, parse_mode="HTML",
                                 reply_markup=markup, disable_web_page_preview=True)
            else:
                bot.edit_message_text(welcome_text, call.message.chat.id, call.message.message_id,
                                      parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True)
        except:
            bot.send_message(call.message.chat.id, welcome_text, parse_mode="HTML",
                             reply_markup=markup, disable_web_page_preview=True)
        _answer(bot, call.id)
