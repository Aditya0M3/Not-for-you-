import json
import threading
from datetime import datetime, timedelta
from CONFIG.config import DB_FILE

db_lock = threading.Lock()


def load_db():
    import os
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {
        "users": {},
        "banned": {},
        "approved": {},
        "global_stats": {
            "total_checked": 0,
            "total_hits": 0,
            "total_lines_checked": 0
        }
    }


def save_db(db):
    with db_lock:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)


def get_user(db, uid):
    uid = str(uid)
    if uid not in db["users"]:
        db["users"][uid] = {
            "username": "",
            "full_name": "",
            "first_seen": datetime.now().isoformat(),
            "last_seen": datetime.now().isoformat(),
            "total_checked": 0,
            "total_hits": 0,
            "total_lines": 0,
            "checks_count": 0
        }
    db["users"][uid]["last_seen"] = datetime.now().isoformat()
    return db["users"][uid]


def update_user_info(db, user):
    uid = str(user.id)
    u = get_user(db, uid)
    u["username"] = user.username or ""
    fn = user.first_name or ""
    ln = user.last_name or ""
    u["full_name"] = f"{fn} {ln}".strip()
    u["last_active"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    save_db(db)


def bump_user_stats(db, uid, files=0, lines=0, hits=0, cookie_checks=0):
    """#12 — user activity counters"""
    uid = str(uid)
    u = get_user(db, uid)
    st = u.setdefault("stats", {})
    st["files"] = st.get("files", 0) + files
    st["lines"] = st.get("lines", 0) + lines
    st["hits"] = st.get("hits", 0) + hits
    st["cookie_checks"] = st.get("cookie_checks", 0) + cookie_checks
    u["last_active"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    save_db(db)


DAILY_FILE_LIMIT = 10  # #15 — non-admin users per day


def get_user_plan(db, uid):
    """#16 — user plan: free | elite"""
    u = get_user(db, str(uid))
    return u.get("plan", "free")


def set_user_plan(db, uid, plan):
    u = get_user(db, str(uid))
    u["plan"] = plan
    save_db(db)


def check_daily_limit(db, uid, limit=None):
    """#15/#16 — (allowed, remaining) daily file limit; Elite = 50/day"""
    if limit is None:
        lim = 50 if get_user_plan(db, uid) == "elite" else DAILY_FILE_LIMIT
    else:
        lim = limit
    uid = str(uid)
    u = get_user(db, uid)
    today = datetime.now().strftime("%Y-%m-%d")
    d = u.get("daily", {})
    if d.get("date") != today:
        d = {"date": today, "files": 0}
    used = d.get("files", 0)
    return used < lim, max(0, lim - used)


def consume_daily_file(db, uid):
    uid = str(uid)
    u = get_user(db, uid)
    today = datetime.now().strftime("%Y-%m-%d")
    d = u.get("daily", {})
    if d.get("date") != today:
        d = {"date": today, "files": 0}
    d["files"] = d.get("files", 0) + 1
    u["daily"] = d
    save_db(db)


def is_banned(db, uid):
    uid = str(uid)
    if uid not in db.get("banned", {}):
        return False, None
    ban = db["banned"][uid]
    if ban.get("days"):
        ban_date = datetime.fromisoformat(ban["date"])
        if datetime.now() > ban_date + timedelta(days=ban["days"]):
            del db["banned"][uid]
            save_db(db)
            return False, None
    return True, ban.get("reason", "No reason")


def is_approved(db, uid):
    uid = str(uid)
    if uid not in db.get("approved", {}):
        return False
    appr = db["approved"][uid]
    if appr.get("days"):
        appr_date = datetime.fromisoformat(appr["date"])
        if datetime.now() > appr_date + timedelta(days=appr["days"]):
            del db["approved"][uid]
            save_db(db)
            return False
    return True
