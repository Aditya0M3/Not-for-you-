
"""
Boosteroid Cloud Gaming Cookie Checker
Checks Boosteroid subscription status via API
"""
import re
import json
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


BOOSTEROID_BASE = "https://cloud.boosteroid.com"


def is_valid_boosteroid(d: dict) -> bool:
    """Check if cookies contain Boosteroid session keys"""
    keys = ['token', 'access_token', 'refresh_token', 'session', 'auth_token', 'boosteroid']
    return any(k in d for k in keys)


def count_valid_boosteroid(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_boosteroid(d):
            result.append((src, d))
    return len(result), result


def _parse_cookies_from_text(text: str) -> Dict[str, str]:
    """Parse cookies from text"""
    text = text.strip()
    if not text:
        return {}
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            cookies[parts[5]] = parts[6]
        elif '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                cookies[kv[0].strip().strip('"')] = kv[1].strip().strip(';').strip('"')
    return cookies


def check_boosteroid_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    """Check Boosteroid cookie and return subscription info"""
    px = None
    try:
        session = requests.Session()

        # Build headers with cookies
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': BOOSTEROID_BASE,
            'Referer': f'{BOOSTEROID_BASE}/',
        }

        # Set cookies
        for k, v in cookies_dict.items():
            session.cookies.set(k, v, domain=".boosteroid.com", path="/")
            session.cookies.set(k, v, domain="cloud.boosteroid.com", path="/")

        # Check auth/login
        r1 = session.get(
            f'{BOOSTEROID_BASE}/api/v1/auth/login',
            headers=headers,
            timeout=(5, 10),
            allow_redirects=True,
            verify=False
        )

        if r1.status_code in (401, 403):
            return None, 'expired'

        # Check subscription
        r2 = session.get(
            f'{BOOSTEROID_BASE}/api/v1/payments/subscriptions?active=true',
            headers=headers,
            timeout=(5, 10),
            allow_redirects=True,
            verify=False
        )

        info = {
            'logged_in': False,
            'email': 'N/A',
            'plan': 'N/A',
            'is_premium': False,
            'expiry': 'N/A',
            'status': 'N/A'
        }

        if r2.status_code == 200:
            try:
                data = r2.json()
                info['logged_in'] = True

                if isinstance(data, list) and len(data) > 0:
                    sub = data[0]
                    info['plan'] = sub.get('plan', 'Unknown')
                    info['status'] = sub.get('status', 'Unknown')
                    info['expiry'] = sub.get('expires_at', 'N/A')
                    info['is_premium'] = info['status'] == 'active'
                elif isinstance(data, dict):
                    info['plan'] = data.get('plan', 'Unknown')
                    info['status'] = data.get('status', 'Unknown')
                    info['expiry'] = data.get('expires_at', 'N/A')
                    info['is_premium'] = info['status'] == 'active'

                # Try to get email from auth response
                if r1.status_code == 200:
                    try:
                        auth_data = r1.json()
                        info['email'] = auth_data.get('email', auth_data.get('user', {}).get('email', 'N/A'))
                    except:
                        pass

                return info, 'valid'
            except:
                pass

        # Check if logged in but no subscription
        if r1.status_code == 200:
            info['logged_in'] = True
            return info, 'valid'

        return None, 'expired'

    except requests.exceptions.ProxyError:
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_boosteroid(d: dict) -> str:
    lines = ["# Netscape HTTP Cookie File", "# Boosteroid Cookies", ""]
    for name, value in d.items():
        secure = "TRUE" if name in ('token', 'access_token', 'auth_token') else "FALSE"
        lines.append(f".boosteroid.com\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_boosteroid(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_boosteroid(cookies_dict)

    content = f"""════════════════════════════════════════════════════════
  WHITE Boosteroid Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Email      : {result.get('email', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Status     : {result.get('status', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}
  Expiry     : {result.get('expiry', 'N/A')}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Boosteroid Checker
════════════════════════════════════════════════════════
"""
    safe_plan = re.sub(r'[<>:"/\\|?*\s]', '_', result.get("plan", "unknown").lower())
    safe_email = re.sub(r'[<>:"/\\|?*\s]', '_', result.get("email", "unknown"))
    filename = f"[boosteroid_{safe_plan}][{safe_email}].txt"
    return content, filename
