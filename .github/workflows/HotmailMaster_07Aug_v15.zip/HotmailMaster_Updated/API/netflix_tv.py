
"""
Netflix TV Activator Engine
Activate Netflix on TV using cookies from nf_cookies/ folder
"""
import os
import re
import json
import requests
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"


class NetflixTVActivator:
    """Netflix TV Activator - Activate Netflix on TV using web activation"""

    def __init__(self, cookies_folder="nf_cookies"):
        self.cookies_folder = Path(cookies_folder)
        self.cookies_folder.mkdir(exist_ok=True)
        self.hits_folder = Path("nf_tv_hits")
        self.hits_folder.mkdir(exist_ok=True)

    def parse_cookie(self, cookie_file):
        """Parse a cookie file (Netscape format or JSON)"""
        cp = self.cookies_folder / cookie_file
        if not cp.exists():
            return None
        try:
            with open(cp, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            cookies = {}

            # Try JSON first
            try:
                data = json.loads(content)
                if isinstance(data, dict) and "cookies" in data and isinstance(data["cookies"], list):
                    for c in data["cookies"]:
                        if isinstance(c, dict):
                            name = c.get("name", "")
                            value = c.get("value", "")
                            if name:
                                cookies[name] = value
                    return cookies if cookies else None
            except:
                pass

            # Netscape format
            for line in content.strip().split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                p = line.split('\t')
                if len(p) >= 7:
                    cookies[p[5]] = p[6]
                elif '=' in line:
                    try:
                        k, v = line.split('=', 1)
                        cookies[k.strip()] = v.strip()
                    except:
                        pass
            return cookies if cookies else None
        except:
            return None

    def get_account_info(self, cookies):
        """Check if Netflix account is valid and get info"""
        try:
            session = requests.Session()
            session.cookies.update(cookies)
            headers = {
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
            }
            # Check Netflix account page
            r = session.get('https://www.netflix.com/YourAccount', headers=headers, timeout=30, allow_redirects=True)
            if r.status_code != 200:
                return None

            if 'login' in r.url.lower() or 'signin' in r.url.lower():
                return None

            # Extract account info
            info = {'plan': 'Unknown', 'country': 'Unknown', 'email': None, 'is_premium': False}

            # Check for premium indicators
            text = r.text
            if 'Account' in text or 'Membership' in text or 'Plan' in text:
                info['is_premium'] = True

            # Try to get plan
            pm = re.search(r'localizedPlanName.{1,50}?value":"([^"]+)"', text)
            if pm:
                info['plan'] = pm.group(1)

            # Try to get email
            em = re.search(r'"emailAddress"\s*:\s*"([^"]+)"', text)
            if em:
                info['email'] = em.group(1)

            # Try to get country
            cm = re.search(r'"countryOfSignup"\s*:\s*"([^"]+)"', text)
            if cm:
                info['country'] = cm.group(1)

            return info
        except:
            return None

    def find_premium_account(self):
        """Find a working Netflix account from cookies folder"""
        for cf in self.cookies_folder.iterdir():
            if not cf.is_file():
                continue
            cookies = self.parse_cookie(cf.name)
            if not cookies:
                continue
            info = self.get_account_info(cookies)
            if info and info.get('is_premium'):
                return cf.name, cookies, info
        return None, None, None

    def activate_tv(self, cookies, tv_code):
        """Activate Netflix on TV using the TV code"""
        try:
            session = requests.Session()
            session.cookies.update(cookies)

            headers = {
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://www.netflix.com/',
            }

            # Netflix TV activation URL
            activation_url = "https://www.netflix.com/tv"
            r = session.get(activation_url, headers=headers, timeout=30, allow_redirects=True)

            if r.status_code != 200:
                return False, f"Failed to load activation page (HTTP {r.status_code})"

            # Extract any necessary tokens from the page
            auth_token = None
            token_match = re.search(r'authURL["\']?\s*:\s*["\']?([^"\']+)', r.text)
            if token_match:
                auth_token = token_match.group(1)

            # Step 2: Submit the TV code
            submit_headers = {
                **headers,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://www.netflix.com',
                'Referer': activation_url,
            }

            form_data = {
                'code': tv_code,
                'action': 'registerDevice',
            }
            if auth_token:
                form_data['authURL'] = auth_token

            # Try Netflix TV activation endpoints
            endpoints = [
                "https://www.netflix.com/api/tv/device",
                "https://www.netflix.com/tv",
            ]

            for endpoint in endpoints:
                try:
                    r2 = session.post(endpoint, data=form_data, headers=submit_headers, timeout=30, allow_redirects=True)

                    if r2.status_code == 200:
                        text_lower = r2.text.lower()
                        if any(x in text_lower for x in ['success', 'activated', 'registered', 'device registered']):
                            return True, "Netflix TV Activation Successful"
                        if 'already registered' in text_lower:
                            return True, "Device already registered"
                        if 'invalid code' in text_lower:
                            return False, "Invalid TV code"
                        if 'expired' in text_lower:
                            return False, "TV code expired"
                except:
                    continue

            # If we get here, check the last response for clues
            if 'invalid' in r2.text.lower():
                return False, "Invalid TV code"
            if 'expired' in r2.text.lower():
                return False, "TV code expired"

            return True, "Activation request completed. Check your TV."

        except Exception as e:
            return False, f"Error: {str(e)[:100]}"

    def save_hit(self, tv_code, info):
        """Save successful activation to hits folder"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = self.hits_folder / f"nf_tv_activated_{timestamp}.txt"
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Netflix TV Activated Successfully\n")
            f.write(f"TV Code: {tv_code}\n")
            f.write(f"Plan: {info.get('plan', 'Unknown')}\n")
            f.write(f"Country: {info.get('country', 'Unknown')}\n")
            f.write(f"Email: {info.get('email', 'Unknown')}\n")
            f.write(f"Time: {timestamp}\n")
        return filepath
