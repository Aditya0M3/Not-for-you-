"""
JioHotstar TV Activator Engine
Based on JioHotstar (1).py logic | Integrated into Hotmail Master Bot
"""
import os
import re
import json
import glob
import random
import cloudscraper
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class JioHotstarTVActivator:
    """JioHotstar TV Activator - Activate JioHotstar on TV using QR code"""

    def __init__(self, cookies_folder="jh_cookies"):
        self.cookies_folder = Path(cookies_folder)
        self.cookies_folder.mkdir(exist_ok=True)
        self.stats_file = Path("jh_stats.json")
        self.usage_file = Path("jh_cookie_usage.json")

    def _load_stats(self) -> dict:
        try:
            with open(self.stats_file, 'r') as f:
                return json.load(f)
        except:
            return {'total': 0, 'success': 0, 'failed': 0, 'last': None}

    def _save_stats(self, stats: dict):
        with open(self.stats_file, 'w') as f:
            json.dump(stats, f, indent=2)

    def _load_usage(self) -> dict:
        try:
            with open(self.usage_file, 'r') as f:
                return json.load(f)
        except:
            return {}

    def _save_usage(self, usage: dict):
        with open(self.usage_file, 'w') as f:
            json.dump(usage, f, indent=2)

    def _get_usage(self, name: str) -> int:
        return self._load_usage().get(name, 0)

    def _inc_usage(self, name: str) -> int:
        u = self._load_usage()
        u[name] = u.get(name, 0) + 1
        self._save_usage(u)
        return u[name]

    def _parse_cookie(self, filepath: str) -> Tuple[str, Optional[str], Optional[str], Optional[str]]:
        """Parse cookie file and return cookie string + tokens"""
        cookies = {}
        session_token = None
        user_up_token = None
        device_id = None

        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split('\t')
                    if len(parts) >= 7:
                        name = parts[5]
                        value = parts[6]
                        cookies[name] = value
                        if name == 'sessionUserUP':
                            session_token = value
                        elif name == 'userUP':
                            user_up_token = value
                        elif name == 'deviceId':
                            device_id = value
        except:
            pass

        cookie_str = '; '.join([f"{k}={v}" for k, v in cookies.items()])
        return cookie_str, session_token, user_up_token, device_id

    def get_random_cookie(self) -> Tuple[Optional[dict], Optional[str]]:
        """Get a random available cookie (max 3 uses)"""
        cookie_files = glob.glob(str(self.cookies_folder / "*.txt"))

        if not cookie_files:
            return None, "No cookie files found in vault"

        available = [f for f in cookie_files if self._get_usage(os.path.basename(f)) < 3]
        if not available:
            return None, "All cookies have reached maximum usage limit (3 uses)"

        random.shuffle(available)
        filepath = available[0]
        filename = os.path.basename(filepath)

        cookie_str, session_token, user_up_token, device_id = self._parse_cookie(filepath)
        if not cookie_str:
            return None, f"Failed to parse {filename}"

        name = filename.replace('.txt', '').split('_')[0] if '_' in filename else filename.replace('.txt', '')

        return {
            'name': name,
            'cookie_str': cookie_str,
            'token': session_token or user_up_token,
            'device_id': device_id,
            'filepath': filepath,
            'filename': filename
        }, None

    def count_cookies(self) -> int:
        return len(glob.glob(str(self.cookies_folder / "*.txt")))

    def count_available(self) -> int:
        return sum(1 for f in glob.glob(str(self.cookies_folder / "*.txt")) 
                   if self._get_usage(os.path.basename(f)) < 3)

    def activate_tv(self, qr_url: str, cookie_info: dict) -> Tuple[bool, str]:
        """Activate JioHotstar on TV using QR code"""
        scraper = cloudscraper.create_scraper()

        headers = {
            "authority": "www.hotstar.com",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "accept-language": "en-MM,en-GB;q=0.9,en-US;q=0.8,en;q=0.7",
            "cookie": cookie_info['cookie_str'],
            "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
        }

        if cookie_info.get('token'):
            headers["cookie"] += f"; userUP={cookie_info['token']}"

        try:
            response = scraper.get(qr_url, headers=headers, timeout=30)

            if response.status_code == 200:
                if "success" in response.text.lower() or "activated" in response.text.lower():
                    return True, "✅ JioHotstar Activation Successful"
                elif "JioHotstar" in response.text and "Watch TV Shows" in response.text:
                    return True, "✅ Page loaded! TV activation in progress"
                else:
                    return True, "✅ Request completed. Check your TV"

            return False, f"❌ Failed with status: {response.status_code}"
        except Exception as e:
            return False, f"❌ Error: {str(e)[:100]}"

    def update_stats(self, success: bool = True) -> dict:
        stats = self._load_stats()
        stats['total'] += 1
        if success:
            stats['success'] += 1
        else:
            stats['failed'] += 1
        stats['last'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self._save_stats(stats)
        return stats

    def delete_cookie(self, filepath: str) -> bool:
        try:
            os.remove(filepath)
            return True
        except:
            return False

    def clear_all(self) -> int:
        files = glob.glob(str(self.cookies_folder / "*.txt"))
        deleted = sum(1 for f in files if self.delete_cookie(f))
        self._save_usage({})
        return deleted

    def check_cookie_premium(self, cookie_info: dict) -> Tuple[bool, str, dict]:
        """Check if JioHotstar cookie has active premium subscription"""
        scraper = cloudscraper.create_scraper()

        headers = {
            "authority": "www.hotstar.com",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "accept-language": "en-US,en;q=0.9",
            "cookie": cookie_info['cookie_str'],
            "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
        }

        if cookie_info.get('token'):
            headers["cookie"] += f"; userUP={cookie_info['token']}"

        try:
            # Check account page for subscription info
            r = scraper.get("https://www.hotstar.com/in/subscribe/my-account", 
                          headers=headers, timeout=20, allow_redirects=True)

            if r.status_code != 200:
                return False, f"HTTP {r.status_code}", {}

            text = r.text.lower()

            # Check for premium indicators
            is_premium = any(x in text for x in [
                'premium', 'vip', 'gold', 'plus', 'max', 'subscription',
                'active plan', 'current plan', 'membership'
            ])

            # Check for free/expired indicators
            is_free = any(x in text for x in [
                'no active plan', 'subscribe now', 'free tier',
                'upgrade to premium', 'start free trial'
            ])

            # Extract plan info if available
            # Extract plan info if available
            plan = "Unknown"
            plan_pattern = r'''plan["']?\s*:\s*["']?([^"']+)'''
            plan_match = re.search(plan_pattern, r.text, re.I)
            if plan_match:
                plan = plan_match.group(1)

            # Extract email if available
            email = "N/A"
            email_pattern = r'''email["']?\s*:\s*["']?([^"']+@[^"']+)'''
            email_match = re.search(email_pattern, r.text, re.I)
            if email_match:
                email = email_match.group(1)
                email = email_match.group(1)
                email = email_match.group(1)

            account_info = {
                'plan': plan,
                'email': email,
                'is_premium': is_premium and not is_free
            }

            if is_premium and not is_free:
                return True, "✅ Premium subscription active", account_info
            elif is_free:
                return False, "❌ Free account - no active subscription", account_info
            else:
                return False, "❌ No active subscription found", account_info

        except Exception as e:
            return False, f"❌ Error checking subscription: {str(e)[:100]}", {}

    def get_premium_cookie(self) -> Tuple[Optional[dict], Optional[str]]:
        """Get a random premium cookie (checks subscription status)"""
        cookie_files = glob.glob(str(self.cookies_folder / "*.txt"))

        if not cookie_files:
            return None, "No cookie files found in vault"

        # Shuffle to try random order
        random.shuffle(cookie_files)

        for filepath in cookie_files:
            filename = os.path.basename(filepath)
            usage_count = self._get_usage(filename)

            if usage_count >= 3:
                continue  # Skip maxed out cookies

            cookie_str, session_token, user_up_token, device_id = self._parse_cookie(filepath)
            if not cookie_str:
                continue

            name = filename.replace('.txt', '').split('_')[0] if '_' in filename else filename.replace('.txt', '')

            cookie_info = {
                'name': name,
                'cookie_str': cookie_str,
                'token': session_token or user_up_token,
                'device_id': device_id,
                'filepath': filepath,
                'filename': filename
            }

            # Check if premium
            is_premium, msg, account_info = self.check_cookie_premium(cookie_info)

            if is_premium:
                cookie_info['account_info'] = account_info
                return cookie_info, None

        return None, "No premium subscription cookies found. All cookies are free/expired."
